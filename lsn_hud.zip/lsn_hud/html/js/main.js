/* ============================================================
   LSN HUD · enrutador de mensajes de Lua
   ============================================================ */
(() => {
  'use strict';
  const { $, post, on, emit, state, applyTheme, placeAll } = window.LSN;

  on('config', (c) => { state.config = { ...state.config, ...c }; });

  on('settings', () => {
    applyTheme(state.settings);
    placeAll();
  });

  on('serverConfig', (payload) => {
    if (!payload || typeof payload !== 'object') return;
    if (typeof payload.isAdmin === 'boolean') state.isAdmin = payload.isAdmin;
    if (payload.server && typeof payload.server === 'object') {
      state.server = window.LSN.normServer(payload.server);
    }
    emit('serverUpdated', state.server);
    placeAll();
  });

  on('visible', (v) => {
    state.visible = !!v;
    $('root').classList.toggle('hud-hidden', !v);
  });

  on('cinematic', (v) => { $('cine').classList.toggle('on', !!v); });

  window.addEventListener('message', (e) => {
    const m = e.data;
    if (!m || typeof m.a !== 'string') return;
    if (m.a === 'settings') {
      if (window.LSN.settingsPanel && window.LSN.settingsPanel.isOpen()) return;
      state.settings = window.LSN.normSettings(m.d);
      emit('settings', state.settings);
      return;
    }
    emit(m.a, m.d);
  });

  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (window.LSN.settingsPanel && (window.LSN.settingsPanel.isOpen() || $('root').classList.contains('editing'))) {
      window.LSN.settingsPanel.escape();
    } else if (window.LSN.carplay && window.LSN.carplay.isOpen()) {
      window.LSN.carplay.close();
    }
  });

  applyTheme(state.settings);
  placeAll();
  emit('settings', state.settings);
  emit('serverUpdated', state.server);
  post('ready');
})();
