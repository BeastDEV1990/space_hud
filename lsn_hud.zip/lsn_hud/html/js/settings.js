/* ============================================================
   LSN HUD · /lsnhud + /lsnhudadmin
   Ajustes del jugador, edicion de brujula, panel de admin con
   gestor de logo (link o subida) y editor de posiciones con guias.
   ============================================================ */
(() => {
  'use strict';
  const { $, esc, clamp, num, post, on, emit, state, icons: I, applyTheme, placeAll, Speedo, speedoDemo } = window.LSN;

  const root = $('settings');
  const hudRoot = $('root');
  const guidesEl = $('editGuides');
  const coordsEl = $('editCoords');

  let orig = null;
  let origServer = null;
  let fromCarplay = false;
  let open = false;
  let activeTab = 'general';
  let previews = [];
  let demoTimer = null;

  const STYLES = [
    { id: 'minimal', name: 'Minimalista', desc: 'Limpio y flotante: velocidad clara, barra fina de RPM y testigos activos.' },
    { id: 'digital', name: 'Digital', desc: 'Arco minimalista de RPM, velocidad centrada y barra de combustible.' },
    { id: 'analog', name: 'Agujas', desc: 'Dos relojes transparentes y ligeros con agujas de precisión.' },
    { id: 'sport', name: 'Deportivo', desc: 'Barra de cambio LED, marcha protagonista y telemetría limpia.' },
  ];

  const TOGGLES = [
    ['minimapOnFoot', 'Minimapa a pie', 'Si se apaga, el radar solo aparece en vehículos.'],
    ['statusMode', 'Comida y sed solo cuando bajan', 'Se muestran al bajar del 35%.'],
    ['showStreet', 'Calle, zona y reloj', 'Bloque independiente y movible.'],
    ['showVoice', 'Indicador de voz', 'Se ilumina al hablar o usar radio.'],
    ['beltChime', 'Aviso del cinturón', 'Suena sin cinturón a más de 20 km/h.'],
    ['alertSounds', 'Sonidos del tablero', 'Direccionales, crucero y alertas.'],
  ];

  root.innerHTML = `
    <div class="st" role="dialog" aria-label="Panel de configuración del HUD">
      <header class="st-head">
        <div>
          <b>LSN HUD</b>
          <small id="stSub">Personaliza tu pantalla, brújula y posiciones</small>
        </div>
        <nav class="st-tabs" id="stTabs">
          <button type="button" class="st-tab on" data-tab="general">HUD y Velocímetro</button>
          <button type="button" class="st-tab" data-tab="compass">Brújula</button>
          <button type="button" class="st-tab st-tab-admin" data-tab="admin" id="tabAdminBtn" hidden>Panel Admin</button>
        </nav>
        <button type="button" class="icon-btn" id="stClose" aria-label="Cerrar">${I.close}</button>
      </header>

      <!-- TAB 1: GENERAL & VELOCIMETRO -->
      <div class="st-body st-pane" data-pane="general">
        <section class="st-left">
          <h4>Estilo de velocímetro</h4>
          <div class="sp-cards" id="spCards">
            ${STYLES.map((s) => `<button type="button" class="sp-card" data-style="${s.id}"><div class="sp-prev"><div class="sp-prev-in"></div></div><b>${s.name}</b><small>${s.desc}</small></button>`).join('')}
          </div>
        </section>
        <section class="st-right">
          <h4>Unidades</h4>
          <div class="segctl" id="stUnits"><button type="button" data-v="kmh">km/h · km</button><button type="button" data-v="mph">mph · millas</button></div>
          <h4>Color de acento</h4>
          <div class="swatches" id="stAccent"></div>
          <h4>Tamaño global <output id="stScaleV">90%</output></h4>
          <input type="range" id="stScale" min="0.6" max="1.6" step="0.05">
          <h4>Elementos visibles</h4>
          <div class="toggles" id="stToggles">
            ${TOGGLES.map(([k, l, d]) => `<label class="tg"><input type="checkbox" data-k="${k}"><i></i><span><b>${l}</b>${d ? `<small>${d}</small>` : ''}</span></label>`).join('')}
          </div>
          <h4>Volumen de la radio <output id="stVolV">100</output></h4>
          <input type="range" id="stVol" min="0" max="100" step="1">
        </section>
      </div>

      <!-- TAB 2: EDICION DE BRUJULA -->
      <div class="st-body st-pane st-pane-single" data-pane="compass" hidden>
        <section class="st-card-grid">
          <div class="st-box">
            <h4>Apariencia de la brújula</h4>
            <label class="tg">
              <input type="checkbox" id="cmpShow"><i></i>
              <span><b>Mostrar brújula</b><small>Activa o desactiva la brújula de forma independiente a la calle.</small></span>
            </label>

            <h4>Estilo</h4>
            <div class="segctl segctl-3" id="cmpStyle">
              <button type="button" data-v="minimal">Minimalista</button>
              <button type="button" data-v="bar">Barra</button>
              <button type="button" data-v="compact">Compacta</button>
            </div>

            <h4>Ancho de la cinta <output id="cmpWidthV">280 px</output></h4>
            <input type="range" id="cmpWidth" min="180" max="420" step="10">

            <label class="tg">
              <input type="checkbox" id="cmpDegrees"><i></i>
              <span><b>Mostrar números de grados</b><small>Muestra 15, 30, 60... entre los puntos cardinales.</small></span>
            </label>
            <label class="tg">
              <input type="checkbox" id="cmpHeading"><i></i>
              <span><b>Mostrar rumbo exacto</b><small>Muestra el indicador de dirección y grados (ej. N · 004°).</small></span>
            </label>
          </div>

          <div class="st-box">
            <h4>Ubicación de la brújula</h4>
            <p class="st-hint">Puedes mover la brújula libremente a cualquier parte de la pantalla o elegir una posición rápida.</p>
            <div class="preset-grid" id="cmpPresets">
              <button type="button" class="btn" data-preset="topCenter">Arriba centro</button>
              <button type="button" class="btn" data-preset="aboveMap">Sobre minimapa</button>
              <button type="button" class="btn" data-preset="topLeft">Arriba izquierda</button>
              <button type="button" class="btn" data-preset="topRight">Arriba derecha</button>
            </div>
            <div class="st-actions-col">
              <button type="button" class="btn btn-primary" id="cmpMoveBtn">Mover brújula en pantalla</button>
              <button type="button" class="btn" id="cmpResetPos">Restablecer posición de brújula</button>
            </div>
          </div>
        </section>
      </div>

      <!-- TAB 3: PANEL ADMIN / SERVIDOR (LOGO DEL SERVIDOR) -->
      <div class="st-body st-pane st-pane-single" data-pane="admin" hidden>
        <section class="st-card-grid">
          <div class="st-box">
            <h4>Logo del servidor (Global)</h4>
            <label class="tg">
              <input type="checkbox" id="admLogoEnabled"><i></i>
              <span><b>Mostrar logo en el HUD</b><small>Visible para todos los jugadores conectados.</small></span>
            </label>

            <h4>Pegar enlace de imagen (URL)</h4>
            <div class="url-row">
              <input type="text" id="admLogoUrl" class="txt-in" placeholder="https://ejemplo.com/logo.png">
              <button type="button" class="btn" id="admApplyUrl">Aplicar</button>
            </div>

            <h4>O subir imagen desde tu PC</h4>
            <label class="dropzone" id="admDropzone">
              <input type="file" id="admLogoFile" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml" hidden>
              <b>Haz clic o arrastra una imagen aquí</b>
              <small>PNG, WebP, JPG, SVG o GIF (se optimiza automáticamente)</small>
            </label>

            <div class="logo-prev-wrap">
              <div class="logo-prev-box">
                <img id="admLogoPrev" alt="Vista previa" hidden>
                <span id="admLogoEmpty" class="muted">Sin logo cargado</span>
              </div>
              <div class="logo-prev-info">
                <small id="admLogoMeta" class="muted">Pega un enlace o sube un archivo.</small>
                <button type="button" class="btn btn-danger" id="admLogoClear">Quitar logo</button>
              </div>
            </div>
          </div>

          <div class="st-box">
            <h4>Tamaño, opacidad y ubicación global</h4>
            <h4>Tamaño del logo <output id="admLogoSizeV">68 px</output></h4>
            <input type="range" id="admLogoSize" min="28" max="220" step="2">

            <h4>Opacidad <output id="admLogoOpacityV">90%</output></h4>
            <input type="range" id="admLogoOpacity" min="10" max="100" step="5">

            <h4>Posición global por defecto</h4>
            <div class="preset-grid" id="admLogoPresets">
              <button type="button" class="btn" data-lp="topRight">Arriba derecha</button>
              <button type="button" class="btn" data-lp="topLeft">Arriba izquierda</button>
              <button type="button" class="btn" data-lp="topCenter">Arriba centro</button>
              <button type="button" class="btn" data-lp="bottomRight">Abajo derecha</button>
            </div>

            <div class="st-actions-col">
              <button type="button" class="btn" id="admMoveLogo">Mover logo arrastrando en pantalla</button>
              <button type="button" class="btn btn-primary" id="admSaveServer">Guardar para todo el servidor</button>
            </div>
            <p class="st-hint">Los cambios de esta pestaña se guardan en el servidor y se sincronizan al instante con todos los jugadores.</p>
          </div>
        </section>
      </div>

      <footer class="st-foot">
        <button type="button" class="btn" id="stMove">Mover elementos</button>
        <button type="button" class="btn" id="stReset">Restablecer todo</button>
        <span class="grow"></span>
        <button type="button" class="btn" id="stCancel">Cancelar</button>
        <button type="button" class="btn btn-primary" id="stSave">Guardar mis ajustes</button>
      </footer>
    </div>`;

  const draft = () => state.settings;
  const srvDraft = () => state.server;

  function setTab(tab) {
    if (tab === 'admin' && !state.isAdmin) tab = 'general';
    activeTab = tab;
    root.querySelectorAll('.st-tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
    root.querySelectorAll('.st-pane').forEach((p) => { p.hidden = p.dataset.pane !== tab; });
    if (tab === 'general' && open && !demoTimer) startPreviews();
    else if (tab !== 'general') stopPreviews();
  }

  function paintAdmin() {
    const srv = srvDraft();
    $('tabAdminBtn').hidden = !state.isAdmin;
    $('admLogoEnabled').checked = !!srv.logoEnabled;
    const isData = String(srv.logoUrl || '').startsWith('data:image/');
    $('admLogoUrl').value = isData ? '' : (srv.logoUrl || '');
    $('admLogoUrl').placeholder = isData ? 'Imagen subida localmente (pega un link para reemplazar)' : 'https://ejemplo.com/logo.png';
    $('admLogoSize').value = num(srv.logoSize, 68);
    $('admLogoSizeV').textContent = num(srv.logoSize, 68) + ' px';
    $('admLogoOpacity').value = num(srv.logoOpacity, 90);
    $('admLogoOpacityV').textContent = num(srv.logoOpacity, 90) + '%';

    const prev = $('admLogoPrev');
    const empty = $('admLogoEmpty');
    const meta = $('admLogoMeta');
    if (srv.logoUrl) {
      prev.src = srv.logoUrl;
      prev.hidden = false;
      empty.hidden = true;
      meta.textContent = isData
        ? `Imagen subida (${Math.round(srv.logoUrl.length / 1024)} KB)`
        : 'Enlace externo configurado';
    } else {
      prev.removeAttribute('src');
      prev.hidden = true;
      empty.hidden = false;
      meta.textContent = 'Pega un enlace o sube un archivo.';
    }
  }

  function paint() {
    const s = draft();
    root.querySelectorAll('.sp-card').forEach((c) => c.classList.toggle('on', c.dataset.style === s.speedo));
    root.querySelectorAll('#stUnits button').forEach((b) => b.classList.toggle('on', b.dataset.v === s.units));
    $('stAccent').innerHTML = (state.config.accents || []).map((c) =>
      `<button type="button" class="sw${c.toLowerCase() === String(s.accent).toLowerCase() ? ' on' : ''}" data-c="${esc(c)}" style="--c:${esc(c)}" aria-label="${esc(c)}"></button>`).join('');
    $('stScale').value = s.scale;
    $('stScaleV').textContent = Math.round(num(s.scale, 0.9) * 100) + '%';
    root.querySelectorAll('#stToggles input').forEach((i) => {
      const k = i.dataset.k;
      i.checked = k === 'statusMode' ? s.statusMode === 'auto' : !!s[k];
    });
    $('stVol').value = s.musicVolume;
    $('stVolV').textContent = s.musicVolume;

    // Brujula
    $('cmpShow').checked = !!s.showCompass;
    root.querySelectorAll('#cmpStyle button').forEach((b) => b.classList.toggle('on', b.dataset.v === (s.compassStyle || 'minimal')));
    $('cmpWidth').value = num(s.compassWidth, 280);
    $('cmpWidthV').textContent = num(s.compassWidth, 280) + ' px';
    $('cmpDegrees').checked = !!s.compassDegrees;
    $('cmpHeading').checked = !!s.compassHeading;

    paintAdmin();
  }

  function live() {
    applyTheme(draft());
    placeAll();
    emit('settings', draft());
    paint();
  }

  function liveServer() {
    emit('serverUpdated', srvDraft());
    paintAdmin();
  }

  // ------------------------------------------------------------
  // Vistas previas animadas
  // ------------------------------------------------------------
  function startPreviews() {
    stopPreviews();
    previews = [...root.querySelectorAll('.sp-card')].map((c) => new Speedo(c.querySelector('.sp-prev-in'), c.dataset.style));
    const t0 = performance.now();
    demoTimer = setInterval(() => {
      const d = speedoDemo(performance.now() - t0);
      if (draft().units === 'mph') { d.unit = 'mph'; d.spd *= 0.6214; d.km *= 0.6214; d.trip *= 0.6214; d.dist = 'mi'; }
      previews.forEach((p) => p.update(d));
    }, 110);
  }
  function stopPreviews() {
    if (demoTimer) { clearInterval(demoTimer); demoTimer = null; }
    root.querySelectorAll('.sp-prev-in').forEach((e) => { e.innerHTML = ''; });
    previews = [];
  }

  // ------------------------------------------------------------
  // Subida y compresion de imagen local (para logo)
  // ------------------------------------------------------------
  function handleLogoFile(file) {
    if (!file || !file.type || !file.type.startsWith('image/')) {
      post('notify', { msg: 'Selecciona un archivo de imagen válido.', kind: 'error' });
      return;
    }
    const maxBytes = num(state.config.maxLogoBytes, 240000);
    const reader = new FileReader();
    reader.onload = () => {
      const rawUrl = String(reader.result || '');
      // SVG o GIF pequenos pasan directo si caben
      if ((file.type === 'image/svg+xml' || file.type === 'image/gif') && rawUrl.length <= maxBytes) {
        srvDraft().logoUrl = rawUrl;
        srvDraft().logoEnabled = true;
        return liveServer();
      }
      const img = new Image();
      img.onload = () => {
        const maxDim = 420;
        let w = img.naturalWidth || img.width;
        let h = img.naturalHeight || img.height;
        if (w > maxDim || h > maxDim) {
          const r = Math.min(maxDim / w, maxDim / h);
          w = Math.max(1, Math.round(w * r));
          h = Math.max(1, Math.round(h * r));
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);

        // Intentar WebP con transparencia, luego PNG, luego reducir calidad
        let out = canvas.toDataURL('image/webp', 0.88);
        if (!out.startsWith('data:image/webp') || out.length > maxBytes) {
          out = canvas.toDataURL('image/png');
        }
        if (out.length > maxBytes) {
          out = canvas.toDataURL('image/webp', 0.65);
        }
        if (out.length > maxBytes) {
          post('notify', { msg: 'La imagen sigue siendo muy pesada. Usa una más pequeña o un enlace.', kind: 'error' });
          return;
        }
        srvDraft().logoUrl = out;
        srvDraft().logoEnabled = true;
        liveServer();
      };
      img.onerror = () => post('notify', { msg: 'No se pudo leer esa imagen.', kind: 'error' });
      img.src = rawUrl;
    };
    reader.readAsDataURL(file);
  }

  // ------------------------------------------------------------
  // Abrir / cerrar
  // ------------------------------------------------------------
  function openPanel(fromCp, tab) {
    fromCarplay = !!fromCp;
    if (fromCarplay) window.LSN.carplay.hide();
    state.settings = window.LSN.normSettings(state.settings);
    state.server = window.LSN.normServer(state.server);
    orig = JSON.parse(JSON.stringify(state.settings));
    origServer = JSON.parse(JSON.stringify(state.server));
    state.settings = JSON.parse(JSON.stringify(state.settings));
    state.server = JSON.parse(JSON.stringify(state.server));
    open = true;
    root.hidden = false;
    paint();
    setTab(tab || 'general');
  }

  function closePanel(save) {
    if (!open) return;
    open = false;
    stopPreviews();
    root.hidden = true;
    if (save) {
      post('saveSettings', state.settings);
    } else {
      state.settings = orig;
      state.server = origServer;
      applyTheme(state.settings);
      placeAll();
      emit('settings', state.settings);
      emit('serverUpdated', state.server);
    }
    if (fromCarplay) window.LSN.carplay.show();
    else post('close');
  }

  on('openSettings', (d) => {
    if (d && d.fromCarplay) return openPanel(true, 'general');
    if (d && typeof d === 'object') {
      if (typeof d.isAdmin === 'boolean') state.isAdmin = d.isAdmin;
      if (d.server) state.server = window.LSN.normServer(d.server);
      const incoming = d.settings || (!d.tab && !d.server ? d : null);
      if (incoming && typeof incoming === 'object') {
        state.settings = window.LSN.normSettings({ ...state.settings, ...incoming });
      }
      openPanel(false, d.tab || 'general');
    } else {
      openPanel(false, 'general');
    }
  });

  // ------------------------------------------------------------
  // Eventos del panel
  // ------------------------------------------------------------
  root.addEventListener('click', (e) => {
    const tabBtn = e.target.closest('.st-tab');
    if (tabBtn) return setTab(tabBtn.dataset.tab);

    const card = e.target.closest('.sp-card');
    if (card) { draft().speedo = card.dataset.style; return live(); }

    const u = e.target.closest('#stUnits button');
    if (u) { draft().units = u.dataset.v; return live(); }

    const sw = e.target.closest('.sw');
    if (sw) { draft().accent = sw.dataset.c; return live(); }

    const cs = e.target.closest('#cmpStyle button');
    if (cs) { draft().compassStyle = cs.dataset.v; return live(); }

    const cp = e.target.closest('#cmpPresets button');
    if (cp) {
      const p = cp.dataset.preset;
      const r = state.minimap.rect;
      if (!draft().pos || Array.isArray(draft().pos)) draft().pos = {};
      if (p === 'topCenter') delete draft().pos.compass;
      else if (p === 'aboveMap') draft().pos.compass = { x: +r.x.toFixed(2), y: +Math.max(2, r.y - 6.5).toFixed(2) };
      else if (p === 'topLeft') draft().pos.compass = { x: 2.0, y: 2.0 };
      else if (p === 'topRight') draft().pos.compass = { x: 76.0, y: 2.0 };
      return live();
    }

    const lp = e.target.closest('#admLogoPresets button');
    if (lp) {
      const k = lp.dataset.lp;
      if (k === 'topRight') srvDraft().logoPos = { x: 93.5, y: 2.4 };
      else if (k === 'topLeft') srvDraft().logoPos = { x: 2.0, y: 2.4 };
      else if (k === 'topCenter') srvDraft().logoPos = { x: 48.0, y: 2.0 };
      else if (k === 'bottomRight') srvDraft().logoPos = { x: 93.5, y: 88.0 };
      if (draft().pos) delete draft().pos.logo;
      return liveServer();
    }
  });

  $('stScale').addEventListener('input', (e) => { draft().scale = Number(e.target.value); live(); });
  $('stVol').addEventListener('input', (e) => { draft().musicVolume = Number(e.target.value); $('stVolV').textContent = e.target.value; });
  root.querySelectorAll('#stToggles input').forEach((i) => i.addEventListener('change', () => {
    const k = i.dataset.k;
    if (k === 'statusMode') draft().statusMode = i.checked ? 'auto' : 'always';
    else draft()[k] = i.checked;
    live();
  }));

  // Brujula inputs
  $('cmpShow').addEventListener('change', (e) => { draft().showCompass = e.target.checked; live(); });
  $('cmpWidth').addEventListener('input', (e) => { draft().compassWidth = Number(e.target.value); live(); });
  $('cmpDegrees').addEventListener('change', (e) => { draft().compassDegrees = e.target.checked; live(); });
  $('cmpHeading').addEventListener('change', (e) => { draft().compassHeading = e.target.checked; live(); });
  $('cmpResetPos').addEventListener('click', () => { if (draft().pos) delete draft().pos.compass; live(); });

  // Admin logo inputs
  $('admLogoEnabled').addEventListener('change', (e) => { srvDraft().logoEnabled = e.target.checked; liveServer(); });
  $('admLogoSize').addEventListener('input', (e) => { srvDraft().logoSize = Number(e.target.value); liveServer(); });
  $('admLogoOpacity').addEventListener('input', (e) => { srvDraft().logoOpacity = Number(e.target.value); liveServer(); });
  $('admApplyUrl').addEventListener('click', () => {
    const url = $('admLogoUrl').value.trim();
    if (url && !/^https?:\/\/\S+$/i.test(url)) {
      return post('notify', { msg: 'Ingresa un enlace válido que empiece por http:// o https://', kind: 'error' });
    }
    srvDraft().logoUrl = url;
    if (url) srvDraft().logoEnabled = true;
    liveServer();
  });
  $('admLogoClear').addEventListener('click', () => {
    srvDraft().logoUrl = '';
    srvDraft().logoEnabled = false;
    $('admLogoUrl').value = '';
    $('admLogoFile').value = '';
    liveServer();
  });
  $('admLogoFile').addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) handleLogoFile(e.target.files[0]);
  });
  const dz = $('admDropzone');
  dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('over'));
  dz.addEventListener('drop', (e) => {
    e.preventDefault();
    dz.classList.remove('over');
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) handleLogoFile(e.dataTransfer.files[0]);
  });

  $('admSaveServer').addEventListener('click', () => {
    origServer = JSON.parse(JSON.stringify(srvDraft()));
    post('saveServerConfig', srvDraft());
  });

  $('stClose').addEventListener('click', () => closePanel(false));
  $('stCancel').addEventListener('click', () => closePanel(false));
  $('stSave').addEventListener('click', () => closePanel(true));
  $('stReset').addEventListener('click', () => {
    const keepVol = draft().musicVolume;
    state.settings = JSON.parse(JSON.stringify(window.LSN.DEFAULTS));
    state.settings.musicVolume = keepVol;
    live();
  });

  // ------------------------------------------------------------
  // Editor de posiciones (con snap al centro y coordenadas)
  // ------------------------------------------------------------
  const LABELS = {
    compass: 'Brújula',
    street: 'Calle y zona',
    status: 'Estado',
    speedo: 'Velocímetro',
    logo: 'Logo del servidor',
    air: 'Panel de vuelo',
  };
  let editing = false;
  let injected = false;
  let drag = null;

  function startEdit() {
    editing = true;
    root.hidden = true;
    hudRoot.classList.add('editing');
    $('editbar').hidden = false;
    coordsEl.textContent = '';
    document.querySelectorAll('.blk').forEach((b) => { b.dataset.label = LABELS[b.dataset.blk] || ''; });
    if ($('speedo').classList.contains('off') || !$('speedo').firstElementChild) {
      injected = true;
      emit('car', speedoDemo(0));
    }
    if ($('air').classList.contains('off')) {
      injected = true;
      emit('air', { kind: 'plane', ias: 142, gs: 138, alt: 2450, agl: 1980, vs: 650, pitch: 4, roll: -8, hdg: 284, wind: { from: 240, kn: 12 }, gear: 'UP', rpm: 0.82, fuel: 71, eng: 96, on: true, air: true, warn: {} });
    }
  }
  function endEdit() {
    editing = false;
    hudRoot.classList.remove('editing');
    guidesEl.classList.remove('snap-v', 'snap-h');
    $('editbar').hidden = true;
    if (injected) { injected = false; emit('car', false); emit('air', false); }
    root.hidden = false;
  }

  $('stMove').addEventListener('click', startEdit);
  $('cmpMoveBtn').addEventListener('click', startEdit);
  $('admMoveLogo').addEventListener('click', startEdit);
  $('editDone').addEventListener('click', endEdit);
  $('editReset').addEventListener('click', () => { draft().pos = {}; placeAll(); coordsEl.textContent = 'Restablecido'; });

  hudRoot.addEventListener('mousedown', (e) => {
    if (!editing) return;
    const blk = e.target.closest('.blk');
    if (!blk) return;
    const r = blk.getBoundingClientRect();
    blk.style.right = blk.style.bottom = '';
    blk.style.transformOrigin = 'top left';
    blk.style.left = r.left + 'px';
    blk.style.top = r.top + 'px';
    drag = { blk, dx: e.clientX - r.left, dy: e.clientY - r.top, w: r.width, h: r.height };
    e.preventDefault();
  });

  window.addEventListener('mousemove', (e) => {
    if (!drag) return;
    let x = clamp(e.clientX - drag.dx, 0, Math.max(0, window.innerWidth - drag.w));
    let y = clamp(e.clientY - drag.dy, 0, Math.max(0, window.innerHeight - drag.h));

    // Imán suave al centro horizontal y vertical (umbral 10px)
    const cx = x + drag.w / 2;
    const cy = y + drag.h / 2;
    const snapV = Math.abs(cx - window.innerWidth / 2) < 10;
    const snapH = Math.abs(cy - window.innerHeight / 2) < 10;
    if (snapV) x = window.innerWidth / 2 - drag.w / 2;
    if (snapH) y = window.innerHeight / 2 - drag.h / 2;
    guidesEl.classList.toggle('snap-v', snapV);
    guidesEl.classList.toggle('snap-h', snapH);

    drag.blk.style.left = x + 'px';
    drag.blk.style.top = y + 'px';

    const px = +(x / window.innerWidth * 100).toFixed(2);
    const py = +(y / window.innerHeight * 100).toFixed(2);
    coordsEl.textContent = `${LABELS[drag.blk.dataset.blk] || ''}: ${px}% · ${py}%`;

    if (drag.blk.dataset.blk === 'logo' && state.isAdmin && activeTab === 'admin') {
      srvDraft().logoPos = { x: px, y: py };
      if (draft().pos) delete draft().pos.logo;
    } else {
      if (!draft().pos || typeof draft().pos !== 'object' || Array.isArray(draft().pos)) draft().pos = {};
      draft().pos[drag.blk.dataset.blk] = { x: px, y: py };
    }
  });

  window.addEventListener('mouseup', () => {
    if (!drag) return;
    drag = null;
    guidesEl.classList.remove('snap-v', 'snap-h');
    placeAll();
  });

  window.LSN.settingsPanel = {
    isOpen: () => open,
    escape: () => { if (editing) endEdit(); else closePanel(false); },
  };
})();
