/* ============================================================
   LSN HUD · vista superior realista del vehiculo (CarPlay)
   Pintura metalica con el color real del auto, vidrios con
   reflejo, interior visible, faros LED y luz trasera de barra.
   Puertas, capo y maletero se abren; los vidrios bajan y el
   techo convertible deja ver los asientos.
   ============================================================ */
(() => {
  'use strict';
  const { clamp, num } = window.LSN;

  const hex = (r, g, b) => '#' + [r, g, b].map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('');
  const mix = (c, t, k) => c.map((v, i) => v + (t[i] - v) * k);   // de c hacia t
  const DEFAULT = [44, 92, 168];

  function shades(color) {
    let c = color && Array.isArray(color) ? color : color && typeof color === 'object' ? [color.r, color.g, color.b] : DEFAULT;
    c = c.map((v) => clamp(num(v), 0, 255));
    const lum = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
    // pintura muy oscura: subirla un poco para que se lea sobre fondo negro
    const base = lum < 0.08 ? mix(c, [70, 74, 82], 0.55) : c;
    return {
      edge: hex(...mix(base, [0, 0, 0], 0.62)),
      dark: hex(...mix(base, [0, 0, 0], 0.32)),
      base: hex(...base),
      light: hex(...mix(base, [255, 255, 255], 0.28)),
      gloss: hex(...mix(base, [255, 255, 255], 0.55)),
    };
  }

  // contorno del auto (mirando hacia arriba: el frente arriba)
  const BODY = 'M130 12C168 12 196 18 204 34C212 50 214 70 216 96C218 120 218 140 214 165L212 300C216 325 220 350 218 380C216 410 212 432 200 446C188 458 160 462 130 462C100 462 72 458 60 446C48 432 44 410 42 380C40 350 44 325 48 300L46 165C42 140 42 120 44 96C46 70 48 50 56 34C64 18 92 12 130 12Z';
  const HOOD = 'M68 150C64 112 62 72 67 46C77 28 101 22 130 22C159 22 183 28 193 46C198 72 196 112 192 150Z';
  const TRUNK = 'M76 374H184C192 398 196 420 192 438C178 450 156 454 130 454C104 454 82 450 68 438C64 420 68 398 76 374Z';
  // puertas: [indice, contorno, bisagra]
  const DOORS = [
    [0, 'M45 168H70V256H47Z', '45px 168px'],
    [1, 'M215 168H190V256H213Z', '215px 168px'],
    [2, 'M47 258H70V332H47C46 312 46 290 47 258Z', '47px 258px'],
    [3, 'M213 258H190V332H213C214 312 214 290 213 258Z', '213px 258px'],
  ];

  function svg(color) {
    const p = shades(color);
    const doors = DOORS.map(([i, d, o]) => `
      <g class="ct-zone ct-door" data-door="${i}">
        <path class="ct-gap" d="${d}"/>
        <g class="ct-swing" style="transform-origin:${o}">
          <path class="ct-part ct-paint" d="${d}"/>
          <path class="ct-handle" d="${i % 2 === 0 ? 'M51 ' : 'M203 '}${i < 2 ? 214 : 296}h6" />
        </g>
      </g>`).join('');

    return `<svg viewBox="0 0 260 474" class="ct-svg" aria-label="Vehículo">
      <defs>
        <linearGradient id="ctPaint" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stop-color="${p.edge}"/><stop offset=".12" stop-color="${p.dark}"/>
          <stop offset=".32" stop-color="${p.base}"/><stop offset=".5" stop-color="${p.light}"/>
          <stop offset=".68" stop-color="${p.base}"/><stop offset=".88" stop-color="${p.dark}"/>
          <stop offset="1" stop-color="${p.edge}"/>
        </linearGradient>
        <linearGradient id="ctGloss" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset=".25" stop-color="#fff" stop-opacity="0"/>
          <stop offset=".7" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".25"/>
        </linearGradient>
        <linearGradient id="ctGlass" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stop-color="#3a4a5c" stop-opacity=".92"/><stop offset=".55" stop-color="#121820" stop-opacity=".9"/>
          <stop offset="1" stop-color="#05070a" stop-opacity=".95"/>
        </linearGradient>
        <linearGradient id="ctRoofG" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stop-color="#1d2632"/><stop offset=".5" stop-color="#0a0e13"/><stop offset="1" stop-color="#05070a"/>
        </linearGradient>
        <radialGradient id="ctShadow" cx=".5" cy=".5" r=".5">
          <stop offset=".6" stop-color="#000" stop-opacity=".7"/><stop offset="1" stop-color="#000" stop-opacity="0"/>
        </radialGradient>
        <clipPath id="ctClip"><path d="${BODY}"/></clipPath>
      </defs>

      <ellipse cx="130" cy="238" rx="122" ry="240" fill="url(#ctShadow)"/>

      <!-- llantas -->
      <g class="ct-wheels">
        <rect x="33" y="74" width="20" height="56" rx="7"/><rect x="207" y="74" width="20" height="56" rx="7"/>
        <rect x="33" y="328" width="20" height="56" rx="7"/><rect x="207" y="328" width="20" height="56" rx="7"/>
      </g>

      <!-- espejos -->
      <path class="ct-paint" d="M47 172L28 166C24 165 23 175 27 177L47 182Z"/>
      <path class="ct-paint" d="M213 172L232 166C236 165 237 175 233 177L213 182Z"/>

      <!-- carroceria -->
      <path class="ct-body ct-paint" d="${BODY}"/>

      <g clip-path="url(#ctClip)">
        <!-- vano del motor (se ve con el capo abierto) -->
        <g class="ct-bay">
          <path d="${HOOD}" fill="#0b0d10"/>
          <rect x="98" y="62" width="64" height="58" rx="8" fill="#20252c" stroke="#333a44"/>
          <rect x="106" y="70" width="48" height="10" rx="3" fill="#2d343d"/>
          <rect x="106" y="86" width="48" height="10" rx="3" fill="#2d343d"/>
          <rect x="74" y="58" width="18" height="26" rx="3" fill="#1a1d22" stroke="#2c323a"/>
          <circle cx="178" cy="72" r="9" fill="#1a1d22" stroke="#2c323a"/>
          <rect x="84" y="34" width="92" height="12" rx="3" fill="#15181c"/>
        </g>
        <!-- cajuela (se ve con el maletero abierto) -->
        <path class="ct-bay" d="${TRUNK}" fill="#0b0d10"/>

        <!-- interior -->
        <g class="ct-interior">
          <rect x="60" y="196" width="140" height="140" fill="#121418"/>
          <rect x="66" y="204" width="128" height="16" rx="6" fill="#1b1e23"/>
          <circle cx="100" cy="232" r="13" fill="none" stroke="#2f343c" stroke-width="5"/>
          <rect x="82" y="244" width="38" height="40" rx="9" fill="#24282e"/><rect x="140" y="244" width="38" height="40" rx="9" fill="#24282e"/>
          <rect x="85" y="248" width="32" height="10" rx="4" fill="#2c3138"/><rect x="143" y="248" width="32" height="10" rx="4" fill="#2c3138"/>
          <rect x="124" y="244" width="12" height="44" rx="4" fill="#1b1e23"/>
          <rect x="80" y="294" width="100" height="36" rx="10" fill="#24282e"/>
        </g>
      </g>

      <!-- brillo de la pintura -->
      <path d="${BODY}" fill="url(#ctGloss)" pointer-events="none"/>

      <!-- vidrios laterales -->
      <path class="ct-side" data-w="0" d="M70 200L80 205V262H70Z"/>
      <path class="ct-side" data-w="1" d="M190 200L180 205V262H190Z"/>
      <path class="ct-side" data-w="2" d="M70 264H80V328L72 334Z"/>
      <path class="ct-side" data-w="3" d="M190 264H180V328L188 334Z"/>

      <!-- parabrisas, techo y luneta -->
      <path class="ct-glass" d="M66 154C96 146 164 146 194 154L182 205C150 199 110 199 78 205Z"/>
      <path class="ct-shine" d="M86 156L120 152L100 202L82 204Z"/>
      <g class="ct-roof">
        <path d="M80 207C110 201 150 201 180 207V328C150 333 110 333 80 328Z" fill="url(#ctRoofG)" stroke="rgba(255,255,255,.08)"/>
        <path d="M92 214L132 210L104 320L90 318Z" fill="#fff" opacity=".05"/>
      </g>
      <path class="ct-glass" d="M80 332C110 337 150 337 180 332L188 372C150 377 110 377 72 372Z"/>

      <!-- capo y maletero (se levantan) -->
      <g class="ct-zone ct-lid" data-door="4" style="transform-origin:130px 150px">
        <path class="ct-part ct-paint" d="${HOOD}"/>
        <path d="M100 40C110 70 112 110 110 146M160 40C150 70 148 110 150 146" class="ct-crease"/>
        <path d="${HOOD}" fill="url(#ctGloss)" pointer-events="none"/>
      </g>
      <g class="ct-zone ct-lid" data-door="5" style="transform-origin:130px 374px">
        <path class="ct-part ct-paint" d="${TRUNK}"/>
      </g>

      <!-- puertas -->
      ${doors}

      <!-- faros y luces -->
      <path class="ct-head" d="M60 40C70 30 84 25 100 23"/>
      <path class="ct-head" d="M200 40C190 30 176 25 160 23"/>
      <path class="ct-tail" d="M58 444C72 452 88 455 104 456"/>
      <path class="ct-tail" d="M202 444C188 452 172 455 156 456"/>
      <path class="ct-tail bar" d="M104 457H156"/>

      <text class="ct-tag" x="130" y="96">Capó</text>
      <text class="ct-tag" x="130" y="420">Maletero</text>
    </svg>`;
  }

  // aplica el estado (puertas, vidrios, techo, permisos) a un SVG ya creado
  const bit = (v, i) => (num(v) & (1 << i)) !== 0;
  function paint(host, S) {
    const key = S.color ? [S.color.r, S.color.g, S.color.b].join(',') : 'def';
    if (host._color !== key) { host._color = key; host.innerHTML = svg(S.color); }
    const ownDoor = { 0: 1, 1: 2, 2: 3 }[S.seat];
    host.querySelectorAll('.ct-zone').forEach((g) => {
      const i = Number(g.dataset.door);
      g.style.display = bit(S.doorValid, i) ? '' : 'none';
      g.classList.toggle('open', bit(S.doorOpen, i));
      g.classList.toggle('locked', !(S.seat === -1 || ownDoor === i));
    });
    host.querySelectorAll('.ct-side').forEach((w) => w.classList.toggle('down', bit(S.win, Number(w.dataset.w))));
    host.querySelector('.ct-roof').classList.toggle('open', !!S.roof);
    host.querySelector('.ct-svg').classList.toggle('lights', !!S.on);
  }

  window.LSN.carTop = { svg, paint, shades };
})();
