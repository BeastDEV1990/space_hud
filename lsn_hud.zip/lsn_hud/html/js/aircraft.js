/* ============================================================
   LSN HUD · panel de vuelo (PFD) para aviones y helicopteros
   Horizonte artificial, cinta de velocidad (nudos), cinta de
   altitud (pies) con velocidad vertical, cinta de rumbo con
   waypoint, viento, radioaltimetro y alertas.
   ============================================================ */
(() => {
  'use strict';
  const { $, clamp, num, on, sound, icons: I } = window.LSN;

  const cv = $('pfd');
  const ctx = cv.getContext('2d');
  const W = 600, H = 400;
  const ATT = { x: 150, y: 50, w: 300, h: 250, cx: 300, cy: 175 };
  const FONT = (px, w = 600) => `${w} ${px}px "Barlow Condensed", "Arial Narrow", sans-serif`;
  const C = {
    sky1: '#1d5fc4', sky2: '#4f9ae8', gnd1: '#8a5a2b', gnd2: '#5a3818', white: '#f3f6f9', yellow: '#ffd23f',
    magenta: '#ff4fd8', green: '#2ee86b', amber: '#f5a524', red: '#ff3b30', tape: 'rgba(12,14,18,.82)', cyan: '#5fe3ff',
  };

  let target = null;   // ultimo dato de Lua
  let cur = null;      // valores suavizados
  let running = false;

  const lerp = (a, b, k) => a + (b - a) * k;
  const angDiff = (a, b) => ((b - a + 540) % 360) - 180;
  const lerpAng = (a, b, k) => (a + angDiff(a, b) * k + 360) % 360;

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function text(str, x, y, { size = 16, color = C.white, align = 'center', weight = 600, base = 'middle' } = {}) {
    ctx.font = FONT(size, weight); ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = base;
    ctx.fillText(str, x, y);
  }
  function line(x0, y0, x1, y1, color = C.white, w = 2) {
    ctx.strokeStyle = color; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
  }

  // ------------------------------------------------------------
  // Horizonte artificial
  // ------------------------------------------------------------
  function drawAttitude(d) {
    const PPD = 5;
    ctx.save();
    roundRect(ATT.x, ATT.y, ATT.w, ATT.h, 16);
    ctx.clip();
    ctx.translate(ATT.cx, ATT.cy);
    ctx.rotate((-d.roll * Math.PI) / 180);
    ctx.translate(0, d.pitch * PPD);

    let g = ctx.createLinearGradient(0, -500, 0, 0);
    g.addColorStop(0, C.sky1); g.addColorStop(1, C.sky2);
    ctx.fillStyle = g; ctx.fillRect(-700, -1400, 1400, 1400);
    g = ctx.createLinearGradient(0, 0, 0, 500);
    g.addColorStop(0, C.gnd1); g.addColorStop(1, C.gnd2);
    ctx.fillStyle = g; ctx.fillRect(-700, 0, 1400, 1400);
    line(-700, 0, 700, 0, C.white, 2.5);

    // escalera de cabeceo
    for (let p = -90; p <= 90; p += 2.5) {
      if (p === 0) continue;
      const y = -p * PPD;
      if (Math.abs(y + d.pitch * PPD) > 150) continue;
      const w = p % 10 === 0 ? 46 : p % 5 === 0 ? 24 : 10;
      ctx.setLineDash(p < 0 && p % 5 === 0 ? [6, 4] : []);
      line(-w, y, w, y, C.white, p % 10 === 0 ? 2 : 1.5);
      ctx.setLineDash([]);
      if (p % 10 === 0) {
        text(String(Math.abs(p)), -w - 14, y, { size: 14 });
        text(String(Math.abs(p)), w + 14, y, { size: 14 });
      }
    }
    ctx.restore();

    // escala de alabeo (fija) e indice (gira con el horizonte)
    ctx.save();
    ctx.translate(ATT.cx, ATT.cy);
    const R = 112;
    ctx.strokeStyle = C.white; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, R, (-150 * Math.PI) / 180, (-30 * Math.PI) / 180); ctx.stroke();
    for (const a of [-60, -45, -30, -20, -10, 0, 10, 20, 30, 45, 60]) {
      const len = a === 0 ? 0 : Math.abs(a) % 30 === 0 ? 12 : 7;
      const t = ((a - 90) * Math.PI) / 180;
      if (a === 0) {
        ctx.fillStyle = C.white; ctx.beginPath();
        ctx.moveTo(0, -R); ctx.lineTo(-7, -R - 11); ctx.lineTo(7, -R - 11); ctx.closePath(); ctx.fill();
      } else {
        line(Math.cos(t) * R, Math.sin(t) * R, Math.cos(t) * (R + len), Math.sin(t) * (R + len), C.white, 2);
      }
    }
    ctx.rotate((-d.roll * Math.PI) / 180);
    ctx.fillStyle = C.yellow; ctx.beginPath();
    ctx.moveTo(0, -R + 2); ctx.lineTo(-8, -R + 14); ctx.lineTo(8, -R + 14); ctx.closePath(); ctx.fill();
    ctx.restore();

    // simbolo del avion (fijo)
    ctx.save();
    ctx.translate(ATT.cx, ATT.cy);
    ctx.fillStyle = '#111'; ctx.strokeStyle = C.yellow; ctx.lineWidth = 3;
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(s * 92, -3); ctx.lineTo(s * 38, -3); ctx.lineTo(s * 38, 12); ctx.lineTo(s * 30, 12); ctx.lineTo(s * 30, 4); ctx.lineTo(s * 92, 4);
      ctx.closePath(); ctx.fill(); ctx.stroke();
    }
    ctx.fillStyle = C.yellow; ctx.fillRect(-4, -4, 8, 8);
    ctx.restore();

    // marco
    ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1.5;
    roundRect(ATT.x, ATT.y, ATT.w, ATT.h, 16); ctx.stroke();
  }

  // ------------------------------------------------------------
  // Cintas verticales (velocidad y altitud)
  // ------------------------------------------------------------
  function drawTape({ x, w, value, ppu, minor, major, label, side, fmt, low, ground }) {
    const top = ATT.y, h = ATT.h, cy = ATT.cy;
    ctx.save();
    roundRect(x, top, w, h, 10); ctx.fillStyle = C.tape; ctx.fill();
    ctx.clip();
    // zona roja (perdida) o suelo
    if (low != null && value - low < (h / 2) / ppu) {
      const y = cy + (value - low) * ppu;
      ctx.fillStyle = 'rgba(255,59,48,.85)';
      ctx.fillRect(side === 'left' ? x + w - 7 : x, y, 7, top + h - y);
    }
    if (ground != null && value - ground < (h / 2) / ppu) {
      const y = cy + (value - ground) * ppu;
      ctx.fillStyle = 'rgba(138,90,43,.75)';
      ctx.fillRect(x, y, w, top + h - y);
      line(x, y, x + w, y, C.amber, 2);
    }
    const span = h / 2 / ppu + minor;
    const start = Math.floor((value - span) / minor) * minor;
    for (let v = start; v <= value + span; v += minor) {
      if (v < 0 && label === 'KT') continue;
      const y = cy - (v - value) * ppu;
      const isMajor = Math.abs(v % major) < 1e-6;
      const len = isMajor ? 12 : 7;
      if (side === 'left') line(x + w - len, y, x + w, y, C.white, 1.6);
      else line(x, y, x + len, y, C.white, 1.6);
      if (isMajor) text(fmt(v), side === 'left' ? x + w - 18 : x + 18, y, { size: 15, align: side === 'left' ? 'right' : 'left' });
    }
    ctx.restore();

    // caja del valor actual
    const bw = w + 8, bh = 34, bx = side === 'left' ? x - 4 : x - 4;
    ctx.fillStyle = '#05070a'; ctx.strokeStyle = C.yellow; ctx.lineWidth = 2;
    ctx.beginPath();
    if (side === 'left') {
      ctx.moveTo(bx, cy - bh / 2); ctx.lineTo(bx + bw - 10, cy - bh / 2); ctx.lineTo(bx + bw, cy); ctx.lineTo(bx + bw - 10, cy + bh / 2); ctx.lineTo(bx, cy + bh / 2);
    } else {
      ctx.moveTo(bx + bw, cy - bh / 2); ctx.lineTo(bx + 10, cy - bh / 2); ctx.lineTo(bx, cy); ctx.lineTo(bx + 10, cy + bh / 2); ctx.lineTo(bx + bw, cy + bh / 2);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    text(fmt(value, true), side === 'left' ? bx + bw / 2 - 4 : bx + bw / 2 + 4, cy + 1, { size: 22, weight: 700 });
    text(label, x + w / 2, top - 12, { size: 14, color: C.cyan });
  }

  // velocidad vertical (escala no lineal, en miles de pies/min)
  function drawVS(vs) {
    const x = 540, top = ATT.y + 20, h = ATT.h - 40, cy = ATT.cy;
    const map = (v) => Math.sign(v) * Math.sqrt(Math.min(Math.abs(v), 6000) / 6000) * (h / 2);
    ctx.fillStyle = C.tape; roundRect(x, top, 34, h, 8); ctx.fill();
    for (const v of [-6000, -2000, -1000, -500, 0, 500, 1000, 2000, 6000]) {
      const y = cy - map(v);
      line(x, y, x + (v % 1000 === 0 ? 9 : 5), y, 'rgba(255,255,255,.75)', 1.5);
      if (v && Math.abs(v) >= 1000) text(String(Math.abs(v) / 1000), x + 20, y, { size: 12, color: 'rgba(255,255,255,.75)' });
    }
    const y = cy - map(vs);
    line(x + 32, cy, x + 4, y, C.green, 3);
    if (Math.abs(vs) > 200) {
      text((vs > 0 ? '+' : '') + Math.round(vs / 10) * 10, x + 17, vs > 0 ? top - 10 : top + h + 11, { size: 13, color: C.green });
    }
  }

  // ------------------------------------------------------------
  // Cinta de rumbo
  // ------------------------------------------------------------
  function drawHeading(hdg, wpt) {
    const x = ATT.x, y = 318, w = ATT.w, h = 34, cx = ATT.cx, PPD = 4;
    ctx.save();
    roundRect(x, y, w, h, 8); ctx.fillStyle = C.tape; ctx.fill(); ctx.clip();
    const span = w / 2 / PPD + 10;
    for (let a = Math.floor((hdg - span) / 5) * 5; a <= hdg + span; a += 5) {
      const n = ((a % 360) + 360) % 360;
      const px = cx + angDiff(hdg, n) * PPD;
      const major = n % 10 === 0;
      line(px, y, px, y + (major ? 10 : 6), C.white, 1.5);
      if (major) {
        const lbl = { 0: 'N', 90: 'E', 180: 'S', 270: 'W' }[n] ?? String(n / 10);
        text(lbl, px, y + 22, { size: n % 90 === 0 ? 17 : 14, color: n % 90 === 0 ? C.white : 'rgba(255,255,255,.8)' });
      }
    }
    if (wpt) {
      const px = clamp(cx + angDiff(hdg, wpt.brg) * PPD, x + 6, x + w - 6);
      ctx.fillStyle = C.magenta; ctx.beginPath();
      ctx.moveTo(px, y + 2); ctx.lineTo(px - 7, y + 12); ctx.lineTo(px + 7, y + 12); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    // caja del rumbo
    ctx.fillStyle = '#05070a'; ctx.strokeStyle = C.yellow; ctx.lineWidth = 2;
    roundRect(cx - 28, y - 16, 56, 22, 5); ctx.fill(); ctx.stroke();
    text(String(Math.round(hdg) % 360).padStart(3, '0') + '°', cx, y - 4, { size: 18, weight: 700 });
  }

  // flecha del viento (relativa al rumbo)
  function drawWind(wind, hdg) {
    const x = 520, y = 22;
    if (!wind) return;
    text(`${String(Math.round(wind.from) % 360).padStart(3, '0')}° / ${Math.round(wind.kn)} KT`, x - 22, y, { size: 16, align: 'right' });
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(((angDiff(hdg, wind.from) + 180) * Math.PI) / 180);
    ctx.strokeStyle = C.cyan; ctx.fillStyle = C.cyan; ctx.lineWidth = 2.5;
    line(0, -10, 0, 10, C.cyan, 2.5);
    ctx.beginPath(); ctx.moveTo(0, 13); ctx.lineTo(-6, 4); ctx.lineTo(6, 4); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  // ------------------------------------------------------------
  // Alertas
  // ------------------------------------------------------------
  const WARN_ORDER = [['pullup', 'PULL UP'], ['stall', 'STALL'], ['gear', 'GEAR'], ['engine', 'ENGINE'], ['rotor', 'ROTOR'], ['fuel', 'FUEL']];
  let lastAlarm = 0;
  function drawWarnings(warn) {
    const hit = WARN_ORDER.find(([k]) => warn && warn[k]);
    if (!hit) return;
    const flash = Math.floor(Date.now() / 350) % 2 === 0;
    if (flash) {
      ctx.fillStyle = 'rgba(255,59,48,.92)';
      roundRect(ATT.cx - 78, ATT.cy + 46, 156, 38, 7); ctx.fill();
      text(hit[1], ATT.cx, ATT.cy + 66, { size: 28, weight: 800 });
    }
    const now = Date.now();
    if ((hit[0] === 'pullup' || hit[0] === 'stall') && now - lastAlarm > (hit[0] === 'stall' ? 300 : 1200)) {
      lastAlarm = now;
      sound(hit[0] === 'stall' ? 'stall' : 'alarm');
    }
  }

  // ------------------------------------------------------------
  // Cuadro completo
  // ------------------------------------------------------------
  function frame() {
    if (!running || !target) { running = false; return; }
    const t = target;
    if (!cur) cur = { ...t };
    const k = 0.35;
    cur.ias = lerp(cur.ias, num(t.ias), k);
    cur.alt = lerp(cur.alt, num(t.alt), k);
    cur.agl = lerp(cur.agl, num(t.agl), k);
    cur.vs = lerp(cur.vs, num(t.vs), 0.2);
    cur.pitch = lerp(cur.pitch, num(t.pitch), k);
    cur.roll = lerp(cur.roll, num(t.roll), k);
    cur.hdg = lerpAng(cur.hdg, num(t.hdg), k);

    ctx.clearRect(0, 0, W, H);
    // fondo del panel
    ctx.fillStyle = 'rgba(6,8,11,.78)';
    roundRect(4, 4, W - 8, H - 8, 20); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1; ctx.stroke();

    text(t.kind === 'heli' ? 'HELI' : 'AVIÓN', 26, 22, { size: 15, color: C.cyan, align: 'left' });
    text(`GS ${Math.round(num(t.gs))}`, 92, 22, { size: 16, align: 'left' });

    drawAttitude(cur);
    drawTape({
      x: 66, w: 70, value: Math.max(0, cur.ias), ppu: 3, minor: 5, major: 10, label: 'KT', side: 'left',
      fmt: (v, box) => (box ? String(Math.round(v)) : String(Math.round(v))),
      low: t.kind === 'plane' && t.air ? (window.LSN.state.config.stallKnots || 65) : null,
    });
    drawTape({
      x: 462, w: 72, value: cur.alt, ppu: 0.3, minor: 20, major: 100, label: 'FT', side: 'right',
      fmt: (v, box) => (box ? String(Math.round(v)) : String(Math.round(v))),
      ground: cur.alt - cur.agl,
    });
    drawVS(cur.vs);
    drawHeading(cur.hdg, t.wpt);
    drawWind(t.wind, cur.hdg);

    // radioaltimetro
    if (cur.agl < 2500) {
      const col = cur.agl < 200 ? C.amber : C.green;
      text(`RA ${Math.round(cur.agl)}`, ATT.cx, ATT.y + ATT.h - 18, { size: 20, weight: 700, color: col });
    }
    drawWarnings(t.warn);
    requestAnimationFrame(frame);
  }

  // ------------------------------------------------------------
  // Franja inferior (tren, motor, combustible, rotor, waypoint)
  // ------------------------------------------------------------
  const strip = $('airStrip');
  function chip(label, value, cls = '') { return `<div class="ach ${cls}"><small>${label}</small><b>${value}</b></div>`; }
  function updateStrip(d) {
    let html = '';
    if (d.gear) {
      const cls = d.gear === 'DN' ? 'g' : d.gear === 'UP' ? '' : 'a';
      const txt = d.gear === 'DN' ? 'ABAJO' : d.gear === 'UP' ? 'ARRIBA' : 'EN TRÁNSITO';
      html += `<div class="ach gear ${cls}"><small>TREN</small><span class="gbox"><i></i><i></i><i></i></span><b>${txt}</b></div>`;
    }
    if (d.rotor != null) html += chip('ROTOR', Math.round(d.rotor) + '%', d.rotor < 35 ? 'r' : d.rotor < 60 ? 'a' : '');
    html += chip('MOTOR', d.on ? Math.round(num(d.eng)) + '%' : 'APAGADO', !d.on ? 'a' : d.eng < 30 ? 'r' : d.eng < 60 ? 'a' : '');
    html += chip(d.kind === 'heli' ? 'RPM' : 'N1', Math.round(num(d.rpm) * 100) + '%');
    html += chip('COMB.', Math.round(num(d.fuel)) + '%', d.fuel < 10 ? 'r' : d.fuel < 20 ? 'a' : '');
    html += chip('VS', (d.vs > 0 ? '+' : '') + Math.round(num(d.vs) / 10) * 10 + ' ft/m');
    if (d.wpt) html += chip('WPT', `${String(Math.round(d.wpt.brg) % 360).padStart(3, '0')}° · ${d.wpt.nm.toFixed(1)} NM`, 'm');
    if (strip._h !== html) { strip._h = html; strip.innerHTML = html; }
  }

  let airAt = 0;
  setInterval(() => {
    if (target && Date.now() - airAt > 1200 && !$('root').classList.contains('editing')) {
      target = null; cur = null;
      $('air').classList.add('off');
    }
  }, 500);
  on('air', (d) => {
    $('air').classList.toggle('off', !d);
    airAt = Date.now();
    target = d || null;
    if (!d) { cur = null; return; }
    updateStrip(d);
    if (!running) { running = true; requestAnimationFrame(frame); }
  });
})();
