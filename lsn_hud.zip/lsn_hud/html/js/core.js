/* ============================================================
   LSN HUD · core: utilidades, ajustes, posiciones y sonidos
   ============================================================ */
(() => {
  'use strict';

  const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'lsn_hud';
  const IN_GAME = typeof GetParentResourceName === 'function';

  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function h(tag, attrs, html) {
    const e = document.createElement(tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') e.className = v;
      else if (k === 'dataset') Object.assign(e.dataset, v);
      else e.setAttribute(k, v);
    }
    if (html != null) e.innerHTML = html;
    return e;
  }

  function post(name, data) {
    if (!IN_GAME) { console.debug('[post]', name, data); return Promise.resolve(); }
    return fetch(`https://${RES}/${name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data || {}),
    }).catch(() => {});
  }

  const fmtInt = new Intl.NumberFormat('es', { maximumFractionDigits: 0 });
  const fmt1 = new Intl.NumberFormat('es', { minimumFractionDigits: 1, maximumFractionDigits: 1 });

  // ------------------------------------------------------------
  // Bus de eventos simple
  // ------------------------------------------------------------
  const handlers = {};
  const on = (name, fn) => { (handlers[name] ||= []).push(fn); };
  const emit = (name, data) => { (handlers[name] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(name, e); } }); };

  // ------------------------------------------------------------
  // Ajustes y posiciones
  // ------------------------------------------------------------
  const DEFAULTS = {
    speedo: 'minimal', units: 'kmh', accent: '#3fa9ff', scale: 0.9, minimapOnFoot: true,
    statusMode: 'always', showStreet: true, showCompass: true,
    compassStyle: 'minimal', compassWidth: 280, compassDegrees: true, compassHeading: true,
    showVoice: true, beltChime: true, alertSounds: true, musicVolume: 100, pos: {},
  };

  const SERVER_DEFAULTS = {
    logoEnabled: false,
    logoUrl: '',
    logoSize: 68,
    logoOpacity: 90,
    logoPos: { x: 93.5, y: 2.4 },
  };

  function normSettings(s) {
    const o = { ...DEFAULTS, ...(s && typeof s === 'object' ? s : {}) };
    const p = o.pos;
    o.pos = p && typeof p === 'object' && !Array.isArray(p) ? { ...p } : {};
    return o;
  }

  function normServer(s) {
    const o = { ...SERVER_DEFAULTS, ...(s && typeof s === 'object' ? s : {}) };
    if (!o.logoPos || typeof o.logoPos !== 'object' || !Number.isFinite(Number(o.logoPos.x))) {
      o.logoPos = { ...SERVER_DEFAULTS.logoPos };
    }
    return o;
  }

  const state = {
    settings: { ...DEFAULTS },
    server: { ...SERVER_DEFAULTS },
    isAdmin: !IN_GAME, // en navegador local permite probar el panel admin
    config: { accents: ['#3fa9ff', '#22c55e', '#f59e0b', '#ef4444', '#a78bfa', '#ec4899', '#14b8a6', '#e5e7eb'], maxLogoBytes: 240000 },
    minimap: { show: true, rect: { x: 1.5, y: 76.4, w: 14.1, h: 17.6 } },
    visible: true,
    editing: false,
  };

  function applyTheme(s) {
    const root = document.documentElement;
    root.style.setProperty('--accent', s.accent || DEFAULTS.accent);
    root.style.setProperty('--accent-rgb', hexToRgb(s.accent || DEFAULTS.accent).join(','));
  }
  function hexToRgb(hex) {
    const m = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(hex || '');
    return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [63, 169, 255];
  }

  const baseScale = () => (window.innerHeight / 1080) * num(state.settings.scale, 0.9);

  function defaultPos(name) {
    const r = state.minimap.rect;
    const s = baseScale();
    switch (name) {
      case 'compass': {
        const w = state.settings.compassStyle === 'compact' ? 110 : num(state.settings.compassWidth, 280);
        const leftPct = 50 - ((w * s) / Math.max(window.innerWidth, 1)) * 50;
        return { left: clamp(leftPct, 1, 95), top: 1.6, origin: 'top left' };
      }
      case 'street': return { left: r.x, bottom: 100 - r.y + 0.7, origin: 'bottom left' };
      case 'status': return { left: r.x + r.w + 0.7, bottom: 100 - (r.y + r.h), origin: 'bottom left' };
      case 'speedo': return { right: 2.2, bottom: 3.2, origin: 'bottom right' };
      case 'logo': {
        const lp = (state.server && state.server.logoPos) || SERVER_DEFAULTS.logoPos;
        return { left: num(lp.x, 93.5), top: num(lp.y, 2.4), origin: 'top left' };
      }
      case 'air': return { left: 50 - ((600 * s) / Math.max(window.innerWidth, 1)) * 50, bottom: 2.5, origin: 'bottom left' };
      default: return { left: 40, top: 40, origin: 'top left' };
    }
  }

  function place(el) {
    if (!el) return;
    const name = el.dataset.blk;
    const custom = state.settings.pos && state.settings.pos[name];
    const s = baseScale();
    el.style.left = el.style.right = el.style.top = el.style.bottom = '';
    if (custom && Number.isFinite(Number(custom.x)) && Number.isFinite(Number(custom.y))) {
      el.style.left = custom.x + '%';
      el.style.top = custom.y + '%';
      el.style.transformOrigin = 'top left';
    } else {
      const p = defaultPos(name);
      for (const k of ['left', 'right', 'top', 'bottom']) if (p[k] != null) el.style[k] = p[k] + '%';
      el.style.transformOrigin = p.origin;
    }
    el.style.transform = `scale3d(${s}, ${s}, 1)`;
  }
  const placeAll = () => document.querySelectorAll('.blk').forEach(place);
  let resizeRaf = 0;
  window.addEventListener('resize', () => {
    if (resizeRaf) return;
    resizeRaf = requestAnimationFrame(() => { resizeRaf = 0; placeAll(); });
  });

  // ------------------------------------------------------------
  // Sonidos (WebAudio, sin archivos)
  // ------------------------------------------------------------
  let ctx = null;
  const ac = () => (ctx ||= new (window.AudioContext || window.webkitAudioContext)());

  function tone(freq, dur, { type = 'sine', vol = 0.12, attack = 0.004, delay = 0, slide = 0 } = {}) {
    try {
      const a = ac();
      const t0 = a.currentTime + delay;
      const o = a.createOscillator();
      const g = a.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, t0);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + attack);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g).connect(a.destination);
      o.start(t0);
      o.stop(t0 + dur + 0.02);
    } catch (e) { /* sin audio */ }
  }

  const SOUNDS = {
    tick: () => tone(2400, 0.025, { type: 'square', vol: 0.05 }),
    tock: () => tone(1700, 0.03, { type: 'square', vol: 0.045 }),
    beltOn: () => { tone(900, 0.04, { type: 'square', vol: 0.06 }); tone(1300, 0.05, { type: 'square', vol: 0.05, delay: 0.05 }); },
    beltOff: () => tone(700, 0.05, { type: 'square', vol: 0.05 }),
    chime: () => { tone(1046, 0.5, { vol: 0.09 }); tone(1318, 0.6, { vol: 0.06, delay: 0.02 }); },
    cruiseOn: () => { tone(880, 0.09, { vol: 0.07 }); tone(1320, 0.12, { vol: 0.07, delay: 0.1 }); },
    cruiseOff: () => { tone(1320, 0.09, { vol: 0.07 }); tone(880, 0.12, { vol: 0.07, delay: 0.1 }); },
    ind: () => tone(1900, 0.03, { type: 'square', vol: 0.05 }),
    alarm: () => { tone(740, 0.16, { type: 'sawtooth', vol: 0.05 }); tone(740, 0.16, { type: 'sawtooth', vol: 0.05, delay: 0.22 }); },
    stall: () => tone(330, 0.12, { type: 'square', vol: 0.06 }),
    click: () => tone(1500, 0.02, { type: 'triangle', vol: 0.05 }),
  };
  function sound(name, force) {
    const s = state.settings;
    if (!force) {
      if (name === 'chime' && !s.beltChime) return;
      if (['tick', 'tock', 'ind', 'cruiseOn', 'cruiseOff', 'alarm', 'stall'].includes(name) && !s.alertSounds) return;
    }
    (SOUNDS[name] || (() => {}))();
  }

  window.LSN = {
    RES, IN_GAME, $, h, esc, clamp, num, post, on, emit, state, DEFAULTS, SERVER_DEFAULTS,
    normSettings, normServer, fmtInt, fmt1, applyTheme, place, placeAll, baseScale, sound, hexToRgb,
  };
})();
