/* ============================================================
   LSN HUD · reproductor de YouTube (oculto, optimizado)
   Sin setInterval activo cuando no hay musica reproduciendose.
   ============================================================ */
(() => {
  'use strict';
  const { num, post, on, emit } = window.LSN;

  let api = null;
  let player = null;
  let ready = false;
  let want = null;
  let loaded = null;
  let recvAt = 0;
  let lastSeek = 0;
  let endedSent = -1;

  function parseId(input) {
    const s = String(input || '').trim();
    if (/^[\w-]{11}$/.test(s)) return s;
    let url;
    try { url = new URL(/^https?:\/\//i.test(s) ? s : 'https://' + s); } catch (e) { return null; }
    const host = url.hostname.replace(/^www\.|^m\.|^music\./, '');
    let id = null;
    if (host === 'youtu.be') id = url.pathname.split('/')[1];
    else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      if (url.pathname === '/watch') id = url.searchParams.get('v');
      else {
        const m = url.pathname.match(/^\/(?:embed|shorts|live|v)\/([\w-]{11})/);
        if (m) id = m[1];
      }
    }
    return id && /^[\w-]{11}$/.test(id) ? id : null;
  }

  function loadApi() {
    if (api) return api;
    api = new Promise((resolve) => {
      if (window.YT && window.YT.Player) return resolve();
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); resolve(); };
      const s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api';
      s.onerror = () => { api = null; };
      document.head.appendChild(s);
    });
    return api;
  }

  function create() {
    return loadApi().then(() => new Promise((resolve) => {
      if (player) return resolve();
      player = new YT.Player('ytplayer', {
        width: '1', height: '1',
        host: 'https://www.youtube-nocookie.com',
        playerVars: { autoplay: 1, controls: 0, disablekb: 1, fs: 0, modestbranding: 1, playsinline: 1, rel: 0, iv_load_policy: 3, enablejsapi: 1, origin: window.location.origin },
        events: {
          onReady: () => {
            try { player.getIframe().setAttribute('referrerpolicy', 'strict-origin-when-cross-origin'); } catch (e) {}
            ready = true; resolve();
          },
          onStateChange: (e) => {
            if (e.data === YT.PlayerState.ENDED && want && loaded && want.inside && endedSent !== loaded.n) {
              endedSent = loaded.n;
              post('ytEnded', { n: loaded.n });
            }
            emit('playerState', info());
          },
          onError: () => {
            if (want && loaded && want.inside && endedSent !== loaded.n) {
              endedSent = loaded.n;
              post('ytError', { n: loaded.n });
            }
          },
        },
      });
    }));
  }

  function expected() {
    if (!want) return 0;
    if (want.p) return num(want.pos);
    return Math.max(0, num(want.now) - num(want.t) + (performance.now() - recvAt) / 1000);
  }

  let targetVol = 0;
  let curVol = -1;
  let volTimer = null;

  function stopVolRamp() {
    if (volTimer) { clearInterval(volTimer); volTimer = null; }
  }

  function ensureVolRamp() {
    if (volTimer || !player || !ready || !loaded) return;
    volTimer = setInterval(() => {
      if (!player || !ready || !loaded) return stopVolRamp();
      if (curVol < 0) curVol = targetVol;
      const diff = targetVol - curVol;
      if (Math.abs(diff) < 0.5) {
        curVol = targetVol;
        const v = Math.round(curVol);
        if (v !== player._lsnVol) { player._lsnVol = v; try { player.setVolume(v); } catch (e) {} }
        return stopVolRamp();
      }
      const step = Math.max(2, Math.abs(diff) * 0.35);
      curVol = diff > 0 ? Math.min(targetVol, curVol + step) : Math.max(targetVol, curVol - step);
      const v = Math.round(curVol);
      if (v !== player._lsnVol) { player._lsnVol = v; try { player.setVolume(v); } catch (e) {} }
    }, 60);
  }

  function apply() {
    if (!ready || !player) return;
    if (!want) {
      stopVolRamp();
      if (loaded) { try { player.stopVideo(); } catch (e) {} loaded = null; curVol = -1; }
      return;
    }
    const vol = Math.max(0, Math.min(100, num(want.vol)));
    if (!loaded || loaded.id !== want.id || loaded.n !== want.n) {
      loaded = { id: want.id, n: want.n };
      const opts = { videoId: want.id, startSeconds: Math.floor(expected()) };
      if (want.p) player.cueVideoById(opts); else player.loadVideoById(opts);
      lastSeek = performance.now();
    }
    targetVol = vol;
    ensureVolRamp();
    const st = player.getPlayerState();
    if (want.p) {
      if (st === YT.PlayerState.PLAYING || st === YT.PlayerState.BUFFERING) player.pauseVideo();
    } else {
      if (st === YT.PlayerState.PAUSED || st === YT.PlayerState.CUED) player.playVideo();
      const cur = player.getCurrentTime ? player.getCurrentTime() : 0;
      const exp = expected();
      const dur = player.getDuration ? player.getDuration() : 0;
      if (st === YT.PlayerState.PLAYING && Math.abs(cur - exp) > 3 && (!dur || exp < dur - 2) && performance.now() - lastSeek > 4000) {
        player.seekTo(exp, true);
        lastSeek = performance.now();
      }
    }
  }

  on('audio', (d) => {
    want = d && d.id ? d : null;
    recvAt = performance.now();
    if (!want) { apply(); return; }
    if (!player) create().then(apply);
    else apply();
  });

  function info() {
    if (!player || !ready || !loaded) return null;
    let title = '';
    try { title = (player.getVideoData() || {}).title || ''; } catch (e) {}
    return {
      id: loaded.id,
      title,
      cur: player.getCurrentTime ? player.getCurrentTime() : 0,
      dur: player.getDuration ? player.getDuration() : 0,
      playing: player.getPlayerState && player.getPlayerState() === 1,
    };
  }

  async function fetchTitle(id) {
    const urls = [
      `https://www.youtube.com/oembed?url=${encodeURIComponent('https://www.youtube.com/watch?v=' + id)}&format=json`,
      `https://noembed.com/embed?url=${encodeURIComponent('https://www.youtube.com/watch?v=' + id)}`,
    ];
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 1800);
    const one = (u) => fetch(u, { signal: ctl.signal }).then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j) => (j && j.title ? String(j.title).slice(0, 90) : Promise.reject()));
    try {
      return await Promise.any(urls.map(one));
    } catch (e) {
      return null;
    } finally {
      clearTimeout(timer);
      ctl.abort();
    }
  }

  window.LSN.player = { parseId, info, fetchTitle };
})();
