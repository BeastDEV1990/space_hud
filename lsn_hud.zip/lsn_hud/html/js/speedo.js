/* ============================================================
   LSN HUD · velocimetros minimalistas (optimizado)
   4 estilos: minimal, digital, analog, sport.
   Sin querySelectorAll en caliente y sin timers fuera del auto.
   ============================================================ */
(() => {
  'use strict';
  const { $, clamp, num, state, icons: I, on, sound, fmtInt, fmt1 } = window.LSN;

  const REDLINE = 7000;
  const TACH_MAX = 8000;
  const MAX_SPEED = { 'km/h': 280, mph: 180, kn: 70 };

  const realRpm = (d) => (d.on ? 800 + clamp((num(d.rpm) - 0.2) / 0.8, 0, 1) * (REDLINE - 800) : 0);

  const LAMP_ICON = {
    indL: 'indL', indR: 'indR', low: 'low', high: 'high', cruise: 'cruise', belt: 'belt', hb: 'hb',
    engine: 'engine', oil: 'oil', battery: 'battery', temp: 'temp', brakes: 'brakes', tires: 'tires',
    fuel: 'fuel', door: 'door', lock: 'lock',
  };
  const lampsHTML = (keys) => keys.map((k) => `<i class="lamp" data-l="${k}">${I[LAMP_ICON[k]]}</i>`).join('');

  let blinkOn = false;
  const blinkSlow = () => Math.floor(Date.now() / 500) % 2 === 0;

  function lampState(k, d) {
    const w = d.warn || {};
    switch (k) {
      case 'indL': return (num(d.ind) & 1) && blinkOn ? 'g' : '';
      case 'indR': return (num(d.ind) & 2) && blinkOn ? 'g' : '';
      case 'low': return d.low && !d.high ? 'g' : '';
      case 'high': return d.high ? 'b' : '';
      case 'cruise': return d.cruise != null ? 'g' : '';
      case 'belt': return d.belt === false ? (d.beltWarn && !blinkSlow() ? '' : 'r') : '';
      case 'hb': return d.hb ? 'r' : '';
      case 'door': return num(d.doors) ? 'r' : '';
      case 'lock': return d.locked ? 'w' : '';
      default: {
        const lv = num(w[k]);
        return lv >= 2 ? 'r blink' : lv === 1 ? 'a' : '';
      }
    }
  }

  // ------------------------------------------------------------
  // SVG: arcos y diales limpios
  // ------------------------------------------------------------
  const rad = (deg) => (deg * Math.PI) / 180;
  const polar = (cx, cy, r, deg) => [cx + r * Math.cos(rad(deg)), cy + r * Math.sin(rad(deg))];
  function arcPath(cx, cy, r, a0, a1) {
    const [x0, y0] = polar(cx, cy, r, a0);
    const [x1, y1] = polar(cx, cy, r, a1);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  }

  const AN = { size: 224, c: 112, r: 100, start: 135, sweep: 270 };
  const AN_LEN = AN.r * rad(AN.sweep);
  const MINI = { r: 92, a0: 62, a1: 118 };
  const miniPath = (frac) => arcPath(AN.c, AN.c, MINI.r, MINI.a1 - (MINI.a1 - MINI.a0) * clamp(frac, 0.001, 1), MINI.a1);

  function modernDial({ max, minor, major, every, red, fmt = (v) => v, mini }) {
    const { c, r, start, sweep } = AN;
    let ticks = '';
    for (let v = 0; v <= max + 1e-6; v += minor) {
      const a = start + (v / max) * sweep;
      const isMajor = Math.abs(v / major - Math.round(v / major)) < 1e-6;
      const isRed = red != null && v >= red - 1e-6;
      const [x0, y0] = polar(c, c, r - 6, a);
      const [x1, y1] = polar(c, c, r - 6 - (isMajor ? 9 : 4), a);
      ticks += `<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" class="${isMajor ? 'at-M' : 'at-m'}${isRed ? ' red' : ''}"/>`;
      if (Math.abs(v / every - Math.round(v / every)) < 1e-6) {
        const [tx, ty] = polar(c, c, r - 27, a);
        ticks += `<text x="${tx.toFixed(1)}" y="${(ty + 5).toFixed(1)}" class="at-n${isRed ? ' red' : ''}">${fmt(v)}</text>`;
      }
    }
    const ring = arcPath(c, c, r, start, start + sweep);
    const redArc = red != null ? `<path d="${arcPath(c, c, r, start + (red / max) * sweep, start + sweep)}" class="an-red"/>` : '';
    const [ex, ey] = polar(c, c, MINI.r + 1, MINI.a1 + 9);
    const [fx, fy] = polar(c, c, MINI.r + 1, MINI.a0 - 9);
    const ends = mini === 'fuel' ? ['E', 'F'] : ['C', 'H'];
    return `<svg viewBox="0 0 ${AN.size} ${AN.size}" class="an-svg">
      <path d="${ring}" class="an-ring"/>
      ${redArc}
      <path d="${ring}" class="an-prog" stroke-dasharray="${AN_LEN.toFixed(1)}" stroke-dashoffset="${AN_LEN.toFixed(1)}"/>
      ${ticks}
      <path d="${arcPath(c, c, MINI.r, MINI.a0, MINI.a1)}" class="mini-track"/>
      <path d="${miniPath(0.5)}" class="mini-fill ${mini}"/>
      <text x="${ex.toFixed(1)}" y="${(ey + 4).toFixed(1)}" class="mini-end">${ends[0]}</text>
      <text x="${fx.toFixed(1)}" y="${(fy + 4).toFixed(1)}" class="mini-end">${ends[1]}</text>
      <g class="needle" style="transform-origin:${c}px ${c}px;transform:rotate(${start + 90}deg)">
        <path d="M${c - 2.1} ${c - r * 0.45}L${c - 0.6} ${c - r + 5}L${c + 0.6} ${c - r + 5}L${c + 2.1} ${c - r * 0.45}z" class="an-needle"/>
      </g>
    </svg>`;
  }
  const needleAngle = (v, max, start = 135, sweep = 270) => start + 90 + clamp(v / max, 0, 1.03) * sweep;

  const CAR_DIAG = `<svg viewBox="0 0 70 124" class="cardiag-svg">
    <rect class="cd-tire" data-t="0" x="4" y="22" width="7" height="17" rx="2"/>
    <rect class="cd-tire" data-t="1" x="59" y="22" width="7" height="17" rx="2"/>
    <rect class="cd-tire" data-t="2" x="4" y="84" width="7" height="17" rx="2"/>
    <rect class="cd-tire" data-t="3" x="59" y="84" width="7" height="17" rx="2"/>
    <path class="cd-body" d="M20 6h30q9 0 9 12v88q0 12-9 12H20q-9 0-9-12V18q0-12 9-12z"/>
    <path class="cd-glass" d="M18 36h34l-3 12H21zM20 82h30l2 10H18z"/>
    <path class="cd-door" data-d="4" d="M17 9h36"/>
    <path class="cd-door" data-d="5" d="M17 115h36"/>
    <path class="cd-door" data-d="0" d="M11 44v22" style="transform-origin:11px 44px"/>
    <path class="cd-door" data-d="1" d="M59 44v22" style="transform-origin:59px 44px"/>
    <path class="cd-door" data-d="2" d="M11 68v20" style="transform-origin:11px 68px"/>
    <path class="cd-door" data-d="3" d="M59 68v20" style="transform-origin:59px 68px"/>
  </svg>`;

  // ------------------------------------------------------------
  // Plantillas minimalistas
  // ------------------------------------------------------------
  const DG = { cx: 130, cy: 130, r: 112, a0: 135, a1: 405 };
  const DG_LEN = DG.r * rad(DG.a1 - DG.a0);

  const TEMPLATES = {
    minimal: () => `
      <div class="sp sp-minimal">
        <div class="cardiag">${CAR_DIAG}</div>
        <div class="mn-top">
          <div class="mn-speed"><b class="spd">0</b><small class="unit">km/h</small></div>
          <span class="gear">P</span>
        </div>
        <div class="mn-bars">
          <span class="bar rpm"><b class="rpmb"></b></span>
          <div class="mn-meta">
            <div class="mn-fuel"><i>${I.fuel}</i><span class="bar fuel"><b class="fuelb"></b></span><em class="fuelv">0%</em></div>
            <span class="mn-odo"><span class="odo">—</span> <small class="du">km</small></span>
          </div>
        </div>
        <div class="mn-foot">
          <div class="lamps hide-off">${lampsHTML(['indL', 'low', 'high', 'cruise', 'belt', 'hb', 'engine', 'oil', 'battery', 'temp', 'brakes', 'tires', 'fuel', 'door', 'lock', 'indR'])}</div>
        </div>
        <div class="cruise-tag"></div>
      </div>`,

    digital: () => `
      <div class="sp sp-digital">
        <div class="cardiag">${CAR_DIAG}</div>
        <div class="row lamps top">${lampsHTML(['indL', 'low', 'high', 'cruise', 'belt', 'hb', 'indR'])}</div>
        <div class="dg-dial">
          <svg viewBox="0 0 260 260">
            <path d="${arcPath(DG.cx, DG.cy, DG.r, DG.a0, DG.a1)}" class="dg-track"/>
            <path d="${arcPath(DG.cx, DG.cy, DG.r, DG.a0 + (REDLINE / TACH_MAX) * 270, DG.a1)}" class="dg-red"/>
            <path d="${arcPath(DG.cx, DG.cy, DG.r, DG.a0, DG.a1)}" class="dg-fill" stroke-dasharray="${DG_LEN.toFixed(1)}" stroke-dashoffset="${DG_LEN.toFixed(1)}"/>
          </svg>
          <div class="dg-center">
            <span class="dg-gear gear">P</span>
            <b class="spd">0</b>
            <small class="unit">km/h</small>
            <span class="dg-rpm"><b class="rpmv">0</b> rpm</span>
          </div>
          <div class="cruise-tag"></div>
        </div>
        <div class="dg-bars">
          <div class="mini"><i>${I.fuel}</i><span class="bar"><b class="fuelb"></b></span><em class="fuelv">0%</em></div>
          <div class="mini"><i>${I.temp}</i><span class="bar"><b class="tempb"></b></span><em class="tempv">—</em></div>
        </div>
        <div class="row lamps warn hide-off">${lampsHTML(['engine', 'oil', 'battery', 'temp', 'brakes', 'tires', 'fuel', 'door', 'lock'])}</div>
        <div class="odo-line"><span><b class="odo">—</b> <small class="du">km</small></span><span>TRIP <b class="trip">0,0</b></span></div>
      </div>`,

    analog: (unit) => {
      const max = MAX_SPEED[unit] || 280;
      const minor = unit === 'kn' ? 5 : 10;
      const major = unit === 'kn' ? 10 : 20;
      const every = unit === 'kn' ? 10 : unit === 'mph' ? 20 : 40;
      return `
      <div class="sp sp-analog">
        <div class="an-dial tach">
          ${modernDial({ max: 8, minor: 0.5, major: 1, every: 1, red: 7, mini: 'temp' })}
          <div class="an-center"><b class="gear">P</b><small>x1000</small></div>
          <i class="an-mico">${I.temp}</i>
        </div>
        <div class="an-mid">
          <div class="an-arrows"><i class="lamp" data-l="indL">${I.indL}</i><i class="lamp" data-l="indR">${I.indR}</i></div>
          <div class="lamps an-top hide-off">${lampsHTML(['low', 'high', 'cruise', 'belt', 'hb', 'door'])}</div>
          <div class="an-slot"><div class="cardiag">${CAR_DIAG}</div><div class="cruise-tag"></div></div>
          <div class="an-info">
            <div><small>ODO</small><b class="odo">—</b><small class="du">km</small></div>
            <div><small>TRIP</small><b class="trip">0,0</b><small class="du">km</small></div>
          </div>
          <div class="lamps an-warn hide-off">${lampsHTML(['engine', 'oil', 'battery', 'temp', 'brakes', 'tires', 'fuel', 'lock'])}</div>
        </div>
        <div class="an-dial speed">
          ${modernDial({ max, minor, major, every, mini: 'fuel' })}
          <div class="an-center"><b class="spd">0</b><small class="unit">km/h</small></div>
          <i class="an-mico">${I.fuel}</i>
        </div>
      </div>`;
    },

    sport: () => {
      let segs = '';
      for (let i = 0; i < 20; i++) segs += `<i class="seg${i >= 17 ? ' r' : i >= 13 ? ' y' : ''}"></i>`;
      return `
      <div class="sp sp-sport">
        <div class="cardiag">${CAR_DIAG}</div>
        <div class="st-shift">${segs}</div>
        <div class="st-main">
          <div class="st-speed"><b class="spd">0</b><small class="unit">km/h</small></div>
          <div class="st-gear"><b class="gear">P</b></div>
          <div class="st-right">
            <div class="st-rpm"><b class="rpmv">0</b><small>rpm</small></div>
            <div class="st-bar"><i>${I.fuel}</i><span class="bar"><b class="fuelb"></b></span></div>
            <div class="st-bar"><i>${I.temp}</i><span class="bar"><b class="tempb"></b></span></div>
          </div>
        </div>
        <div class="st-foot">
          <div class="lamps hide-off">${lampsHTML(['indL', 'indR', 'low', 'high', 'cruise', 'belt', 'hb', 'engine', 'oil', 'battery', 'temp', 'brakes', 'tires', 'fuel', 'door'])}</div>
          <div class="st-odo"><span class="odo">—</span> <small class="du">km</small></div>
        </div>
        <div class="cruise-tag"></div>
      </div>`;
    },
  };

  // ------------------------------------------------------------
  // Instancia (nodos cacheados para cero búsquedas DOM por frame)
  // ------------------------------------------------------------
  class Speedo {
    constructor(host, style, unit = 'km/h') {
      this.host = host;
      this.style = TEMPLATES[style] ? style : 'minimal';
      this.unit = unit;
      this.build();
    }

    build() {
      this.host.innerHTML = TEMPLATES[this.style](this.unit);
      const q = (sel) => [...this.host.querySelectorAll(sel)];
      this.el = {
        spd: q('.spd'), unit: q('.unit'), gear: q('.gear'), rpmv: q('.rpmv'), rpmb: q('.rpmb'),
        fuelb: q('.fuelb'), fuelv: q('.fuelv'), tempb: q('.tempb'), tempv: q('.tempv'),
        odo: q('.odo'), trip: q('.trip'), du: q('.du'), cruise: q('.cruise-tag'),
        fill: this.host.querySelector('.dg-fill'), segs: q('.seg'),
        tachNeedle: this.host.querySelector('.tach .needle'), speedNeedle: this.host.querySelector('.speed .needle'),
        tachProg: this.host.querySelector('.tach .an-prog'), speedProg: this.host.querySelector('.speed .an-prog'),
        tempArc: this.host.querySelector('.mini-fill.temp'), fuelArc: this.host.querySelector('.mini-fill.fuel'),
        lamps: q('.lamp'),
        diag: this.host.querySelector('.cardiag'),
        diagDoors: q('.cd-door'),
        diagTires: q('.cd-tire'),
      };
      this.root = this.host.firstElementChild;
      this.prevDiagKey = '';
      this.prevFuel = -1;
      this.prevTemp = null;
    }

    set(list, text) {
      for (let i = 0; i < list.length; i++) {
        if (list[i].textContent !== text) list[i].textContent = text;
      }
    }

    update(d) {
      if (!d) return;
      const unit = d.unit || 'km/h';
      if (this.style === 'analog' && unit !== this.unit) { this.unit = unit; this.build(); }
      const e = this.el;
      const spd = Math.max(0, Math.round(num(d.spd)));
      const rpm = realRpm(d);
      const rpmFrac = clamp(rpm / TACH_MAX, 0, 1);

      this.set(e.spd, String(spd));
      this.set(e.unit, unit);
      this.set(e.gear, d.gear || 'N');
      if (e.rpmv.length) this.set(e.rpmv, fmtInt.format(Math.round(rpm / 50) * 50));
      for (let i = 0; i < e.rpmb.length; i++) {
        e.rpmb[i].style.transform = `scaleX(${rpmFrac.toFixed(3)})`;
      }

      const fuel = clamp(num(d.fuel), 0, 100);
      if (Math.abs(fuel - this.prevFuel) >= 0.4) {
        this.prevFuel = fuel;
        for (let i = 0; i < e.fuelb.length; i++) {
          e.fuelb[i].style.transform = `scaleX(${(fuel / 100).toFixed(3)})`;
          e.fuelb[i].classList.toggle('low', fuel < 15);
        }
        this.set(e.fuelv, Math.round(fuel) + '%');
        if (e.fuelArc) {
          e.fuelArc.setAttribute('d', miniPath(fuel / 100));
          e.fuelArc.classList.toggle('low', fuel < 15);
        }
      }

      const hasTemp = d.temp != null;
      const tempRounded = hasTemp ? Math.round(num(d.temp)) : null;
      if (tempRounded !== this.prevTemp) {
        this.prevTemp = tempRounded;
        const tFrac = hasTemp ? clamp((num(d.temp) - 50) / 80, 0, 1) : 0.5;
        for (let i = 0; i < e.tempb.length; i++) {
          e.tempb[i].style.transform = `scaleX(${tFrac.toFixed(3)})`;
          e.tempb[i].classList.toggle('hot', hasTemp && d.temp > 105);
          e.tempb[i].classList.toggle('na', !hasTemp);
        }
        this.set(e.tempv, hasTemp ? tempRounded + '°' : '—');
        if (e.tempArc) {
          e.tempArc.setAttribute('d', miniPath(tFrac));
          e.tempArc.classList.toggle('hot', hasTemp && d.temp > 105);
          e.tempArc.classList.toggle('na', !hasTemp);
        }
      }

      const du = d.dist || 'km';
      this.set(e.du, du);
      this.set(e.odo, d.km != null ? fmtInt.format(Math.floor(d.km)) : '—');
      this.set(e.trip, fmt1.format(num(d.trip)));

      const cr = d.cruise != null ? `${I.cruise}<b>${Math.round(d.cruise)}</b>` : '';
      for (let i = 0; i < e.cruise.length; i++) {
        const c = e.cruise[i];
        if (c._v !== cr) { c._v = cr; c.innerHTML = cr; c.classList.toggle('on', !!cr); }
      }

      if (e.fill) e.fill.style.strokeDashoffset = (DG_LEN * (1 - rpmFrac)).toFixed(1);
      if (this.root) this.root.classList.toggle('redline', rpm >= REDLINE * 0.97);
      if (e.segs.length) {
        const lit = Math.round(rpmFrac * e.segs.length);
        const flash = rpm >= REDLINE * 0.97 && blinkSlow();
        for (let i = 0; i < e.segs.length; i++) e.segs[i].classList.toggle('on', i < lit && !flash);
      }
      if (e.tachNeedle) e.tachNeedle.style.transform = `rotate(${needleAngle(rpm / 1000, 8).toFixed(1)}deg)`;
      if (e.speedNeedle) e.speedNeedle.style.transform = `rotate(${needleAngle(num(d.spd), MAX_SPEED[unit] || 280).toFixed(1)}deg)`;
      const sFrac = clamp(num(d.spd) / (MAX_SPEED[unit] || 280), 0, 1);
      if (e.tachProg) e.tachProg.style.strokeDashoffset = (AN_LEN * (1 - rpmFrac)).toFixed(1);
      if (e.speedProg) e.speedProg.style.strokeDashoffset = (AN_LEN * (1 - sFrac)).toFixed(1);

      // Testigos (sin querySelectorAll)
      for (let i = 0; i < e.lamps.length; i++) {
        const el = e.lamps[i];
        const s = lampState(el.dataset.l, d);
        if (el._s !== s) { el._s = s; el.className = 'lamp' + (s ? ' on ' + s : ''); }
      }

      // Diagrama puertas/llantas (solo si cambia)
      if (e.diag) {
        const doors = num(d.doors);
        const tires = num(d.tires);
        const diagKey = `${d.kind}:${doors}:${tires}`;
        if (diagKey !== this.prevDiagKey) {
          this.prevDiagKey = diagKey;
          e.diag.classList.toggle('show', d.kind === 'car' && (doors !== 0 || tires !== 0));
          for (let i = 0; i < e.diagDoors.length; i++) {
            const p = e.diagDoors[i];
            p.classList.toggle('open', (doors & (1 << Number(p.dataset.d))) !== 0);
          }
          for (let i = 0; i < e.diagTires.length; i++) {
            const p = e.diagTires[i];
            p.classList.toggle('burst', (tires & (1 << Number(p.dataset.t))) !== 0);
          }
        }
      }

      if (this.root) this.root.classList.toggle('engine-off', !d.on);
    }
  }

  // ------------------------------------------------------------
  // Velocimetro del HUD (timer activo SOLO dentro del vehiculo)
  // ------------------------------------------------------------
  const host = $('speedo');
  let main = null;
  let last = null;
  let lastAt = 0;
  let blinkTimer = null;
  let tickTock = false;
  let beltSince = 0;
  let lastChime = 0;

  function stopBlinkTimer() {
    if (blinkTimer) { clearInterval(blinkTimer); blinkTimer = null; }
    blinkOn = false;
    beltSince = 0;
  }

  function startBlinkTimer() {
    if (blinkTimer) return;
    blinkTimer = setInterval(() => {
      const d = last;
      const active = d && Date.now() - lastAt < 1500;
      if (!active) {
        if (!document.getElementById('root').classList.contains('editing')) {
          last = null;
          host.classList.add('off');
          stopBlinkTimer();
        }
        return;
      }
      const ind = num(d.ind);
      if (ind) {
        blinkOn = !blinkOn;
        tickTock = !tickTock;
        sound(tickTock ? 'tick' : 'tock');
      } else {
        blinkOn = false;
      }
      if (d.beltWarn) {
        const now = Date.now();
        if (!beltSince) beltSince = now;
        if (now - beltSince < 60000 && now - lastChime > 1600) { lastChime = now; sound('chime'); }
      } else {
        beltSince = 0;
      }
      if (main && (ind || d.beltWarn)) main.update(d);
    }, 400);
  }

  function ensure() {
    const style = state.settings.speedo;
    if (!main || main.style !== style) {
      main = new Speedo(host, style, last && last.unit);
      if (last) main.update(last);
    }
  }
  on('settings', () => { ensure(); if (last) main.update(last); });

  on('car', (d) => {
    host.classList.toggle('off', !d);
    last = d || null;
    if (!d) { stopBlinkTimer(); return; }
    lastAt = Date.now();
    ensure();
    main.update(d);
    startBlinkTimer();
  });

  on('sound', (name) => sound(name));

  window.LSN.Speedo = Speedo;
  window.LSN.speedoDemo = (t) => {
    const k = (Math.sin(t / 1400) + 1) / 2;
    return {
      kind: 'car', spd: 40 + k * 90, unit: 'km/h', rpm: 0.3 + k * 0.62, gear: String(2 + Math.round(k * 3)),
      fuel: 64, eng: 92, body: 88, on: true, low: true, high: false, ind: 0, cruise: null, belt: true,
      hb: false, locked: false, doors: 0, tires: 0, km: 23481.6 + t / 50000, trip: 12.4, dist: 'km', temp: 88,
      warn: { oil: 1 }, drv: true,
    };
  };
})();
