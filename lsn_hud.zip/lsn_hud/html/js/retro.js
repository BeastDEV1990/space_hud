/* ============================================================
   LSN HUD · radio de epoca (autos viejos)
   En vez de CarPlay: radio cromada con dial iluminado, perillas,
   teclas mecanicas y casetera; abajo, panel de interruptores
   para motor, seguro, luces, puertas, vidrios y asientos.
   Usa los mismos datos y las mismas acciones que CarPlay.
   ============================================================ */
(() => {
  'use strict';
  const { $, esc, clamp, num, post, state, sound } = window.LSN;

  const root = $('retro');
  let S = null;
  let recvAt = 0;
  const bit = (v, i) => (num(v) & (1 << i)) !== 0;

  // ------------------------------------------------------------
  // Esqueleto
  // ------------------------------------------------------------
  const FM = [88, 92, 96, 100, 104, 108];
  const AM = [54, 60, 70, 80, 100, 120, 140, 160];
  const scale = (vals) => vals.map((v, i) => `<span style="left:${(i / (vals.length - 1)) * 100}%">${v}</span>`).join('');
  const sw = (act, label, i, cls = '') =>
    `<button type="button" class="rt-sw ${cls}" data-act="${act}"${i != null ? ` data-i="${i}"` : ''}><i class="pl"></i><i class="base"><i class="lever"></i></i><span>${label}</span></button>`;

  root.innerHTML = `
    <div class="rt" role="dialog" aria-label="Radio del vehículo">
      <div class="rt-dash">
        <div class="rt-unit">
          <div class="rt-knob" id="rtVol" title="Volumen (rueda del mouse o arrastra)"><i class="cap"><i class="mark"></i></i><span>VOLUMEN</span></div>
          <div class="rt-center">
            <div class="rt-window" id="rtWindow">
              <div class="rt-scale fm"><b>FM</b><div class="nums">${scale(FM)}</div><small>MHz</small></div>
              <div class="rt-ticks"></div>
              <div class="rt-scale am"><b>AM</b><div class="nums">${scale(AM)}</div><small>KHz</small></div>
              <i class="rt-pointer" id="rtPointer"></i>
              <i class="rt-stereo" id="rtStereo">STEREO</i>
            </div>
            <div class="rt-keys">
              <button type="button" class="rt-key" data-radio="stop" title="Expulsar el casete">⏏<span>EXPULSAR</span></button>
              <button type="button" class="rt-key" data-radio="toggle" id="rtPlay" title="Reproducir / pausa">▶ ❚❚<span>PLAY</span></button>
              <button type="button" class="rt-key" data-radio="next" id="rtNext" title="Siguiente casete">▶▶<span>AVANZAR</span></button>
              <button type="button" class="rt-key" data-radio="clear" title="Vaciar la guantera">✕<span>BORRAR</span></button>
            </div>
          </div>
          <div class="rt-knob tune" id="rtTune" title="Siguiente casete"><i class="cap"><i class="mark"></i></i><span>SINTONÍA</span></div>
        </div>

        <div class="rt-deck">
          <div class="rt-slot" id="rtSlot">
            <div class="cassette" id="rtCass">
              <div class="c-label"><b id="rtTitle">—</b><small id="rtSub">LADO A</small></div>
              <div class="c-win"><i class="reel l"></i><i class="tape"></i><i class="reel r"></i></div>
            </div>
            <div class="rt-empty" id="rtEmpty">SIN CASETE</div>
          </div>
          <div class="rt-side">
            <form class="rt-load" id="rtForm" autocomplete="off">
              <input id="rtUrl" type="text" placeholder="Pega un link de YouTube…" spellcheck="false" maxlength="200">
              <button type="submit" class="rt-btn">INSERTAR</button>
              <button type="button" class="rt-btn" id="rtQueueBtn">A LA GUANTERA</button>
            </form>
            <div class="rt-glove"><b>Guantera</b><ol id="rtQueue"></ol></div>
            <p class="rt-note" id="rtNote" hidden></p>
          </div>
        </div>
      </div>

      <div class="rt-panel">
        <div class="rt-group"><h5>MANDOS</h5><div class="rt-row">
          ${sw('engine', 'MOTOR')}${sw('lock', 'SEGURO')}${sw('belt', 'CINTURÓN')}${sw('int', 'LUZ INT.')}
          ${sw('ind', '◀ DIR.', 1, 'g')}${sw('ind', 'EMERG.', 3, 'r')}${sw('ind', 'DIR. ▶', 2, 'g')}${sw('roof', 'CAPOTA', null, 'roof')}
        </div></div>
        <div class="rt-group"><h5>PUERTAS</h5><div class="rt-row" id="rtDoors"></div></div>
        <div class="rt-group"><h5>VIDRIOS</h5><div class="rt-row" id="rtWins"></div></div>
        <div class="rt-group"><h5>ASIENTO</h5><div class="rt-row" id="rtSeats"></div></div>
      </div>

      <div class="rt-foot">
        <label class="rt-me">MI VOLUMEN <input type="range" min="0" max="100" step="1" id="rtMe"><output id="rtMeV">100</output></label>
        <span class="rt-who" id="rtWho"></span>
        <button type="button" class="rt-btn close" id="rtClose">CERRAR</button>
      </div>
    </div>`;

  // marcas del dial
  (() => {
    let t = '';
    for (let i = 0; i <= 40; i++) t += `<i style="left:${(i / 40) * 100}%" class="${i % 5 === 0 ? 'M' : ''}"></i>`;
    root.querySelector('.rt-ticks').innerHTML = t;
  })();

  // ------------------------------------------------------------
  // Pintar
  // ------------------------------------------------------------
  const DOOR_LABEL = ['DEL. IZQ.', 'DEL. DER.', 'TRAS. IZQ.', 'TRAS. DER.', 'CAPÓ', 'MALETERO'];
  const WIN_LABEL = ['DEL. IZQ.', 'DEL. DER.', 'TRAS. IZQ.', 'TRAS. DER.'];
  const SEAT_LABEL = ['CONDUCTOR', 'COPILOTO', 'TRAS. IZQ.', 'TRAS. DER.'];
  const setHTML = (el, html) => { if (el._h !== html) { el._h = html; el.innerHTML = html; } };

  function setSw(sel, on, disabled) {
    root.querySelectorAll(sel).forEach((b) => { b.classList.toggle('on', !!on); b.disabled = !!disabled; });
  }

  function paintControls() {
    const drv = S.drv;
    const own = (i) => S.seat === -1 || ({ 0: 1, 1: 2, 2: 3 })[S.seat] === i;
    setSw('.rt-panel [data-act="engine"]', S.on, !drv);
    setSw('.rt-panel [data-act="lock"]', S.locked, false);
    setSw('.rt-panel [data-act="belt"]', S.belt, !S.beltable);
    setSw('.rt-panel [data-act="int"]', S.int, !(S.seat === -1 || S.seat === 0));
    setSw('.rt-panel [data-act="ind"][data-i="1"]', S.ind === 1, !drv);
    setSw('.rt-panel [data-act="ind"][data-i="3"]', S.ind === 3, !drv);
    setSw('.rt-panel [data-act="ind"][data-i="2"]', S.ind === 2, !drv);
    const roof = root.querySelector('.rt-panel .roof');
    roof.hidden = !S.convertible;
    setSw('.rt-panel .roof', S.roof, !drv);

    let doors = '';
    for (let i = 0; i < 6; i++) {
      if (!bit(S.doorValid, i)) continue;
      doors += sw('door', DOOR_LABEL[i], i, (bit(S.doorOpen, i) ? 'on' : '') + (own(i) ? '' : ' dis'));
    }
    setHTML($('rtDoors'), doors || '<em class="rt-none">—</em>');
    let wins = '';
    for (let i = 0; i < 4; i++) {
      if (!bit(S.doorValid, i)) continue;
      wins += sw('win', WIN_LABEL[i], i, 'crank' + (bit(S.win, i) ? ' on' : '') + (own(i) ? '' : ' dis'));
    }
    setHTML($('rtWins'), wins || '<em class="rt-none">—</em>');
    let seats = '';
    for (let i = 0; i < num(S.seats); i++) {
      const seat = i - 1;
      const me = seat === S.seat;
      const free = bit(S.seatFree, i);
      seats += `<button type="button" class="rt-push${me ? ' on' : ''}" data-act="seat" data-i="${seat}" ${me || !free ? 'disabled' : ''}>${SEAT_LABEL[i] || 'ASIENTO ' + (i + 1)}</button>`;
    }
    setHTML($('rtSeats'), seats);
    root.querySelectorAll('.rt-sw.dis').forEach((b) => { b.disabled = true; });
    $('rtWho').textContent = S.seat === -1 ? 'Conductor' : S.seat === 0 ? 'Copiloto' : 'Pasajero';
  }

  function radioPos() {
    const r = S && S.radio;
    if (!r) return 0;
    if (r.p) return num(r.pos);
    return Math.max(0, num(S.now) - num(r.t) + (performance.now() - recvAt) / 1000);
  }

  function paintMusic() {
    if (!S) return;
    const r = S.radio;
    const p = window.LSN.player.info();
    const same = r && p && p.id === r.id;
    const title = (r && (r.title || (same && p.title))) || 'Casete sin nombre';
    const dur = same ? p.dur : 0;
    const pos = radioPos();
    const can = !!S.canRadio;

    // dial: con la llave puesta se ilumina; la aguja avanza con la cancion
    $('rtWindow').classList.toggle('lit', !!S.on || !!r);
    $('rtStereo').classList.toggle('on', !!r && !r.p);
    const frac = r ? (dur ? clamp(pos / dur, 0, 1) : (pos % 240) / 240) : 0;
    $('rtPointer').style.left = (8.8 + frac * 82.4).toFixed(2) + '%';

    // casete
    $('rtCass').hidden = !r;
    $('rtEmpty').hidden = !!r;
    $('rtCass').classList.toggle('playing', !!r && !r.p);
    $('rtTitle').textContent = title;
    $('rtSub').textContent = r ? (r.p ? 'EN PAUSA' : (dur ? `${mm(pos)} / ${mm(dur)}` : 'LADO A')) : '';
    $('rtPlay').classList.toggle('down', !!r && !r.p);

    // perilla de volumen
    const vol = r ? num(r.vol, 60) : 60;
    if (!dragging) setKnob($('rtVol'), vol);

    root.querySelectorAll('.rt-key, #rtVol, #rtTune').forEach((el) => { el.classList.toggle('dis', !can); });
    root.querySelectorAll('.rt-key').forEach((k) => { k.disabled = !can || (!r && k.dataset.radio !== 'clear'); });
    $('rtNext').disabled = !can || !r || !(r.q && r.q.length);
    $('rtUrl').disabled = !can;
    root.querySelectorAll('#rtForm button').forEach((b) => { b.disabled = !can; });
    const note = $('rtNote');
    note.hidden = can;
    note.textContent = !S.hasRadio ? 'Este vehículo no tiene radio.' : 'Solo el conductor y el copiloto manejan la radio.';

    const q = (r && r.q) || [];
    setHTML($('rtQueue'), q.length
      ? q.map((it, i) => `<li><span>${esc(it.title || 'Casete sin nombre')}</span>${can ? `<button type="button" class="x" data-remove="${i + 1}" aria-label="Quitar">✕</button>` : ''}</li>`).join('')
      : '<li class="empty">Vacía. Usa "A la guantera" para dejar casetes en cola.</li>');

    const me = $('rtMe');
    if (document.activeElement !== me) { me.value = num(state.settings.musicVolume, 100); $('rtMeV').textContent = me.value; }
  }
  const mm = (s) => { s = Math.max(0, Math.floor(num(s))); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

  // ------------------------------------------------------------
  // Perillas
  // ------------------------------------------------------------
  function setKnob(el, v) {
    el.querySelector('.cap').style.transform = `rotate(${-135 + clamp(v, 0, 100) * 2.7}deg)`;
    el._v = v;
  }
  let dragging = false;
  let volTimer = null;
  function changeVol(v) {
    if (!S || !S.canRadio || !S.radio) return;
    v = Math.round(clamp(v, 0, 100));
    setKnob($('rtVol'), v);
    clearTimeout(volTimer);
    volTimer = setTimeout(() => post('radio', { cmd: 'vol', arg: v }), 180);
  }
  const vol = $('rtVol');
  vol.addEventListener('wheel', (e) => { e.preventDefault(); changeVol(num(vol._v, 60) + (e.deltaY < 0 ? 5 : -5)); }, { passive: false });
  vol.addEventListener('mousedown', (e) => {
    if (!S || !S.canRadio) return;
    dragging = true;
    const y0 = e.clientY;
    const v0 = num(vol._v, 60);
    const move = (ev) => changeVol(v0 + (y0 - ev.clientY) * 0.6);
    const up = () => { dragging = false; window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  });
  const tune = $('rtTune');
  let tuneAngle = 0;
  function tuneNext() {
    if (!S || !S.canRadio || !S.radio || !(S.radio.q && S.radio.q.length)) return;
    tuneAngle += 40;
    tune.querySelector('.cap').style.transform = `rotate(${tuneAngle}deg)`;
    sound('click', true);
    post('radio', { cmd: 'next' });
  }
  tune.addEventListener('click', tuneNext);
  tune.addEventListener('wheel', (e) => { e.preventDefault(); if (e.deltaY < 0) tuneNext(); }, { passive: false });

  // ------------------------------------------------------------
  // Clics
  // ------------------------------------------------------------
  root.addEventListener('click', (e) => {
    const act = e.target.closest('[data-act]');
    if (act && !act.disabled) {
      sound('click', true);
      post('vehAction', { act: act.dataset.act, i: act.dataset.i != null ? Number(act.dataset.i) : undefined });
      return;
    }
    const rb = e.target.closest('[data-radio]');
    if (rb && !rb.disabled) { sound('click', true); post('radio', { cmd: rb.dataset.radio }); return; }
    const rm = e.target.closest('[data-remove]');
    if (rm) { post('radio', { cmd: 'remove', arg: Number(rm.dataset.remove) }); }
  });

  async function submit(cmd) {
    const input = $('rtUrl');
    const id = window.LSN.player.parseId(input.value);
    if (!id) { post('notify', { msg: state.config.text?.badLink || 'Ese link no es de YouTube', kind: 'error' }); return; }
    input.value = '';
    const title = await window.LSN.player.fetchTitle(id);
    post('radio', { cmd, arg: id, title });
  }
  $('rtForm').addEventListener('submit', (e) => { e.preventDefault(); submit('play'); });
  $('rtQueueBtn').addEventListener('click', () => submit('queue'));

  let meTimer = null;
  $('rtMe').addEventListener('input', (e) => {
    $('rtMeV').textContent = e.target.value;
    state.settings.musicVolume = Number(e.target.value);
    clearTimeout(meTimer);
    meTimer = setTimeout(() => post('saveSettings', state.settings), 300);
  });

  // ------------------------------------------------------------
  // API para carplay.js (que decide si se muestra esta o CarPlay)
  // ------------------------------------------------------------
  window.LSN.retro = {
    show(st, at, tab) {
      S = st; recvAt = at;
      root.hidden = false;
      paintControls(); paintMusic();
      if (tab === 'music') setTimeout(() => $('rtUrl').focus(), 50);
    },
    paint(st, at) { S = st; recvAt = at; if (!root.hidden) { paintControls(); paintMusic(); } },
    tick() { if (!root.hidden) paintMusic(); },
    hide() { root.hidden = true; },
    onClose(fn) { $('rtClose').addEventListener('click', fn); },
  };
})();
