/* ============================================================
   LSN HUD · iconos SVG (dibujados para el HUD, sin dependencias)
   ============================================================ */
(() => {
  'use strict';
  const s = (vb, body) => `<svg viewBox="${vb}" aria-hidden="true">${body}</svg>`;
  const S = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';

  const I = {
    // ---------- estado del jugador ----------
    heart: s('0 0 24 24', '<path fill="currentColor" d="M12 21s-7.5-4.6-9.6-9.3C.9 8.3 2.9 4.5 6.6 4.5c2.1 0 3.6 1.1 4.4 2.5.8-1.4 2.3-2.5 4.4-2.5 3.7 0 5.7 3.8 4.2 7.2C19.5 16.4 12 21 12 21z"/>'),
    shield: s('0 0 24 24', '<path fill="currentColor" d="M12 2.5l8 3v6.2c0 4.9-3.4 8.6-8 9.8-4.6-1.2-8-4.9-8-9.8V5.5z"/>'),
    food: s('0 0 24 24', '<path fill="currentColor" d="M4 10.5C4 6.9 7.6 4 12 4s8 2.9 8 6.5H4z"/><rect fill="currentColor" x="3" y="12" width="18" height="2.6" rx="1.3"/><path fill="currentColor" d="M4 16.4h16c0 2-1.6 3.6-3.6 3.6H7.6C5.6 20 4 18.4 4 16.4z"/>'),
    drop: s('0 0 24 24', '<path fill="currentColor" d="M12 2.8s6.5 7.2 6.5 11.6A6.5 6.5 0 0 1 5.5 14.4C5.5 10 12 2.8 12 2.8z"/>'),
    oxygen: s('0 0 24 24', '<circle fill="currentColor" cx="8" cy="15" r="4.5"/><circle fill="currentColor" cx="16.5" cy="8.5" r="3.2"/><circle fill="currentColor" cx="17" cy="17.5" r="2"/>'),
    run: s('0 0 24 24', '<circle fill="currentColor" cx="14.5" cy="4" r="2.2"/><path ' + S + ' d="M9 21l3-6 3 2v4M7 12l3-4h4l2 3 3 1M10 8l-1 5"/>'),
    brain: s('0 0 24 24', '<path ' + S + ' d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a3 3 0 0 0-3-1zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>'),
    mic: s('0 0 24 24', '<rect fill="currentColor" x="9" y="2.5" width="6" height="11" rx="3"/><path ' + S + ' d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>'),
    radioWave: s('0 0 24 24', '<path ' + S + ' d="M5 9a9 9 0 0 1 14 0M8 12a5 5 0 0 1 8 0"/><circle fill="currentColor" cx="12" cy="16" r="2"/>'),

    // ---------- testigos del tablero ----------
    indL: s('0 0 24 24', '<path fill="currentColor" d="M10 4.5L2.5 12l7.5 7.5V15h11V9H10z"/>'),
    indR: s('0 0 24 24', '<path fill="currentColor" d="M14 4.5l7.5 7.5-7.5 7.5V15H3V9h11z"/>'),
    low: s('0 0 24 24', '<path fill="currentColor" d="M11 5.5C6.6 5.5 3.5 8.4 3.5 12s3.1 6.5 7.5 6.5h1V5.5z"/><path ' + S + ' d="M15 8.5l6 1.6M15 12l6 1.6M15 15.5l6 1.6"/>'),
    high: s('0 0 24 24', '<path fill="currentColor" d="M11 5.5C6.6 5.5 3.5 8.4 3.5 12s3.1 6.5 7.5 6.5h1V5.5z"/><path ' + S + ' d="M15 7.5h6M15 12h6M15 16.5h6"/>'),
    cruise: s('0 0 24 24', '<path ' + S + ' d="M3.5 17a8.5 8.5 0 1 1 17 0"/><path ' + S + ' d="M12 17l4.5-5.5"/><circle fill="currentColor" cx="12" cy="17" r="1.6"/>'),
    belt: s('0 0 24 24', '<circle fill="currentColor" cx="12" cy="4.2" r="2.3"/><path fill="currentColor" d="M7.5 8.5h9l1 8h-2.6l-.6 5h-4.6l-.6-5H6.5z"/><path fill="none" stroke="#0b0d10" stroke-width="1.7" d="M8.6 8.9l7.6 9.6"/>'),
    hb: s('0 0 24 24', '<circle ' + S + ' cx="12" cy="12" r="7"/><path ' + S + ' d="M3.5 6.5a10.5 10.5 0 0 0 0 11M20.5 6.5a10.5 10.5 0 0 1 0 11"/><path fill="currentColor" d="M10 8h2.8a2.3 2.3 0 0 1 0 4.6H11.6V16H10zm1.6 1.4v1.8h1.1a.9.9 0 0 0 0-1.8z"/>'),
    engine: s('0 0 32 20', '<path fill="currentColor" d="M6 7h3V5h8v2h4l3 3h3v-2h2v8h-2v-2h-3l-3 4H9l-3-3H4v3H2V8h2v3h2z"/>'),
    oil: s('0 0 32 20', '<path fill="currentColor" d="M3 9h5l2-2h8l6 3 6-3-6 8H10l-2-3H3z"/><path fill="currentColor" d="M29 14c0 1.2-.9 2-2 2s-2-.8-2-2 2-3.5 2-3.5 2 2.3 2 3.5z"/>'),
    battery: s('0 0 32 20', '<path d="M5 5h4V3h4v2h6V3h4v2h4v13H5z" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M9 11h4M20 11h4M22 9v4" stroke="currentColor" stroke-width="2"/>'),
    temp: s('0 0 32 20', '<path d="M14 2h4v10a4 4 0 1 1-4 0z" fill="currentColor"/><path d="M19 4h4M19 7h3M19 10h4" stroke="currentColor" stroke-width="1.6"/><path d="M5 17c2-1.5 4 1.5 6 0s4 1.5 6 0 4 1.5 6 0 4 1.5 6 0" fill="none" stroke="currentColor" stroke-width="1.6"/>'),
    brakes: s('0 0 32 20', '<circle cx="16" cy="10" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M7 3.5a10 10 0 0 0 0 13M25 3.5a10 10 0 0 1 0 13" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16 6.5v4.5M16 12.6v1" stroke="currentColor" stroke-width="2"/>'),
    tires: s('0 0 32 20', '<path d="M8 4c-2 4-2 8 0 12h16c2-4 2-8 0-12" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 18h3M14.5 18h3M21 18h3" stroke="currentColor" stroke-width="2"/><path d="M16 6v5M16 12.8v1" stroke="currentColor" stroke-width="2"/>'),
    fuel: s('0 0 24 24', '<path fill="currentColor" d="M4 4.5A1.5 1.5 0 0 1 5.5 3h7A1.5 1.5 0 0 1 14 4.5V20H4zM6 5.5v4h6v-4z"/><path ' + S + ' d="M14 9h1.5l2 2v6.5a1.5 1.5 0 0 0 3 0V8.5L18 6"/>'),
    door: s('0 0 24 24', '<path ' + S + ' d="M8 2.5h8l1.5 4v11L16 21.5H8l-1.5-4v-11z"/><path ' + S + ' d="M17.5 9l4.5 2.5M6.5 9L2 11.5"/>'),
    lock: s('0 0 24 24', '<rect fill="currentColor" x="5" y="10.5" width="14" height="10" rx="2"/><path ' + S + ' d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>'),
    unlock: s('0 0 24 24', '<rect fill="currentColor" x="5" y="10.5" width="14" height="10" rx="2"/><path ' + S + ' d="M8 10.5V7.5a4 4 0 0 1 7.6-1.7"/>'),

    // ---------- CarPlay ----------
    home: s('0 0 24 24', '<path ' + S + ' d="M3.5 11L12 4l8.5 7M6 9.5V20h12V9.5"/>'),
    music: s('0 0 24 24', '<path fill="currentColor" d="M9 17.5a3 3 0 1 1-2-2.8V5l12-2.5v12a3 3 0 1 1-2-2.8V6.6L9 8.2z"/>'),
    car: s('0 0 24 24', '<path fill="currentColor" d="M5.2 6.6A2 2 0 0 1 7 5.5h10a2 2 0 0 1 1.8 1.1L21 11v6.5a1 1 0 0 1-1 1h-1.5a1 1 0 0 1-1-1V16.5h-11v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V11zM6.8 7.5L5.3 10.5h13.4l-1.5-3zM6.5 12.3a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8zm11 0a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8z"/>'),
    wrench: s('0 0 24 24', '<path fill="currentColor" d="M21 7.2a5.2 5.2 0 0 1-7 4.9L6.4 19.7a2.1 2.1 0 1 1-3-3L11 9a5.2 5.2 0 0 1 6.2-6.8l-3 3 .7 3 3 .7z"/>'),
    gear: s('0 0 24 24', '<path fill="currentColor" d="M10.3 2h3.4l.5 2.6 1.8.8 2.2-1.5 2.4 2.4-1.5 2.2.8 1.8 2.6.5v3.4l-2.6.5-.8 1.8 1.5 2.2-2.4 2.4-2.2-1.5-1.8.8-.5 2.6h-3.4l-.5-2.6-1.8-.8-2.2 1.5-2.4-2.4 1.5-2.2-.8-1.8L2 13.7v-3.4l2.6-.5.8-1.8-1.5-2.2 2.4-2.4 2.2 1.5 1.8-.8zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z"/>'),
    play: s('0 0 24 24', '<path fill="currentColor" d="M7 4.5v15l12.5-7.5z"/>'),
    pause: s('0 0 24 24', '<path fill="currentColor" d="M6.5 4.5h4v15h-4zM13.5 4.5h4v15h-4z"/>'),
    stop: s('0 0 24 24', '<rect fill="currentColor" x="5.5" y="5.5" width="13" height="13" rx="1.5"/>'),
    next: s('0 0 24 24', '<path fill="currentColor" d="M5 5v14l10-7zM16 5h3v14h-3z"/>'),
    plus: s('0 0 24 24', '<path ' + S + ' d="M12 5v14M5 12h14"/>'),
    close: s('0 0 24 24', '<path ' + S + ' d="M6 6l12 12M18 6L6 18"/>'),
    vol: s('0 0 24 24', '<path fill="currentColor" d="M4 9h4l5-4.5v15L8 15H4z"/><path ' + S + ' d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>'),
    power: s('0 0 24 24', '<path ' + S + ' d="M12 3v8.5M7 6.2a7.5 7.5 0 1 0 10 0"/>'),
    bulb: s('0 0 24 24', '<path fill="currentColor" d="M12 2.5a6.5 6.5 0 0 0-3.8 11.8c.6.5.8 1 .8 1.7V17h6v-1c0-.7.2-1.2.8-1.7A6.5 6.5 0 0 0 12 2.5zM9 18.5h6V20a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 20z"/>'),
    hazard: s('0 0 24 24', '<path fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" d="M12 3.5L21.5 20h-19z"/><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" d="M12 9.5l4.2 7.3H7.8z"/>'),
    window: s('0 0 24 24', '<path ' + S + ' d="M4 19V9.5L9.5 4H20v15z"/><path ' + S + ' d="M12 9v7M9 13l3 3 3-3"/>'),
    roof: s('0 0 24 24', '<path ' + S + ' d="M3 16.5h18M5 16.5l2.5-6h9l2.5 6"/><path ' + S + ' d="M9 7l3-3 3 3"/>'),
    seat: s('0 0 24 24', '<path fill="currentColor" d="M7 3.5h4.5l1 9.5H18a2 2 0 0 1 2 2v2.5H8.6a2 2 0 0 1-2-1.8z"/><path ' + S + ' d="M9 17.5v3M17 17.5v3"/>'),
    yt: s('0 0 24 24', '<path fill="currentColor" d="M21.6 7.2a2.6 2.6 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.6 2.6 0 0 0 2.4 7.2 27 27 0 0 0 2 12a27 27 0 0 0 .4 4.8 2.6 2.6 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.6 2.6 0 0 0 1.8-1.8A27 27 0 0 0 22 12a27 27 0 0 0-.4-4.8zM10 15V9l5.2 3z"/>'),
    plane: s('0 0 24 24', '<path fill="currentColor" d="M21 15.5v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V8.5l-8 5v2l8-2.5V18l-2 1.5V21l3.5-1 3.5 1v-1.5L13 18v-5z"/>'),
  };

  window.LSN.icons = I;
})();
