/* ============================================================
   LSN HUD · estado minimalista, brujula editable con lerp 60fps,
   calle independiente, logo del servidor y marco del radar
   ============================================================ */
(() => {
  'use strict';
  const { $, h, clamp, num, state, icons: I, on, place } = window.LSN;

  // ------------------------------------------------------------
  // Indicadores de estado minimalistas
  // ------------------------------------------------------------
  const R = 17;
  const C = 2 * Math.PI * R;
  const ITEMS = [
    { k: 'hp', icon: 'heart', color: '#22c55e', label: 'Vida' },
    { k: 'armor', icon: 'shield', color: '#3b82f6', label: 'Chaleco' },
    { k: 'hunger', icon: 'food', color: '#f59e0b', label: 'Comida' },
    { k: 'thirst', icon: 'drop', color: '#38bdf8', label: 'Sed' },
    { k: 'oxygen', icon: 'oxygen', color: '#67e8f9', label: 'Oxígeno' },
    { k: 'stamina', icon: 'run', color: '#e5e7eb', label: 'Energía' },
    { k: 'stress', icon: 'brain', color: '#f472b6', label: 'Estrés' },
  ];

  const statusRoot = $('status');
  const nodes = {};
  for (const it of ITEMS) {
    const el = h('div', { class: 'ring', dataset: { k: it.k }, title: it.label, style: `--c:${it.color}` },
      `<svg viewBox="0 0 40 40"><circle class="ring-bg" cx="20" cy="20" r="${R}"/>` +
      `<circle class="ring-fg" cx="20" cy="20" r="${R}" stroke-dasharray="${C.toFixed(2)}" stroke-dashoffset="0"/></svg>` +
      `<i class="ring-ico">${I[it.icon]}</i>`);
    if (it.k !== 'hp') el.classList.add('off');
    statusRoot.appendChild(el);
    nodes[it.k] = { el, fg: el.querySelector('.ring-fg'), last: -1 };
  }

  const voiceEl = h('div', { class: 'ring voice off', dataset: { k: 'voice' }, title: 'Voz' },
    `<svg viewBox="0 0 40 40"><circle class="ring-bg" cx="20" cy="20" r="${R}"/></svg><i class="ring-ico">${I.mic}</i><span class="voice-dots"><i></i><i></i><i></i></span>`);
  statusRoot.appendChild(voiceEl);
  const voiceDots = [...voiceEl.querySelectorAll('.voice-dots i')];

  function setRing(k, value, show) {
    const n = nodes[k];
    n.el.classList.toggle('off', !show);
    if (!show) return;
    const v = clamp(num(value), 0, 100);
    if (Math.abs(v - n.last) < 0.25) return;
    n.last = v;
    n.fg.style.strokeDashoffset = (C * (1 - v / 100)).toFixed(2);
    n.el.classList.toggle('low', v < 20);
  }

  let lastVoiceSig = '';
  on('player', (d) => {
    const auto = d.autoBelow;
    setRing('hp', d.hp, true);
    setRing('armor', d.armor, num(d.armor) > 0);
    setRing('hunger', d.hunger, d.hunger != null && (auto == null || d.hunger < auto));
    setRing('thirst', d.thirst, d.thirst != null && (auto == null || d.thirst < auto));
    setRing('oxygen', d.oxygen, d.oxygen != null);
    setRing('stamina', d.stamina, d.stamina != null && d.stamina < 99);
    setRing('stress', d.stress, d.stress != null && d.stress > 1);

    const v = d.voice;
    const sig = v ? `${v.talking ? 1 : 0}:${v.radio ? 1 : 0}:${num(v.mode, 2)}` : 'off';
    if (sig !== lastVoiceSig) {
      lastVoiceSig = sig;
      voiceEl.classList.toggle('off', !v);
      if (v) {
        voiceEl.classList.toggle('talking', !!v.talking);
        voiceEl.classList.toggle('radio', !!v.radio);
        const mode = num(v.mode, 2);
        for (let i = 0; i < voiceDots.length; i++) voiceDots[i].classList.toggle('on', i < mode);
      }
    }
  });

  // ------------------------------------------------------------
  // Brujula independiente (editable + interpolacion fluida 60fps)
  // ------------------------------------------------------------
  const compassEl = $('compass');
  const streetEl = $('street');
  const tape = $('compassTape');
  const cmpDir = $('cmpDir');
  const cmpDeg = $('cmpDeg');
  const hdgTxt = $('hdgTxt');
  const streetTxt = $('streetTxt');
  const zoneTxt = $('zoneTxt');
  const clockTxt = $('clockTxt');

  const PX_PER_DEG = 2.2;
  const LABELS = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SO', 270: 'O', 315: 'NO' };
  const DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  const dirName = (deg) => DIRS[Math.round(deg / 45) % 8];

  (() => {
    let html = '';
    for (let d = -360; d <= 720; d += 5) {
      const n = ((d % 360) + 360) % 360;
      const x = (d + 360) * PX_PER_DEG;
      if (LABELS[n] != null) html += `<span class="cl${n % 90 === 0 ? ' major' : ''}" style="left:${x}px">${LABELS[n]}</span>`;
      else if (n % 15 === 0) html += `<span class="cn" style="left:${x}px">${n}</span>`;
      else html += `<i class="ct" style="left:${x}px"></i>`;
    }
    tape.innerHTML = html;
  })();

  let targetHdg = 0;
  let currentHdg = 0;
  let cmpRaf = 0;
  let cachedTapeWidth = 280;

  function renderHeading(deg) {
    const norm = ((deg % 360) + 360) % 360;
    const tx = -(norm + 360) * PX_PER_DEG + cachedTapeWidth / 2;
    tape.style.transform = `translate3d(${tx.toFixed(1)}px, 0, 0)`;
    const dir = dirName(norm);
    if (hdgTxt.textContent !== dir) hdgTxt.textContent = dir;
    if (cmpDir.textContent !== dir) cmpDir.textContent = dir;
    const degStr = String(Math.round(norm) % 360).padStart(3, '0') + '°';
    if (cmpDeg.textContent !== degStr) cmpDeg.textContent = degStr;
  }

  function stepCompass() {
    cmpRaf = 0;
    let diff = ((targetHdg - currentHdg + 540) % 360) - 180;
    if (Math.abs(diff) < 0.15) {
      currentHdg = targetHdg;
      renderHeading(currentHdg);
      return;
    }
    currentHdg = (currentHdg + diff * 0.28 + 360) % 360;
    renderHeading(currentHdg);
    cmpRaf = requestAnimationFrame(stepCompass);
  }

  on('loc', (d) => {
    if (d.hdg != null) {
      targetHdg = num(d.hdg);
      if (!cmpRaf) cmpRaf = requestAnimationFrame(stepCompass);
    }
    if (d.street != null) {
      const s = d.street || '—';
      const z = [d.cross, d.zone].filter(Boolean).join(' · ');
      if (streetTxt.textContent !== s) streetTxt.textContent = s;
      if (zoneTxt.textContent !== z) zoneTxt.textContent = z;
    }
    if (d.time && clockTxt.textContent !== d.time) clockTxt.textContent = d.time;
  });

  function applyLocSettings() {
    const s = state.settings;
    const style = s.compassStyle || 'minimal';
    const w = clamp(num(s.compassWidth, 280), 180, 420);
    cachedTapeWidth = w;

    compassEl.classList.toggle('off', !s.showCompass);
    compassEl.dataset.style = style;
    compassEl.classList.toggle('no-deg', !s.compassDegrees);
    compassEl.classList.toggle('no-hdg', !s.compassHeading);
    compassEl.style.setProperty('--cmp-w', w + 'px');

    streetEl.classList.toggle('off', !s.showStreet);
    renderHeading(currentHdg);
  }
  on('settings', applyLocSettings);

  // ------------------------------------------------------------
  // Logo del servidor (sincronizado desde panel admin)
  // ------------------------------------------------------------
  const logoEl = $('serverLogo');
  const logoImg = $('serverLogoImg');

  function applyServerLogo() {
    const srv = state.server || {};
    const url = String(srv.logoUrl || '').trim();
    const show = !!srv.logoEnabled && url.length > 0;
    logoEl.classList.toggle('off', !show);
    const size = clamp(num(srv.logoSize, 68), 28, 220);
    const opacity = clamp(num(srv.logoOpacity, 90), 10, 100) / 100;
    logoEl.style.setProperty('--logo-size', size + 'px');
    logoEl.style.setProperty('--logo-opacity', String(opacity));
    if (show) {
      if (logoImg.getAttribute('src') !== url) {
        logoImg.src = url;
      }
    } else {
      logoImg.removeAttribute('src');
    }
    place(logoEl);
  }
  logoImg.addEventListener('error', () => {
    logoEl.classList.add('off');
  });
  on('serverUpdated', applyServerLogo);

  // ------------------------------------------------------------
  // Marco del minimapa
  // ------------------------------------------------------------
  on('minimap', (d) => {
    if (d.rect) state.minimap.rect = d.rect;
    state.minimap.show = !!d.show;
    const r = state.minimap.rect;
    const f = $('mmframe');
    f.style.left = r.x + '%';
    f.style.top = r.y + '%';
    f.style.width = r.w + '%';
    f.style.height = r.h + '%';
    f.classList.toggle('off', !d.show);
    window.LSN.placeAll();
  });
})();
