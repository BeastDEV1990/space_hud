/* ============================================================
   LSN HUD · CarPlay: inicio, musica, vehiculo y diagnostico
   ============================================================ */
(() => {
  'use strict';
  const { $, esc, clamp, num, post, on, emit, state, icons: I, sound, fmtInt, fmt1 } = window.LSN;

  const root = $('carplay');
  let S = null;            // estado que manda Lua
  let recvAt = 0;
  let view = 'home';
  let isOpen = false;

  const PART_ORDER = ['oil', 'coolant', 'radiator', 'alternator', 'battery', 'brakes', 'tires', 'transmission'];
  const PART_LABEL = {
    oil: 'Aceite de motor', coolant: 'Refrigerante', radiator: 'Radiador', alternator: 'Alternador',
    battery: 'Batería', brakes: 'Pastillas de freno', tires: 'Llantas', transmission: 'Aceite de transmisión',
  };
  const SEAT_LABEL = ['Conductor', 'Copiloto', 'Trasero izq.', 'Trasero der.'];
  const WIN_LABEL = ['Delantero izq.', 'Delantero der.', 'Trasero izq.', 'Trasero der.'];
  const thumb = (id) => `https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;
  const mmss = (s) => { s = Math.max(0, Math.floor(num(s))); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
  const bit = (v, i) => (num(v) & (1 << i)) !== 0;

  // ------------------------------------------------------------
  // Esqueleto
  // ------------------------------------------------------------
  root.innerHTML = `
    <div class="cp" role="dialog" aria-label="Pantalla del vehículo">
      <aside class="cp-dock">
        <div class="cp-time" id="cpTime">--:--</div>
        <nav class="cp-apps">
          <button type="button" class="cp-app" data-app="home" style="--c:#3b82f6">${I.home}<span>Inicio</span></button>
          <button type="button" class="cp-app" data-app="music" style="--c:#fa2d55">${I.music}<span>Música</span></button>
          <button type="button" class="cp-app" data-app="vehicle" style="--c:#22c55e">${I.car}<span>Vehículo</span></button>
          <button type="button" class="cp-app" data-app="diag" style="--c:#f5a524">${I.wrench}<span>Estado</span></button>
          <button type="button" class="cp-app" data-app="settings" style="--c:#8d97a5">${I.gear}<span>HUD</span></button>
        </nav>
        <button type="button" class="cp-close" id="cpClose" aria-label="Cerrar">${I.close}</button>
      </aside>
      <main class="cp-main">
        <header class="cp-head">
          <div><b id="cpName">Vehículo</b><span id="cpPlate" class="plate"></span></div>
          <span id="cpSeat" class="cp-seat"></span>
        </header>

        <section class="cp-view" data-view="home">
          <div class="home-grid">
            <button type="button" class="card now-mini" data-go="music">
              <img id="homeArt" alt="">
              <div class="nm-txt"><small>Reproduciendo</small><b id="homeTitle">Nada sonando</b><span id="homeSub">Pega un link de YouTube en Música</span></div>
              <i class="nm-ico">${I.music}</i>
            </button>
            <div class="card quick">
              <button type="button" class="tile" data-act="engine">${I.power}<span>Motor</span></button>
              <button type="button" class="tile" data-act="lock">${I.lock}<span>Seguro</span></button>
              <button type="button" class="tile" data-act="ind" data-i="3">${I.hazard}<span>Emergencia</span></button>
              <button type="button" class="tile" data-act="int">${I.bulb}<span>Luz interior</span></button>
            </div>
            <div class="card health">
              <div class="hbar"><span>Combustible</span><span class="bar"><b id="hFuel"></b></span><em id="hFuelV"></em></div>
              <div class="hbar"><span>Motor</span><span class="bar"><b id="hEng"></b></span><em id="hEngV"></em></div>
              <div class="hbar"><span>Carrocería</span><span class="bar"><b id="hBody"></b></span><em id="hBodyV"></em></div>
              <div class="hodo"><span>Odómetro</span><b id="hOdo">—</b></div>
            </div>
          </div>
        </section>

        <section class="cp-view" data-view="music">
          <form class="yt-form" id="ytForm" autocomplete="off">
            <i class="yt-ico">${I.yt}</i>
            <input id="ytUrl" type="text" placeholder="Pega un link de YouTube…" spellcheck="false" maxlength="200">
            <button type="submit" class="btn btn-primary" data-mode="play">${I.play} Reproducir</button>
            <button type="button" class="btn" id="ytQueue">${I.plus} A la cola</button>
          </form>
          <p class="cp-note" id="radioNote" hidden></p>
          <div class="music-grid">
            <div class="now">
              <div class="art"><img id="npArt" alt=""><div class="art-empty" id="npEmpty">${I.music}</div></div>
              <div class="np-info">
                <b id="npTitle">Nada sonando</b>
                <span id="npSub">Radio del vehículo</span>
                <div class="prog"><span id="npCur">0:00</span><span class="bar"><b id="npBar"></b></span><span id="npDur">0:00</span></div>
                <div class="np-ctl">
                  <button type="button" class="round" data-radio="stop" aria-label="Detener">${I.stop}</button>
                  <button type="button" class="round big" data-radio="toggle" aria-label="Pausa" id="npToggle">${I.pause}</button>
                  <button type="button" class="round" data-radio="next" aria-label="Siguiente" id="npNext">${I.next}</button>
                </div>
                <label class="vol"><i>${I.vol}</i><span>Radio</span><input type="range" min="0" max="100" step="1" id="volCar"><output id="volCarV">60</output></label>
                <label class="vol"><i>${I.vol}</i><span>Mi volumen</span><input type="range" min="0" max="100" step="1" id="volMe"><output id="volMeV">100</output></label>
              </div>
            </div>
            <div class="queue">
              <div class="q-head"><b>En cola</b><button type="button" class="link" data-radio="clear">Vaciar</button></div>
              <ol id="qList"></ol>
            </div>
          </div>
        </section>

        <section class="cp-view" data-view="vehicle">
          <div class="veh-grid">
            <div class="car-top" id="carTop"></div>
            <div class="veh-side">
              <div class="tiles">
                <button type="button" class="tile" data-act="engine">${I.power}<span>Motor</span></button>
                <button type="button" class="tile" data-act="lock">${I.lock}<span>Seguro</span></button>
                <button type="button" class="tile" data-act="belt">${I.belt}<span>Cinturón</span></button>
                <button type="button" class="tile" data-act="int">${I.bulb}<span>Luz interior</span></button>
                <button type="button" class="tile" data-act="ind" data-i="1">${I.indL}<span>Direccional</span></button>
                <button type="button" class="tile" data-act="ind" data-i="3">${I.hazard}<span>Emergencia</span></button>
                <button type="button" class="tile" data-act="ind" data-i="2">${I.indR}<span>Direccional</span></button>
                <button type="button" class="tile" data-act="roof" id="tRoof">${I.roof}<span>Techo</span></button>
              </div>
              <h4>Vidrios</h4>
              <div class="wins" id="wins"></div>
              <h4>Asientos</h4>
              <div class="seats" id="seats"></div>
            </div>
          </div>
        </section>

        <section class="cp-view" data-view="diag">
          <div class="diag-grid">
            <div class="diag-col" id="diagBasic"></div>
            <div class="diag-col" id="diagParts"></div>
          </div>
        </section>
      </main>
    </div>`;

  // ------------------------------------------------------------
  // Vista superior del auto (clic en puertas, capo y maletero)
  // ------------------------------------------------------------
  // (el auto lo dibuja cartop.js con el color real del vehiculo)

  // ------------------------------------------------------------
  // Pintar
  // ------------------------------------------------------------
  function setView(v) {
    if (v === 'settings') { emit('openSettings', { fromCarplay: true }); return; }
    view = v;
    root.querySelectorAll('.cp-view').forEach((s) => { s.hidden = s.dataset.view !== v; });
    root.querySelectorAll('.cp-app').forEach((b) => b.classList.toggle('on', b.dataset.app === v));
    paint();
  }

  function setTile(sel, onState, extra) {
    root.querySelectorAll(sel).forEach((b) => {
      b.classList.toggle('on', !!onState);
      if (extra) extra(b);
    });
  }

  function paintCommon() {
    $('cpName').textContent = [S.make, S.name].filter(Boolean).join(' ') || 'Vehículo';
    $('cpPlate').textContent = S.plate || '';
    $('cpSeat').textContent = S.seat === -1 ? 'Conductor' : S.seat === 0 ? 'Copiloto' : 'Pasajero';
    const d = new Date();
    $('cpTime').textContent = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

    const drv = S.drv;
    setTile('[data-act="engine"]', S.on, (b) => { b.disabled = !drv; });
    setTile('[data-act="lock"]', S.locked, (b) => { b.innerHTML = `${S.locked ? I.lock : I.unlock}<span>${S.locked ? 'Con seguro' : 'Sin seguro'}</span>`; });
    setTile('[data-act="belt"]', S.belt, (b) => { b.disabled = !S.beltable; });
    setTile('[data-act="int"]', S.int, (b) => { b.disabled = !(S.seat === -1 || S.seat === 0); });
    setTile('[data-act="ind"][data-i="1"]', S.ind === 1, (b) => { b.disabled = !drv; });
    setTile('[data-act="ind"][data-i="2"]', S.ind === 2, (b) => { b.disabled = !drv; });
    setTile('[data-act="ind"][data-i="3"]', S.ind === 3, (b) => { b.disabled = !drv; });
    const roof = $('tRoof');
    roof.hidden = !S.convertible;
    roof.disabled = !drv;
    roof.classList.toggle('on', !!S.roof);
    roof.querySelector('span').textContent = S.roof ? 'Techo abierto' : 'Techo';
  }

  function radioPos() {
    const r = S && S.radio;
    if (!r) return 0;
    if (r.p) return num(r.pos);
    return Math.max(0, num(S.now) - num(r.t) + (performance.now() - recvAt) / 1000);
  }

  function paintMusic() {
    const r = S.radio;
    const p = window.LSN.player.info();
    const same = r && p && p.id === r.id;
    const title = (r && (r.title || (same && p.title))) || (r ? 'Video de YouTube' : 'Nada sonando');
    const dur = same ? p.dur : 0;
    const pos = radioPos();

    // inicio
    $('homeTitle').textContent = title;
    $('homeSub').textContent = r ? (r.p ? 'En pausa' : 'Sonando en el vehículo') : 'Pega un link de YouTube en Música';
    const ha = $('homeArt');
    if (r) { if (ha.dataset.id !== r.id) { ha.dataset.id = r.id; ha.src = thumb(r.id); } ha.hidden = false; } else { ha.hidden = true; ha.dataset.id = ''; }

    if (view !== 'music') return;
    const art = $('npArt');
    if (r) { if (art.dataset.id !== r.id) { art.dataset.id = r.id; art.src = thumb(r.id); } art.hidden = false; } else { art.hidden = true; art.dataset.id = ''; }
    $('npEmpty').hidden = !!r;
    $('npTitle').textContent = title;
    $('npSub').textContent = r ? (r.p ? 'En pausa' : 'Sonando para todos en el vehículo') : 'Radio del vehículo';
    $('npCur').textContent = mmss(dur ? Math.min(pos, dur) : pos);
    $('npDur').textContent = dur ? mmss(dur) : '--:--';
    $('npBar').style.width = dur ? clamp((pos / dur) * 100, 0, 100) + '%' : '0%';
    $('npToggle').innerHTML = r && r.p ? I.play : I.pause;

    const can = !!S.canRadio;
    root.querySelectorAll('[data-radio], #ytForm button, #ytUrl, #volCar').forEach((el) => { el.disabled = !can || (!r && el.dataset.radio && el.dataset.radio !== 'clear'); });
    $('ytUrl').disabled = !can;
    root.querySelectorAll('#ytForm button').forEach((b) => { b.disabled = !can; });
    $('npNext').disabled = !can || !r || !(r.q && r.q.length);
    const note = $('radioNote');
    note.hidden = can;
    note.textContent = !S.hasRadio ? 'Este vehículo no tiene radio.' : 'Solo el conductor y el copiloto pueden controlar la radio.';

    const vc = $('volCar');
    if (document.activeElement !== vc) { vc.value = r ? num(r.vol, 60) : 60; $('volCarV').textContent = vc.value; }
    const vm = $('volMe');
    if (document.activeElement !== vm) { vm.value = num(state.settings.musicVolume, 100); $('volMeV').textContent = vm.value; }

    const q = (r && r.q) || [];
    const html = q.length
      ? q.map((it, i) => `<li><img src="${thumb(it.id)}" alt=""><span>${esc(it.title || 'Video de YouTube')}</span>${can ? `<button type="button" class="x" data-remove="${i + 1}" aria-label="Quitar">${I.close}</button>` : ''}</li>`).join('')
      : '<li class="empty">La cola está vacía. Usa "A la cola" para agregar canciones.</li>';
    const ql = $('qList');
    if (ql._h !== html) { ql._h = html; ql.innerHTML = html; }
  }

  function paintVehicle() {
    if (view !== 'vehicle') return;
    // auto: puertas, capo, maletero, vidrios y techo
    window.LSN.carTop.paint($('carTop'), S);

    // vidrios
    const wins = [];
    for (let i = 0; i < 4; i++) {
      if (!bit(S.doorValid, i)) continue;
      const own = S.seat === -1 || ({ 0: 1, 1: 2, 2: 3 })[S.seat] === i;
      wins.push(`<button type="button" class="chip${bit(S.win, i) ? ' on' : ''}" data-act="win" data-i="${i}" ${own ? '' : 'disabled'}>${I.window}<span>${WIN_LABEL[i]}</span></button>`);
    }
    const wh = wins.join('') || '<span class="muted">Sin vidrios</span>';
    const w = $('wins');
    if (w._h !== wh) { w._h = wh; w.innerHTML = wh; }

    // asientos
    const seats = [];
    for (let i = 0; i < num(S.seats); i++) {
      const seat = i - 1;
      const me = seat === S.seat;
      const free = bit(S.seatFree, i);
      const lbl = SEAT_LABEL[i] || `Asiento ${i + 1}`;
      seats.push(`<button type="button" class="chip${me ? ' on' : ''}" data-act="seat" data-i="${seat}" ${me || !free ? 'disabled' : ''}>${I.seat}<span>${lbl}${me ? ' · tú' : !free ? ' · ocupado' : ''}</span></button>`);
    }
    const sh = seats.join('');
    const s = $('seats');
    if (s._h !== sh) { s._h = sh; s.innerHTML = sh; }
  }

  function barRow(label, v, extra = '') {
    const pct = clamp(num(v), 0, 100);
    const cls = pct < 15 ? 'crit' : pct < 35 ? 'warn' : '';
    return `<div class="drow"><span>${label}</span><span class="bar"><b class="${cls}" style="width:${pct.toFixed(1)}%"></b></span><em>${Math.round(pct)}%${extra}</em></div>`;
  }

  function paintDiag() {
    const d = S.diag || {};
    // inicio
    const setBar = (id, v) => { const b = $(id); const p = clamp(num(v), 0, 100); b.style.width = p + '%'; b.className = p < 15 ? 'crit' : p < 35 ? 'warn' : ''; $(id + 'V').textContent = Math.round(p) + '%'; };
    setBar('hFuel', d.fuel); setBar('hEng', d.eng); setBar('hBody', d.body);
    $('hOdo').textContent = d.km != null ? `${fmtInt.format(Math.floor(d.km))} ${d.dist}` : '—';

    if (view !== 'diag') return;
    let basic = '<h4>General</h4>' + barRow('Combustible', d.fuel) + barRow('Motor', d.eng) + barRow('Carrocería', d.body);
    if (d.km != null) {
      basic += `<div class="dkv"><span>Odómetro</span><b>${fmtInt.format(Math.floor(d.km))} ${d.dist}</b></div>`;
      basic += `<div class="dkv"><span>Parcial</span><b>${fmt1.format(num(d.trip))} ${d.dist}</b></div>`;
    }
    if (d.temp != null) basic += `<div class="dkv"><span>Temperatura del motor</span><b class="${d.temp > 112 ? 'crit' : d.temp > 105 ? 'warn' : ''}">${Math.round(d.temp)} °C</b></div>`;
    if (d.parts && d.parts.charge != null) basic += barRow('Carga de batería', d.parts.charge);

    let parts = '<h4>Piezas</h4>';
    if (d.parts) {
      const labels = d.labels || {};
      for (const k of PART_ORDER) {
        if (d.parts[k] == null) continue;
        parts += barRow((labels[k] && (labels[k].label || labels[k])) || PART_LABEL[k], d.parts[k]);
      }
    } else {
      parts += `<p class="cp-note">${S.drv ? 'Este vehículo no tiene ficha técnica (no es de un jugador).' : 'El estado de las piezas solo lo ve el conductor.'}</p>`;
    }
    const html = `<div>${basic}</div>`;
    const bEl = $('diagBasic');
    if (bEl._h !== html) { bEl._h = html; bEl.innerHTML = html; }
    const pEl = $('diagParts');
    if (pEl._h !== parts) { pEl._h = parts; pEl.innerHTML = parts; }
  }

  function paint() {
    if (!S) return;
    paintCommon();
    paintMusic();
    paintVehicle();
    paintDiag();
  }

  // ------------------------------------------------------------
  // Eventos
  // ------------------------------------------------------------
  function close() {
    if (!isOpen) return;
    isOpen = false;
    root.hidden = true;
    window.LSN.retro.hide();
    post('close');
  }
  // autos viejos: radio de epoca en lugar de la pantalla
  const retroMode = () => !!(S && S.retro);

  root.addEventListener('click', (e) => {
    const app = e.target.closest('[data-app]');
    if (app) { sound('click', true); return setView(app.dataset.app); }
    const go = e.target.closest('[data-go]');
    if (go) return setView(go.dataset.go);
    const act = e.target.closest('[data-act]');
    if (act && !act.disabled) {
      sound('click', true);
      post('vehAction', { act: act.dataset.act, i: act.dataset.i != null ? Number(act.dataset.i) : undefined });
      return;
    }
    const zone = e.target.closest('.ct-zone');
    if (zone && !zone.classList.contains('locked')) {
      sound('click', true);
      post('vehAction', { act: 'door', i: Number(zone.dataset.door) });
      return;
    }
    const rb = e.target.closest('[data-radio]');
    if (rb && !rb.disabled) { sound('click', true); post('radio', { cmd: rb.dataset.radio }); return; }
    const rm = e.target.closest('[data-remove]');
    if (rm) { post('radio', { cmd: 'remove', arg: Number(rm.dataset.remove) }); return; }
  });
  $('cpClose').addEventListener('click', close);

  async function submitLink(cmd) {
    const input = $('ytUrl');
    const id = window.LSN.player.parseId(input.value);
    if (!id) { post('notify', { msg: state.config.text?.badLink || 'Ese link no es de YouTube', kind: 'error' }); return; }
    input.value = '';
    const title = await window.LSN.player.fetchTitle(id);
    post('radio', { cmd, arg: id, title });
  }
  $('ytForm').addEventListener('submit', (e) => { e.preventDefault(); submitLink('play'); });
  $('ytQueue').addEventListener('click', () => submitLink('queue'));

  let volTimer = null;
  $('volCar').addEventListener('input', (e) => {
    $('volCarV').textContent = e.target.value;
    clearTimeout(volTimer);
    volTimer = setTimeout(() => post('radio', { cmd: 'vol', arg: Number(e.target.value) }), 200);
  });
  let meTimer = null;
  $('volMe').addEventListener('input', (e) => {
    $('volMeV').textContent = e.target.value;
    state.settings.musicVolume = Number(e.target.value);
    clearTimeout(meTimer);
    meTimer = setTimeout(() => post('saveSettings', state.settings), 300);
  });

  // ------------------------------------------------------------
  // Mensajes de Lua
  // ------------------------------------------------------------
  on('carplay', (d) => {
    if (d.open === false) { isOpen = false; root.hidden = true; window.LSN.retro.hide(); return; }
    if (d.state) { S = d.state; recvAt = performance.now(); }
    if (d.open) {
      isOpen = true;
      if (retroMode()) {
        root.hidden = true;
        window.LSN.retro.show(S, recvAt, d.tab);
        return;
      }
      window.LSN.retro.hide();
      root.hidden = false;
      setView(d.tab || 'home');
      if (d.tab === 'music') setTimeout(() => $('ytUrl').focus(), 50);
      return;
    }
    if (retroMode()) window.LSN.retro.paint(S, recvAt); else paint();
  });

  setInterval(() => {
    if (!isOpen || !S) return;
    if (retroMode()) window.LSN.retro.tick(); else paintMusic();
  }, 500);
  // retro.js se carga despues: registrar su boton de cerrar cuando exista
  setTimeout(() => window.LSN.retro && window.LSN.retro.onClose(close), 0);

  window.LSN.carplay = {
    close, isOpen: () => isOpen,
    hide: () => { root.hidden = true; window.LSN.retro && window.LSN.retro.hide(); },
    show: () => { if (!isOpen) return; if (retroMode()) window.LSN.retro.show(S, recvAt); else root.hidden = false; },
  };
})();
