# Novedades 1.3
- **Con `lsn_llaves`:** el motor (G) y el seguro (L) pasan a ser del sistema de llaves. `lsn_hud` ya no registra esas teclas
  y su menú y CarPlay usan las llaves. Sin `lsn_llaves` todo sigue como antes.
- **Arreglado:** la G que no apagaba y la L que había que spamear. Era otro script de llaves (jaksam) usando las mismas teclas:
  los dos se ejecutaban a la vez y se anulaban. Quita `vehicles_keys` del `server.cfg`.
- Export de cliente `isRetro(vehiculo)`: lo usa `lsn_llaves` para saber si al auto se le hace puente con destornillador o con programador.

# Novedades 1.2.1
- **Arreglado:** las posiciones de `/lsnhud` › Mover elementos ya se guardan. Antes, al guardar, todo volvía a su lugar (el tamaño sí se guardaba).

# Novedades 1.2
Reemplaza las carpetas `lsn_hud` y `realengine_vehicles` (1.4.1) y reinicia. No cambia la base de datos.

- **Arreglado:** el velocímetro ya no aparece a pie. Antes salía al entrar al servidor hasta la primera vez que te bajabas de un auto.
- **Bicicletas:** sin velocímetro ni odómetro. `realengine_vehicles` tampoco les cuenta kilómetros ni desgaste. Se cambia en `Config.Vehicle.noSpeedo`.
- **Música desde afuera, realista:**
  - Con el auto **cerrado** no se escucha afuera (`Config.Radio.closedFactor`; pon `0.05` si quieres que se cuele un poco de bajo).
  - El sonido sale por cada **vidrio bajado o roto, puerta abierta, capota abierta o maletero**, desde su lugar en el auto. Al caminar alrededor suena más fuerte del lado abierto y baja con la distancia.
  - Si escuchas desde **otro auto cerrado**, te llega más apagado.
  - El volumen cambia suave, sin saltos.
  - Todo se ajusta en `Config.Radio` (`range`, `refDistance`, `open`, `listenerInClosedCar`).
- **Ítems para instalar la radio** (ox_inventory):
  - `kit_carplay`: CarPlay en un auto viejo.
  - `radio_clasica`: radio de época en un auto moderno.
  - Se usan sentado al volante con el auto detenido (12 s con barra de progreso). El kit se gasta y la radio queda **guardada por placa**: dura aunque el auto vaya al garaje o reinicies el servidor.
  - Para que solo los mecánicos puedan instalar: `Config.HeadUnit.jobs = { mechanic = 0 }`.
  - **Instalación:** pega `install/ox_inventory_items.lua` dentro de `ox_inventory/data/items.lua`, copia `install/images/*.png` a `ox_inventory/web/images/` y reinicia ox_inventory.

# Novedades 1.1
Reemplaza la carpeta `lsn_hud` y reinicia. No toca la base de datos ni `realengine_vehicles`.

- **Velocímetro "Agujas"** (antes "Clásico"): dos relojes de aguja modernos y **transparentes**, para no tapar el camino. Aguja flotante con brillo, arco de color que sigue a la aguja, y combustible y temperatura en el hueco de abajo. El odómetro y el parcial van en el centro.
- **CarPlay en negro**, con botones grises, bordes azules y letras blancas. Ya no usa el color de acento del HUD.
- **El auto de CarPlay** se dibuja con el **color real de su pintura**. Las puertas giran sobre la bisagra, el capó y el maletero se levantan, los vidrios bajados dejan ver el interior y el techo convertible abierto muestra los asientos.
- **Autos viejos: radio de época en vez de CarPlay.** Tiene dial iluminado (la aguja avanza con la canción), perillas de volumen y sintonía, teclas mecánicas y una casetera: el link de YouTube se "inserta" como un casete y la cola queda en la guantera. Abajo hay un panel de interruptores de palanca para el motor, el seguro, las luces, las puertas, los vidrios y el asiento.
  - Se abre con las mismas teclas (K e Y) y hace lo mismo que CarPlay.
  - Qué autos son viejos: `Config.Retro` en `config.lua`. Por defecto son toda la clase 5 (deportivos clásicos) más una lista de muscle, sedanes y vans viejos. En `Config.Retro.modern` pones los modelos que deben usar CarPlay igual (por ejemplo, un restomod).
  - Export de servidor para un taller que cambie la radio: `exports.lsn_hud:setHeadUnit(vehiculo, 'carplay' | 'retro' | nil)`.

# LSN HUD 1.0

HUD completo para ESX: estado del jugador, minimapa con marco, 4 velocímetros, panel de vuelo para aviones y helicópteros, menú del vehículo, pantalla tipo CarPlay y radio de YouTube sincronizada.

## Requisitos
- `es_extended` y `ox_lib` (los que ya usas).
- Opcionales, se detectan solos:
  - `esx_status` + `esx_basicneeds`: comida y sed (y `stress` si lo tienes).
  - `realengine_vehicles` **1.4** (incluida en este paquete): odómetro, parcial, temperatura y testigos (aceite, batería, motor, frenos, llantas) en el velocímetro, y el estado de piezas en CarPlay.
  - `oxmysql`: para que el dueño (owned_vehicles) pueda usar el seguro a distancia.
  - `ox_fuel` o `LegacyFuel`: combustible. Si no hay ninguno, usa el tanque de GTA.
  - `pma-voice`: indicador de voz y alcance.

## Instalación
1. Copia `lsn_hud` a tus resources. Reemplaza `realengine_vehicles` por la versión 1.4 de este paquete (no cambia la base de datos).
2. En el `server.cfg`, después de sus dependencias:
   ```
   ensure oxmysql
   ensure es_extended
   ensure ox_lib
   ensure esx_status
   ensure esx_basicneeds
   ensure realengine
   ensure realengine_vehicles
   ensure lsn_hud
   ```
3. Si tenías otro HUD (barras de esx_status, otro velocímetro), apágalo. En tu `esx_status/config.lua` ya está `Config.Display = false`, así que no hay que tocar nada ahí.
4. No usa tablas nuevas: los ajustes de cada jugador se guardan en su propio cliente.

## Comandos
| Comando | Qué hace |
|---|---|
| `/lsnhud` | Ajustes del HUD: estilo de velocímetro, km/h o mph, color, tamaño, qué mostrar, volumen y **mover elementos** |
| `/hud` | Oculta o muestra todo el HUD |
| `/cine` | Modo cine (barras negras, sin HUD) |
| `/vehiculo` | Menú del vehículo |
| `/radio` | CarPlay en la pantalla de música |

## Teclas (cada jugador las cambia en Configuración › Asignación de teclas › FiveM)
| Tecla | Acción |
|---|---|
| J | Control de crucero (se desactiva al frenar, con el freno de mano o en un choque) |
| ← / → | Direccional izquierda / derecha (se apagan solas al terminar la curva) |
| ↑ | Luces de emergencia (si tu teléfono usa la flecha arriba, cámbiala en `Config.Keys.hazards`) |
| B | Cinturón (con cinturón no puedes bajarte; sin él sales por el parabrisas en choques fuertes) |
| G | Encender / apagar motor |
| L | Seguro (dentro, o cerca del auto con el control remoto) |
| K | Menú del vehículo |
| Y | CarPlay |

## Lo que ve todo el servidor
El servidor valida cada acción y la guarda en el vehículo (statebags). Todos los jugadores cerca la ven igual:
- **Direccionales y luces de emergencia**: solo el conductor.
- **Luz interior**: conductor o copiloto.
- **Puertas y vidrios**: el conductor maneja todas; cada pasajero solo la suya. Capó y maletero: conductor.
- **Techo convertible**: conductor, con el auto detenido.
- **Seguro**: parpadeo de luces y sonido del control para los que están cerca.
- **Radio**: el conductor y el copiloto la manejan. Los que van adentro la escuchan con el volumen de la radio; los de afuera la oyen más bajo con la distancia, y todavía más bajo si va todo cerrado (vidrios arriba, puertas cerradas, techo puesto).

## Radio de YouTube
- Pega un link de YouTube (watch, youtu.be, shorts, music, live) y toca **Reproducir** o **A la cola**.
- Pausa, detener, siguiente, cola de hasta 15 canciones y volumen de la radio. Cada jugador tiene además **su propio volumen** (en CarPlay o en `/lsnhud`).
- Todos escuchan el mismo segundo de la canción: el servidor guarda cuándo empezó y cada cliente se corrige si se desfasa más de 3 s.
- Al empezar una canción se apaga la radio de GTA de ese auto.
- Algunos videos no se pueden reproducir fuera de YouTube (lo decide quien lo subió). En ese caso avisa y pasa a la siguiente.
- El servidor solo guarda el ID del video (11 caracteres), nunca el link que escribe el jugador.
- El reloj de la radio es el del servidor: cada cliente corrige el suyo al entrar, así no importa si su PC tiene la hora corrida.

### Si la radio no suena
- Desde 2025 YouTube rechaza los reproductores que no mandan la cabecera *Referer* (aparece el **error 153**). El HUD ya la manda; no pongas otro `<meta name="referrer">` en `html/index.html`.
- Algunos videos (música con derechos de discográfica, sobre todo) no se dejan reproducir fuera de YouTube. El HUD avisa y salta a la siguiente de la cola. Prueba con otro link de la misma canción (lyric video, audio oficial).

## Seguro y tu script de llaves
Por defecto pueden poner el seguro: el que va manejando y el dueño (owned_vehicles). Si tienes un script de llaves, conéctalo en `config.lua`:
```lua
function Config.Lock.hasKeys(src, plate, veh)
    return exports.tu_script_de_llaves:hasKey(src, plate)
end
```
Si ya tienes otro sistema de seguro, pon `Config.Lock.enabled = false`.

## Panel de vuelo
Aparece al piloto y al copiloto de aviones y helicópteros: horizonte artificial, velocidad en nudos, altitud en pies con el suelo marcado, velocidad vertical, rumbo con el waypoint del mapa en magenta, viento, radioaltímetro, tren de aterrizaje y alertas **PULL UP**, **STALL**, **GEAR**, **ENGINE**, **ROTOR** y **FUEL** con sonido. Si en algún avión el horizonte se inclina al revés, pon `Config.Aircraft.invertRoll = true`.

## Exports
Cliente:
```lua
exports.lsn_hud:setHidden(true)      -- ocultar el HUD (cámaras, cinemáticas)
exports.lsn_hud:hasSeatbelt()        -- ¿lleva el cinturón?
exports.lsn_hud:getCruise()          -- velocidad del crucero en m/s o nil
exports.lsn_hud:getSettings()
```
Servidor:
```lua
exports.lsn_hud:setLocked(vehiculo, true)
```
El cinturón también queda en la statebag del jugador (`Player(src).state.lsnBelt`), útil para que la policía multe.

## Pruebas para hacer en el juego
1. **A pie**: vida, chaleco (solo si tienes), comida, sed, voz, brújula y calle encima del minimapa. Métete al agua: aparece el oxígeno.
2. **Velocímetro**: súbete a tu auto. Prueba los 4 estilos en `/lsnhud` y cambia a mph: el odómetro pasa a millas. En "Agujas" se tiene que ver la calle a través de los relojes.
2b. **Radio de época**: súbete a un Tornado o un Peyote y pulsa Y: tiene que salir la radio de época, no CarPlay. En un auto moderno, CarPlay con el auto pintado de su color.
3. **Crucero**: acelera a más de 30 km/h y pulsa J. Suelta el acelerador: mantiene la velocidad. Frena: se apaga.
4. **Direccionales**: pon una, y pide a otro jugador que mire tu auto: debe verla. Gira en una esquina: se apaga sola.
5. **Menú (K)**: abre el maletero, baja tu vidrio, prende la luz interior. Otro jugador debe verlo igual.
6. **Radio (Y)**: pega un link, sube al copiloto y que pause desde su lado. Bájate y aléjate: el volumen baja.
7. **Daños**: `/repiezas oil 10` (admin de realengine): se enciende el testigo de aceite y en CarPlay › Estado aparece la pieza en rojo.
8. **Avión**: despega, sube el tren y baja rápido cerca del suelo: alerta PULL UP y GEAR.
9. **Mover elementos**: `/lsnhud` › Mover elementos, arrastra el velocímetro, Listo, Guardar.
