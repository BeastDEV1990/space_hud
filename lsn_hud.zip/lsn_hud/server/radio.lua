-- ============================================================
--  LSN HUD - server/radio.lua
--  Radio de YouTube por vehiculo. Solo se guarda el ID del video
--  (11 caracteres), nunca el link que escribio el jugador.
--
--  Statebag 'lsnRadio' del vehiculo:
--   { id, title, t = inicio (epoch), p = pausado, pos = segundo
--     donde se pauso, vol = 0-100, n = numero de pista, q = cola }
-- ============================================================

local R = Config.Radio
local lastAction = {}

local function validId(id)
    return type(id) == 'string' and #id == 11 and id:match('^[%w_%-]+$') ~= nil
end

local function cleanTitle(t)
    if type(t) ~= 'string' then return nil end
    t = t:gsub('[%c<>]', ''):gsub('^%s+', ''):gsub('%s+$', '')
    t = t:sub(1, 90)
    return t ~= '' and t or nil
end

local function copyRadio(r)
    if type(r) ~= 'table' then return nil end
    local q = {}
    if type(r.q) == 'table' then
        for _, it in ipairs(r.q) do q[#q + 1] = { id = it.id, title = it.title } end
    end
    return { id = r.id, title = r.title, t = r.t, p = r.p, pos = r.pos, vol = r.vol, n = r.n, q = q }
end

local function start(r, id, title, prev)
    r = r or {}
    r.id = id
    r.title = title
    r.t = os.time()
    r.p = false
    r.pos = 0
    r.vol = r.vol or (prev and prev.vol) or 60
    r.n = ((prev and prev.n) or r.n or 0) + 1
    r.q = r.q or {}
    return r
end

local function nextTrack(r)
    local item = table.remove(r.q, 1)
    if not item then return nil end
    return start(r, item.id, item.title, r)
end

RegisterNetEvent('lsn_hud:radio', function(netId, cmd, arg, title)
    local src = source
    if not R.enabled or type(cmd) ~= 'string' then return end
    local veh = SV.vehicle(netId)
    if not veh then return end
    local seat = SV.seat(src, veh)
    if not seat then return end
    if not R.controlSeats[seat] then
        return TriggerClientEvent('lsn_hud:radio:msg', src, 'radioNoSeat')
    end

    -- anti-spam (el aviso de "termino" no cuenta)
    if cmd ~= 'ended' and cmd ~= 'vol' then
        local now = GetGameTimer() / 1000.0
        if lastAction[src] and now - lastAction[src] < R.cooldown then return end
        lastAction[src] = now
    elseif not SV.allow(src, 'radio', 10) then
        return
    end

    local st = Entity(veh).state
    local cur = copyRadio(st.lsnRadio)
    local new = cur

    if cmd == 'play' then
        if not validId(arg) then return TriggerClientEvent('lsn_hud:radio:msg', src, 'radioBadLink') end
        new = start(cur, arg, cleanTitle(title), cur)

    elseif cmd == 'queue' then
        if not validId(arg) then return TriggerClientEvent('lsn_hud:radio:msg', src, 'radioBadLink') end
        if not cur then
            new = start(nil, arg, cleanTitle(title), nil)
        elseif #cur.q >= R.maxQueue then
            return TriggerClientEvent('lsn_hud:radio:msg', src, 'radioQueueFull')
        else
            cur.q[#cur.q + 1] = { id = arg, title = cleanTitle(title) }
            TriggerClientEvent('lsn_hud:radio:msg', src, 'radioQueued')
        end

    elseif cmd == 'toggle' then
        if not cur then return end
        if cur.p then
            cur.t = os.time() - (cur.pos or 0)
            cur.p = false
        else
            cur.pos = math.max(0, os.time() - cur.t)
            cur.p = true
        end

    elseif cmd == 'stop' then
        new = nil

    elseif cmd == 'next' then
        if not cur then return end
        new = nextTrack(cur)

    elseif cmd == 'ended' then
        -- varios clientes avisan: solo cuenta el de la pista actual
        if not cur or tonumber(arg) ~= cur.n then return end
        new = nextTrack(cur)

    elseif cmd == 'vol' then
        if not cur then return end
        cur.vol = math.min(math.max(math.floor(tonumber(arg) or cur.vol), 0), 100)

    elseif cmd == 'remove' then
        if not cur then return end
        local i = math.floor(tonumber(arg) or 0)
        if cur.q[i] then table.remove(cur.q, i) end

    elseif cmd == 'clear' then
        if not cur then return end
        cur.q = {}

    else
        return
    end

    st:set('lsnRadio', new, true)
end)

AddEventHandler('playerDropped', function()
    lastAction[source] = nil
end)
