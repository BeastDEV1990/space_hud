-- ============================================================
--  LSN HUD - server/main.lua
--  Valida y replica el estado de los vehiculos (statebags),
--  gestiona permisos de administrador y persiste la configuracion
--  global del servidor (logo del HUD).
-- ============================================================

SV = {}

-- ------------------------------------------------------------
-- Utilidades
-- ------------------------------------------------------------
function SV.vehicle(netId)
    netId = tonumber(netId)
    if not netId then return nil end
    local veh = NetworkGetEntityFromNetworkId(netId)
    if not veh or veh == 0 or not DoesEntityExist(veh) or GetEntityType(veh) ~= 2 then return nil end
    return veh
end

-- asiento del jugador dentro de ese vehiculo (nil si no esta adentro)
function SV.seat(src, veh)
    local ped = GetPlayerPed(src)
    if ped == 0 or GetVehiclePedIsIn(ped, false) ~= veh then return nil end
    for s = -1, 14 do
        if GetPedInVehicleSeat(veh, s) == ped then return s end
    end
    return nil
end

-- limite de acciones por segundo por jugador
local buckets = {}
function SV.allow(src, kind, perSecond)
    local now = GetGameTimer()
    local key = src .. ':' .. kind
    local b = buckets[key]
    if not b or now - b.t > 1000 then
        buckets[key] = { t = now, n = 1 }
        return true
    end
    b.n = b.n + 1
    return b.n <= perSecond
end

AddEventHandler('playerDropped', function()
    local prefix = source .. ':'
    for k in pairs(buckets) do
        if k:sub(1, #prefix) == prefix then buckets[k] = nil end
    end
end)

function SV.notify(src, msg, kind)
    TriggerClientEvent('ox_lib:notify', src, { description = msg, type = kind or 'inform' })
end

local function setBit(v, i, on)
    v = tonumber(v) or 0
    if on then return v | (1 << i) end
    return v & ~(1 << i)
end

-- puerta y vidrio "propios" de cada pasajero
local OWN_DOOR = { [0] = 1, [1] = 2, [2] = 3 }

-- ------------------------------------------------------------
-- Panel Admin y configuracion global del servidor (Logo)
-- ------------------------------------------------------------
local SERVER_KVP = 'lsn_hud_server_cfg'

local function defaultServerCfg()
    local d = Config.ServerDefaults or {}
    local p = d.logoPos or { x = 93.5, y = 2.4 }
    return {
        logoEnabled = d.logoEnabled == true,
        logoUrl     = type(d.logoUrl) == 'string' and d.logoUrl or '',
        logoSize    = tonumber(d.logoSize) or 68,
        logoOpacity = tonumber(d.logoOpacity) or 90,
        logoPos     = { x = tonumber(p.x) or 93.5, y = tonumber(p.y) or 2.4 },
    }
end

local function validLogoUrl(url)
    if type(url) ~= 'string' then return false end
    local trimmed = url:gsub('^%s+', ''):gsub('%s+$', '')
    if trimmed == '' then return true, '' end
    local maxBytes = (Config.Admin and Config.Admin.maxLogoBytes) or 240000
    if #trimmed > maxBytes then return false, 'too_big' end
    if trimmed:match('^https?://[%S]+$') then return true, trimmed end
    if trimmed:match('^data:image/[%w%+%-]+;base64,[%w%+/=]+$') then return true, trimmed end
    return false, 'invalid'
end

local function sanitizeServerCfg(raw)
    local cfg = defaultServerCfg()
    if type(raw) ~= 'table' then return cfg, true end

    cfg.logoEnabled = raw.logoEnabled == true
    local okUrl, cleaned = validLogoUrl(raw.logoUrl or '')
    if not okUrl then return nil, cleaned end
    cfg.logoUrl = cleaned

    cfg.logoSize = math.min(math.max(math.floor(tonumber(raw.logoSize) or cfg.logoSize), 28), 220)
    cfg.logoOpacity = math.min(math.max(math.floor(tonumber(raw.logoOpacity) or cfg.logoOpacity), 10), 100)

    if type(raw.logoPos) == 'table' and tonumber(raw.logoPos.x) and tonumber(raw.logoPos.y) then
        cfg.logoPos = {
            x = math.min(math.max(tonumber(raw.logoPos.x), 0), 100),
            y = math.min(math.max(tonumber(raw.logoPos.y), 0), 100),
        }
    end
    return cfg, true
end

local serverCfg = defaultServerCfg()
do
    local raw = GetResourceKvpString(SERVER_KVP)
    if raw and raw ~= '' then
        local ok, decoded = pcall(json.decode, raw)
        if ok and type(decoded) == 'table' then
            local clean = sanitizeServerCfg(decoded)
            if clean then serverCfg = clean end
        end
    end
end

function SV.isAdmin(src)
    if not src or src <= 0 then return false end
    local adm = Config.Admin or {}
    if adm.ace and adm.ace ~= '' and IsPlayerAceAllowed(src, adm.ace) then return true end
    if IsPlayerAceAllowed(src, 'command') then return true end
    local xPlayer = ESX and ESX.GetPlayerFromId(src)
    if xPlayer and type(adm.groups) == 'table' then
        local grp = xPlayer.getGroup and xPlayer.getGroup() or xPlayer.group
        if grp and adm.groups[grp] then return true end
    end
    return false
end

lib.callback.register('lsn_hud:getServerState', function(src)
    return {
        isAdmin = SV.isAdmin(src),
        server = serverCfg,
    }
end)

RegisterNetEvent('lsn_hud:admin:saveServerConfig', function(data)
    local src = source
    if not SV.allow(src, 'admin_cfg', 2) then return end
    if not SV.isAdmin(src) then
        return SV.notify(src, Config.Text.adminOnly or 'Sin permisos', 'error')
    end

    local clean, err = sanitizeServerCfg(data)
    if not clean then
        if err == 'too_big' then
            return SV.notify(src, Config.Text.logoTooBig or 'Imagen demasiado grande', 'error')
        end
        return SV.notify(src, Config.Text.logoInvalid or 'Enlace o imagen no válidos', 'error')
    end

    serverCfg = clean
    SetResourceKvp(SERVER_KVP, json.encode(serverCfg))
    TriggerClientEvent('lsn_hud:serverConfig', -1, serverCfg)
    SV.notify(src, Config.Text.serverSaved or 'Guardado', 'success')
end)

-- ------------------------------------------------------------
-- Estado del vehiculo
-- ------------------------------------------------------------
RegisterNetEvent('lsn_hud:veh:set', function(netId, key, value)
    local src = source
    if not SV.allow(src, 'set', 8) then return end
    local veh = SV.vehicle(netId)
    if not veh then return end
    local seat = SV.seat(src, veh)
    if not seat then return end
    local st = Entity(veh).state

    if key == 'ind' then
        local v = math.floor(tonumber(value) or -1)
        if seat ~= -1 or v < 0 or v > 3 then return end
        st:set('lsnInd', v, true)

    elseif key == 'int' then
        if seat ~= -1 and seat ~= 0 then return end
        st:set('lsnInt', value == true, true)

    elseif key == 'door' then
        if type(value) ~= 'table' then return end
        local i = math.floor(tonumber(value.i) or -1)
        if i < 0 or i > 5 then return end
        if seat ~= -1 and OWN_DOOR[seat] ~= i then return end
        st:set('lsnDoors', setBit(st.lsnDoors, i, value.open == true), true)

    elseif key == 'win' then
        if type(value) ~= 'table' then return end
        local i = math.floor(tonumber(value.i) or -1)
        if i < 0 or i > 3 then return end
        if seat ~= -1 and OWN_DOOR[seat] ~= i then return end
        st:set('lsnWin', setBit(st.lsnWin, i, value.down == true), true)

    elseif key == 'roof' then
        if seat ~= -1 then return end
        local v = GetEntityVelocity(veh)
        if #v > 2.0 then return end
        st:set('lsnRoof', value == true, true)
    end
end)

-- ------------------------------------------------------------
-- Seguro
-- ------------------------------------------------------------
local ownerCache = {}   -- ['src:placa'] = { ok, t }

local function trim(p)
    return (tostring(p or ''):gsub('^%s+', ''):gsub('%s+$', ''))
end

local function isOwner(src, plate)
    if GetResourceState('oxmysql') ~= 'started' then return false end
    local xPlayer = ESX and ESX.GetPlayerFromId(src)
    if not xPlayer then return false end
    local key = src .. ':' .. plate
    local c = ownerCache[key]
    if c and os.time() - c.t < 60 then return c.ok end

    local p = promise.new()
    exports.oxmysql:scalar('SELECT 1 FROM `owned_vehicles` WHERE `owner` = ? AND `plate` IN (?, ?) LIMIT 1',
        { xPlayer.identifier, plate, trim(plate) }, function(r) p:resolve(r) end)
    local ok = Citizen.Await(p) ~= nil
    ownerCache[key] = { ok = ok, t = os.time() }
    return ok
end

function SV.canLock(src, veh)
    local seat = SV.seat(src, veh)
    if Config.Lock.allowDriver and seat == -1 then return true end
    local plate = GetVehicleNumberPlateText(veh) or ''
    local okKeys, keys = pcall(Config.Lock.hasKeys, src, trim(plate), veh)
    if okKeys and keys then return true end
    if Config.Lock.allowOwner and isOwner(src, plate) then return true end
    return false
end

RegisterNetEvent('lsn_hud:veh:lock', function(netId)
    local src = source
    if not Config.Lock.enabled or not SV.allow(src, 'lock', 2) then return end
    local veh = SV.vehicle(netId)
    if not veh then return end
    local ped = GetPlayerPed(src)
    if #(GetEntityCoords(ped) - GetEntityCoords(veh)) > Config.Lock.distance + 3.0 then return end

    if not SV.canLock(src, veh) then
        return SV.notify(src, Config.Text.noKeys, 'error')
    end

    local locked = GetVehicleDoorLockStatus(veh) >= 2
    SetVehicleDoorsLocked(veh, locked and 1 or 2)
    Entity(veh).state:set('lsnLock', not locked, true)
    SV.notify(src, locked and Config.Text.unlocked or Config.Text.locked, locked and 'inform' or 'success')
    if GetVehiclePedIsIn(ped, false) ~= veh then
        TriggerClientEvent('lsn_hud:veh:fob', src)
    end
end)

-- Reloj del servidor (la radio se sincroniza con el)
lib.callback.register('lsn_hud:time', function()
    return os.time()
end)

-- ------------------------------------------------------------
-- Radio del vehiculo (CarPlay o de epoca), guardada por placa
-- ------------------------------------------------------------
local HU = Config.HeadUnit

local function headUnitKey(veh)
    local plate = trim(GetVehicleNumberPlateText(veh)):upper()
    if plate == '' then return nil end
    return 'hu:' .. plate
end

local function setHeadUnit(veh, unit)
    if unit ~= 'carplay' and unit ~= 'retro' then unit = nil end
    Entity(veh).state:set('lsnHeadUnit', unit, true)
    local key = headUnitKey(veh)
    if key then
        if unit then SetResourceKvp(key, unit) else DeleteResourceKvp(key) end
    end
end

-- al subir a un auto: cargar la radio que tenga guardada su placa
RegisterNetEvent('lsn_hud:headUnit:sync', function(netId)
    local src = source
    if not SV.allow(src, 'husync', 4) then return end
    local veh = SV.vehicle(netId)
    if not veh or not SV.seat(src, veh) then return end
    if Entity(veh).state.lsnHeadUnit ~= nil then return end
    local key = headUnitKey(veh)
    local unit = key and GetResourceKvpString(key)
    if unit == 'carplay' or unit == 'retro' then
        Entity(veh).state:set('lsnHeadUnit', unit, true)
    end
end)

local function jobAllowed(src)
    if not HU.jobs then return true end
    local xPlayer = ESX and ESX.GetPlayerFromId(src)
    local job = xPlayer and xPlayer.job
    if not job then return false end
    local min = HU.jobs[job.name]
    return min ~= nil and (tonumber(job.grade) or 0) >= min
end

-- instalar con el item (el cliente ya hizo la barra de progreso)
RegisterNetEvent('lsn_hud:headUnit:install', function(netId, unit)
    local src = source
    if not HU.items or (unit ~= 'carplay' and unit ~= 'retro') then return end
    if not SV.allow(src, 'huinst', 1) then return end
    local veh = SV.vehicle(netId)
    if not veh or SV.seat(src, veh) ~= -1 then return end
    if not jobAllowed(src) then return SV.notify(src, Config.Text.huJob, 'error') end
    if GetResourceState('ox_inventory') ~= 'started' then return end

    local item = unit == 'carplay' and HU.carplayItem or HU.retroItem
    if (exports.ox_inventory:GetItemCount(src, item) or 0) < 1 then
        return SV.notify(src, Config.Text.huNoItem, 'error')
    end
    if not exports.ox_inventory:RemoveItem(src, item, 1) then return end
    setHeadUnit(veh, unit)
    SV.notify(src, unit == 'carplay' and Config.Text.huDoneCarplay or Config.Text.huDoneRetro, 'success')
end)

exports('setHeadUnit', function(veh, unit)
    if not veh or not DoesEntityExist(veh) then return false end
    setHeadUnit(veh, unit)
    return true
end)

exports('setLocked', function(veh, state)
    if not veh or not DoesEntityExist(veh) then return false end
    SetVehicleDoorsLocked(veh, state and 2 or 1)
    Entity(veh).state:set('lsnLock', state and true or false, true)
    return true
end)
