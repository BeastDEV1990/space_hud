-- ============================================================
--  LSN HUD - items para ox_inventory
--  Pega esto dentro de ox_inventory/data/items.lua (antes del
--  ultimo "}") y copia las imagenes de install/images a
--  ox_inventory/web/images/. Reinicia ox_inventory.
--
--  Se usan sentado al volante con el auto detenido. El kit se
--  gasta al terminar la instalacion (lo quita el servidor).
-- ============================================================

['kit_carplay'] = {
    label = 'Kit CarPlay',
    weight = 1200,
    stack = true,
    close = true,
    consume = 0,
    description = 'Pantalla táctil con CarPlay. Úsala sentado al volante de un auto clásico para cambiarle la radio.',
    client = { export = 'lsn_hud.useCarplayKit' },
},

['radio_clasica'] = {
    label = 'Radio clásica',
    weight = 1500,
    stack = true,
    close = true,
    consume = 0,
    description = 'Radio de época con casetera. Úsala sentado al volante para darle un toque retro a cualquier auto.',
    client = { export = 'lsn_hud.useRetroRadio' },
},
