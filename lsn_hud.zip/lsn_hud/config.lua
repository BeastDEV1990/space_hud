Config = {}

-- ============================================================
--  LSN HUD - Configuracion (Optimizado + Minimalista)
--  HUD de jugador, velocimetros, panel de aeronaves, menu de
--  vehiculo, CarPlay, radio sincronizada y panel admin.
-- ============================================================

Config.Debug = false

-- Comandos
Config.Commands = {
    settings  = 'lsnhud',      -- abre el panel de ajustes del HUD (cada jugador)
    admin     = 'lsnhudadmin', -- abre directamente la pestana Admin / Servidor
    toggle    = 'hud',         -- oculta / muestra todo el HUD
    cinematic = 'cine',        -- modo cine (barras negras, sin HUD)
    vehicle   = 'vehiculo',    -- abre el menu del vehiculo
    radio     = 'radio',       -- abre CarPlay en la pantalla de musica
}

-- Permisos del panel de administrador (logo del servidor y ajustes globales)
-- Se concede acceso si el jugador tiene el permiso ACE o alguno de los grupos ESX.
Config.Admin = {
    ace = 'lsn_hud.admin',
    groups = {
        admin = true,
        superadmin = true,
        owner = true,
        god = true,
        mod = true,
    },
    maxLogoBytes = 240000, -- limite maximo para logo subido en base64 (~240 KB)
}

-- Configuracion global por defecto del servidor (se guarda en KVP al editar desde el panel admin)
Config.ServerDefaults = {
    logoEnabled = false,
    logoUrl     = '',
    logoSize    = 68,          -- px (28 - 220)
    logoOpacity = 90,          -- %  (10 - 100)
    logoPos     = { x = 93.5, y = 2.4 }, -- % por defecto (arriba a la derecha)
}

-- Teclas por defecto. Cada jugador las cambia en
-- Ajustes > Asignacion de teclas > FiveM
Config.Keys = {
    cruise      = 'J',
    indLeft     = 'LEFT',     -- flecha izquierda: direccional izquierda
    indRight    = 'RIGHT',    -- flecha derecha: direccional derecha
    hazards     = 'UP',       -- flecha arriba: luces de emergencia
    seatbelt    = 'B',
    engine      = 'G',        -- encender / apagar motor
    lock        = 'L',        -- seguro (desde dentro o cerca del auto)
    vehicleMenu = 'M',
    carplay     = 'K',
}

-- ------------------------------------------------------------
-- Ajustes por defecto de cada jugador (los cambia en /lsnhud)
-- ------------------------------------------------------------
Config.DefaultSettings = {
    speedo         = 'minimal',   -- 'minimal' | 'digital' | 'analog' | 'sport'
    units          = 'kmh',       -- 'kmh' | 'mph'
    accent         = '#3fa9ff',   -- color de acento
    scale          = 0.9,
    minimapOnFoot  = true,        -- minimapa tambien a pie
    statusMode     = 'always',    -- 'always' | 'auto' (comida/sed solo cuando bajan)
    showStreet     = true,
    showCompass    = true,
    compassStyle   = 'minimal',   -- 'minimal' | 'bar' | 'compact'
    compassWidth   = 280,         -- 180 - 420 px
    compassDegrees = true,        -- mostrar marcas numericas de grados
    compassHeading = true,        -- mostrar indicador de rumbo exacto
    showVoice      = true,
    beltChime      = true,        -- aviso sonoro del cinturon
    alertSounds    = true,        -- sonidos de direccionales, crucero y alertas de vuelo
    musicVolume    = 100,         -- volumen personal de la radio (0-100)
    pos            = {},          -- posiciones personalizadas (se guardan solas)
}

Config.Accents = { '#3fa9ff', '#22c55e', '#f59e0b', '#ef4444', '#a78bfa', '#ec4899', '#14b8a6', '#e5e7eb' }

-- ------------------------------------------------------------
-- Estado del jugador
-- ------------------------------------------------------------
Config.Status = {
    useEsxStatus = true,       -- hambre y sed desde esx_status
    autoShowBelow = 35,        -- en modo 'auto', mostrar comida/sed bajo este %
    hideDefaultHealth = true,  -- ocultar las barras de vida/chaleco de GTA bajo el radar
}

-- ------------------------------------------------------------
-- Minimapa
-- ------------------------------------------------------------
Config.Minimap = {
    square = true,         -- minimapa cuadrado (false = el de GTA)
    zoomOnFoot = 1100,     -- zoom del radar a pie (GTA usa ~1100)
}

-- ------------------------------------------------------------
-- Vehiculos
-- ------------------------------------------------------------
Config.Vehicle = {
    -- Barcos: velocidad en nudos
    boatsInKnots = true,
    -- Tipos de vehiculo sin velocimetro ni odometro
    noSpeedo = { bicycle = true },
    -- Tanque: si usas ox_fuel o LegacyFuel se detecta solo
    fuelResource = 'auto',   -- 'auto' | 'ox_fuel' | 'LegacyFuel' | 'native'
    -- Marchas del velocimetro: 'auto' o 'manual'
    redlineRpm = 7000,       -- rpm que se muestran al 100%
}

Config.Cruise = {
    minKmh = 30,         -- velocidad minima para activarlo
    -- clases donde NO hay crucero (13 bicicletas, 14 barcos, 15 helis, 16 aviones, 21 trenes)
    blockedClasses = { [13] = true, [14] = true, [15] = true, [16] = true, [21] = true },
}

Config.Seatbelt = {
    enabled = false,
    -- Sin cinturon el jugador sale por el parabrisas en choques fuertes
    ejectWithoutBelt = false,
    -- Con cinturon no se puede salir sin quitarselo antes (F)
    blockExitWhenBuckled = false,
    -- Velocidad desde la que suena el aviso
    chimeKmh = 20,
    -- clases sin cinturon (8 motos, 13 bicis, 14 barcos)
    noBeltClasses = { [8] = true, [13] = true, [14] = true },
}

Config.Engine = {
    -- El motor no arranca solo al subir: se enciende con la tecla
    -- (G por defecto) o desde el menu. Si es false, GTA lo enciende solo.
    manualStart = false,
}

-- Seguro de puertas
Config.Lock = {
    enabled = true,
    distance = 10.0,       -- distancia maxima para usar el control remoto
    allowDriver = true,
    allowOwner = true,
}
function Config.Lock.hasKeys(src, plate, veh)
    return false
end

-- ------------------------------------------------------------
-- Aeronaves
-- ------------------------------------------------------------
Config.Aircraft = {
    stallKnots = 65,
    pullUpAgl = 400,
    pullUpVs = -1800,
    gearWarnAgl = 600,
    invertRoll = false,
}

-- ------------------------------------------------------------
-- Radio / CarPlay
-- ------------------------------------------------------------
Config.Radio = {
    enabled = true,
    controlSeats = { [-1] = true, [0] = true },
    range = 25.0,
    refDistance = 2.0,
    closedFactor = 0.0,
    open = { window = 0.75, door = 1.0, roof = 1.0, trunk = 0.45, hood = 0.15 },
    listenerInClosedCar = 0.3,
    maxQueue = 15,
    blockedClasses = { [13] = true, [21] = true },
    cooldown = 1.0,
}

-- ------------------------------------------------------------
-- Autos viejos: radio de epoca en vez de CarPlay
-- ------------------------------------------------------------
Config.Retro = {
    enabled = true,
    classes = { [5] = true },
    models = {
        'blade', 'buccaneer', 'buccaneer2', 'chino', 'chino2', 'clique', 'deviant', 'dukes', 'dukes2',
        'ellie', 'faction', 'faction2', 'hermes', 'hotknife', 'hustler', 'impaler', 'lurcher', 'moonbeam',
        'moonbeam2', 'nightshade', 'peyote2', 'phoenix', 'picador', 'ratloader', 'ratloader2', 'ruiner',
        'sabregt', 'sabregt2', 'slamvan', 'slamvan2', 'stalion', 'stalion2', 'tampa', 'tulip', 'vamos',
        'vigero', 'virgo', 'virgo2', 'virgo3', 'voodoo', 'voodoo2', 'yosemite',
        'emperor', 'emperor2', 'emperor3', 'glendale', 'glendale2', 'ingot', 'primo', 'regina',
        'stratum', 'warrener', 'washington', 'dynasty', 'issi3', 'blista2', 'futo',
        'journey', 'camper', 'surfer', 'surfer2', 'youga', 'bodhi2', 'rebel', 'rebel2', 'rancherxl', 'rancherxl2',
    },
    modern = {},
}

-- ------------------------------------------------------------
-- Instalar CarPlay o la radio de epoca con items (ox_inventory)
-- ------------------------------------------------------------
Config.HeadUnit = {
    items = true,
    carplayItem = 'kit_carplay',
    retroItem = 'radio_clasica',
    seconds = 12,
    jobs = { bennys = 0, hayes = 0 },
}

-- ------------------------------------------------------------
-- Textos
-- ------------------------------------------------------------
Config.Text = {
    cruiseOn       = 'Crucero activado a %s',
    cruiseOff      = 'Crucero desactivado',
    cruiseTooSlow  = 'Acelera a más de %s para activar el crucero',
    beltOn         = 'Cinturón abrochado',
    beltOff        = 'Cinturón desabrochado',
    beltBlocked    = 'Quítate el cinturón (B) para bajarte',
    engineOn       = 'Motor encendido',
    engineOff      = 'Motor apagado',
    locked         = 'Vehículo con seguro',
    unlocked       = 'Vehículo sin seguro',
    noKeys         = 'No tienes las llaves de este vehículo',
    noVehicleNear  = 'No hay un vehículo cerca',
    isLocked       = 'El vehículo tiene seguro',
    noRoof         = 'Este vehículo no tiene techo convertible',
    roofSpeed      = 'Detente para mover el techo',
    radioNoSeat    = 'Solo el conductor y el copiloto pueden usar la radio',
    radioBadLink   = 'Ese link no es de YouTube',
    radioQueued    = 'Agregada a la cola',
    radioQueueFull = 'La cola está llena',
    radioEmbed     = 'Ese video no permite reproducirse fuera de YouTube. Prueba otro.',
    radioNoRadio   = 'Este vehículo no tiene radio',
    hudHidden      = 'HUD oculto. Escribe /hud para mostrarlo.',
    hudShown       = 'HUD visible.',
    notInVehicle   = 'No estás en un vehículo',
    huDriver       = 'Siéntate al volante para instalarlo',
    huNoCar        = 'Solo se puede instalar en autos',
    huStop         = 'Detén el vehículo para instalarlo',
    huHasCarplay   = 'Este vehículo ya tiene CarPlay',
    huHasRetro     = 'Este vehículo ya tiene la radio clásica',
    huInstCarplay  = 'Instalando CarPlay...',
    huInstRetro    = 'Instalando la radio clásica...',
    huDoneCarplay  = 'CarPlay instalado',
    huDoneRetro    = 'Radio clásica instalada',
    huNoItem       = 'No tienes el kit',
    huJob          = 'Solo un mecánico puede instalarlo',
    adminOnly      = 'No tienes permisos de administrador para abrir ese panel',
    serverSaved    = 'Configuración global del HUD guardada para todos los jugadores',
    logoTooBig     = 'La imagen del logo es demasiado grande. Usa un archivo más ligero o pega un enlace.',
    logoInvalid    = 'El enlace o imagen del logo no es válido.',
}
