-- ============================================================
--  LSN HUD - client/sync.lua
--  Aplica en ESTE cliente el estado de los vehiculos que el
--  servidor guarda en statebags, para que todo el servidor vea
--  lo mismo:
--    lsnInd   direccionales (0 nada, 1 izq, 2 der, 3 emergencia)
--    lsnInt   luz interior
--    lsnWin   vidrios abajo (bits 0-3)
--    lsnDoors puertas abiertas (bits 0-5: 4 capo, 5 maletero)
--    lsnRoof  techo convertible abierto
--    lsnLock  seguro (solo para el parpadeo y el sonido)
-- ============================================================

local applied = {}   -- [veh] = { ind, int, win, doors, roof }

local function bit(v, i) return (v & (1 << i)) ~= 0 end

local function apply(veh, key, value, animate)
    if veh == 0 or not DoesEntityExist(veh) then return end
    local a = applied[veh]
    if not a then a = {} applied[veh] = a end

    if key == 'lsnInd' then
        local v = tonumber(value) or 0
        if a.ind ~= v then
            SetVehicleIndicatorLights(veh, 1, v == 1 or v == 3)
            SetVehicleIndicatorLights(veh, 0, v == 2 or v == 3)
            a.ind = v
        end

    elseif key == 'lsnInt' then
        local v = value and true or false
        if a.int ~= v then
            SetVehicleInteriorlight(veh, v)
            a.int = v
        end

    elseif key == 'lsnWin' then
        local v = tonumber(value) or 0
        if a.win ~= v then
            for i = 0, 3 do
                local want = bit(v, i)
                if a.win == nil then
                    if want then RollDownWindow(veh, i) end
                elseif want ~= bit(a.win, i) then
                    if want then RollDownWindow(veh, i) else RollUpWindow(veh, i) end
                end
            end
            a.win = v
        end

    elseif key == 'lsnDoors' then
        local v = tonumber(value) or 0
        if a.doors ~= v then
            for i = 0, 5 do
                local want = bit(v, i)
                if a.doors == nil then
                    if want then SetVehicleDoorOpen(veh, i, false, true) end
                elseif want ~= bit(a.doors, i) then
                    if want then SetVehicleDoorOpen(veh, i, false, false)
                    else SetVehicleDoorShut(veh, i, false) end
                end
            end
            a.doors = v
        end

    elseif key == 'lsnRoof' then
        local v = value and true or false
        if a.roof ~= v then
            if v then LowerConvertibleRoof(veh, not animate)
            elseif a.roof ~= nil then RaiseConvertibleRoof(veh, not animate) end
            a.roof = v
        end
    end
end

local KEYS = { 'lsnInd', 'lsnInt', 'lsnWin', 'lsnDoors', 'lsnRoof' }

for _, key in ipairs(KEYS) do
    AddStateBagChangeHandler(key, nil, function(bagName, k, value)
        local veh = GetEntityFromStateBagName(bagName)
        if veh ~= 0 then apply(veh, k, value, true) end
    end)
end

-- seguro: parpadeo de luces y sonido del control para los que estan cerca
AddStateBagChangeHandler('lsnLock', nil, function(bagName, _, value)
    local veh = GetEntityFromStateBagName(bagName)
    if veh == 0 or not applied[veh] then return end   -- recien cargado: sin efectos
    if #(GetEntityCoords(veh) - GetEntityCoords(PlayerPedId())) > 40.0 then return end
    PlaySoundFromEntity(-1, value and 'Remote_Control_Close' or 'Remote_Control_Open', veh, 'PI_Menu_Sounds', false, 0)
    CreateThread(function()
        local times = value and 1 or 2
        for _ = 1, times do
            SetVehicleLights(veh, 2)
            Wait(180)
            SetVehicleLights(veh, 0)
            Wait(160)
        end
    end)
end)

-- vehiculos que entran al rango (los handlers solo avisan cambios)
CreateThread(function()
    while true do
        Wait(1000)
        local pos = GetEntityCoords(PlayerPedId())
        local seen = {}
        for _, veh in ipairs(GetGamePool('CVehicle')) do
            if NetworkGetEntityIsNetworked(veh) and #(GetEntityCoords(veh) - pos) < 150.0 then
                seen[veh] = true
                local st = Entity(veh).state
                if not applied[veh] then applied[veh] = {} end
                for _, key in ipairs(KEYS) do
                    local v = st[key]
                    if v ~= nil then apply(veh, key, v, false) end
                end
                -- solo los que maneja este HUD (los NPC usan sus propias direccionales)
                local ind = tonumber(st.lsnInd)
                if ind and GetVehicleIndicatorLights(veh) ~= ind then
                    applied[veh].ind = nil
                    apply(veh, 'lsnInd', ind, false)
                end
            end
        end
        for veh in pairs(applied) do
            if not seen[veh] then applied[veh] = nil end
        end
    end
end)

-- lo usa el menu: estado actual de un vehiculo
function VEH.bag(veh)
    local st = Entity(veh).state
    return {
        ind = st.lsnInd or 0,
        int = st.lsnInt or false,
        win = st.lsnWin or 0,
        doors = st.lsnDoors or 0,
        roof = st.lsnRoof or false,
    }
end
