-- ============================================================
--  LSN HUD - client/headunit.lua
--  Radio del vehiculo: CarPlay o radio de epoca.
--   * Al subir a un auto, se carga la radio que tenga guardada
--     esa placa (si alguien le instalo otra).
--   * Items de ox_inventory para instalarlas:
--       kit_carplay   -> client = { export = 'lsn_hud.useCarplayKit' }
--       radio_clasica -> client = { export = 'lsn_hud.useRetroRadio' }
-- ============================================================

local H = Config.HeadUnit
local T = Config.Text
local asked = {}

AddEventHandler('lsn_hud:enteredVehicle', function(veh)
    if asked[veh] or not NetworkGetEntityIsNetworked(veh) then return end
    asked[veh] = true
    if Entity(veh).state.lsnHeadUnit == nil then
        TriggerServerEvent('lsn_hud:headUnit:sync', VehToNet(veh))
    end
end)

-- olvidar los autos que ya no existen
CreateThread(function()
    while true do
        Wait(60000)
        for veh in pairs(asked) do
            if not DoesEntityExist(veh) then asked[veh] = nil end
        end
    end
end)

local busy = false
local function install(unit)
    if not H.items or busy then return end
    local veh = VEH.veh
    if veh == 0 or VEH.seat ~= -1 then return HUD.notify(T.huDriver, 'error') end
    if VEH.kind ~= 'car' then return HUD.notify(T.huNoCar, 'error') end
    local retro = VEH.isRetro(veh)
    if unit == 'carplay' and not retro then return HUD.notify(T.huHasCarplay, 'error') end
    if unit == 'retro' and retro then return HUD.notify(T.huHasRetro, 'error') end
    if GetEntitySpeed(veh) > 1.0 then return HUD.notify(T.huStop, 'error') end

    busy = true
    local done = lib.progressBar({
        duration = H.seconds * 1000,
        label = unit == 'carplay' and T.huInstCarplay or T.huInstRetro,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
    })
    busy = false
    if not done or VEH.veh ~= veh or VEH.seat ~= -1 then return end
    TriggerServerEvent('lsn_hud:headUnit:install', VehToNet(veh), unit)
end

exports('useCarplayKit', function() install('carplay') end)
exports('useRetroRadio', function() install('retro') end)
