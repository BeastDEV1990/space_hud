-- ============================================================
--  LSN HUD - client/aircraft.lua
--  Panel de vuelo (PFD) para aviones y helicopteros:
--  horizonte artificial, velocidad (nudos), altitud (pies),
--  velocidad vertical, rumbo, viento, tren, radioaltimetro,
--  waypoint y alertas (perdida, PULL UP, tren, motor).
-- ============================================================

local A = Config.Aircraft
local M_TO_FT = 3.28084
local MS_TO_KN = 1.943844
local MS_TO_FPM = 196.8504

local function bearing(dx, dy)
    -- en GTA +Y es el norte y +X el este
    return (math.deg(math.atan(dx, dy)) + 360.0) % 360.0
end

local function gearState(veh, kind)
    if kind ~= 'plane' then return nil end
    local ok, has = pcall(GetVehicleHasLandingGear, veh)
    if ok and has == false then return nil end
    local s = GetLandingGearState(veh)
    if s == 0 then return 'DN' end
    if s == 3 then return 'UP' end
    return 'TR'
end

local function waypoint(pos)
    if not IsWaypointActive() then return nil end
    local blip = GetFirstBlipInfoId(8)
    if not DoesBlipExist(blip) then return nil end
    local c = GetBlipInfoIdCoord(blip)
    local dx, dy = c.x - pos.x, c.y - pos.y
    return { brg = bearing(dx, dy), nm = math.sqrt(dx * dx + dy * dy) / 1852.0 }
end

local function wind()
    local dir = GetWindDirection()
    local to = bearing(dir.x, dir.y)
    return { from = (to + 180.0) % 360.0, kn = GetWindSpeed() * MS_TO_KN }
end

local showing = false

CreateThread(function()
    while true do
        local veh = VEH.veh
        local kind = VEH.kind
        if veh ~= 0 and (kind == 'plane' or kind == 'heli') and (VEH.seat == -1 or VEH.seat == 0)
            and DoesEntityExist(veh) and HUD.isVisible() then
            showing = true
            local pos = GetEntityCoords(veh)
            local vel = GetEntityVelocity(veh)
            local ias = GetEntitySpeed(veh) * MS_TO_KN
            local gs = math.sqrt(vel.x * vel.x + vel.y * vel.y) * MS_TO_KN
            local agl = GetEntityHeightAboveGround(veh) * M_TO_FT
            local vs = vel.z * MS_TO_FPM
            local inAir = IsEntityInAir(veh) and agl > 8.0
            local eng = math.max(0, math.min(100, GetVehicleEngineHealth(veh) / 10))
            local fuel = VEH.fuel(veh)
            local gear = gearState(veh, kind)
            local roll = GetEntityRoll(veh)
            if A.invertRoll then roll = -roll end

            local warn = {}
            if kind == 'plane' and inAir and agl > 50 and ias < A.stallKnots then warn.stall = true end
            if inAir and agl < A.pullUpAgl and vs < A.pullUpVs then warn.pullup = true end
            if gear == 'UP' and inAir and agl < A.gearWarnAgl and vs < -300 then warn.gear = true end
            if eng < 30 then warn.engine = true end
            if fuel < 10 then warn.fuel = true end

            local rotor = nil
            if kind == 'heli' then
                rotor = math.max(0, math.min(100, math.min(GetHeliMainRotorHealth(veh), GetHeliTailRotorHealth(veh)) / 10))
                if rotor < 35 then warn.rotor = true end
            end

            HUD.send('air', {
                kind = kind,
                ias = ias,
                gs = gs,
                alt = pos.z * M_TO_FT,
                agl = agl,
                vs = vs,
                pitch = GetEntityPitch(veh),
                roll = roll,
                hdg = (360.0 - GetEntityHeading(veh)) % 360.0,
                wind = wind(),
                gear = gear,
                rpm = GetIsVehicleEngineRunning(veh) and GetVehicleCurrentRpm(veh) or 0.0,
                thr = math.max(0.0, GetVehicleThrottleOffset(veh)),
                fuel = fuel,
                eng = eng,
                rotor = rotor,
                on = GetIsVehicleEngineRunning(veh),
                air = inAir,
                wpt = waypoint(pos),
                warn = warn,
            })
            Wait(50)
        else
            if showing then
                showing = false
                HUD.send('air', false)
            end
            Wait(300)
        end
    end
end)
