-- ============================================================
--  LSN HUD - client/main.lua (Optimizado)
--  Nucleo: ajustes del jugador, panel admin/servidor, puente
--  con la NUI, visibilidad, minimapa y componentes de GTA.
-- ============================================================

HUD = {
    settings = {},
    server = Config.ServerDefaults or {},
    isAdmin = false,
    hidden = GetResourceKvpInt('lsn_hud_hidden') == 1,  -- /hud
    cinematic = false,                                   -- /cine
    focus = nil,                                         -- 'menu' | 'settings' | nil
    ready = false,
}

local KVP = 'lsn_hud_settings'
local VALID_BLOCKS = { compass = true, street = true, status = true, speedo = true, air = true, logo = true }

-- ------------------------------------------------------------
-- Utilidades
-- ------------------------------------------------------------
function HUD.send(action, data)
    SendNUIMessage({ a = action, d = data })
end

function HUD.notify(msg, kind)
    lib.notify({ description = msg, type = kind or 'inform' })
end

local function copy(t)
    if type(t) ~= 'table' then return t end
    local o = {}
    for k, v in pairs(t) do o[k] = copy(v) end
    return o
end

-- solo acepta claves conocidas y del mismo tipo que el valor por defecto
local function sanitize(saved)
    local s = copy(Config.DefaultSettings)
    if type(saved) ~= 'table' then return s end
    for k, def in pairs(Config.DefaultSettings) do
        local v = saved[k]
        if v ~= nil and type(v) == type(def) then s[k] = v end
    end
    local styles = { digital = true, analog = true, sport = true, minimal = true }
    if not styles[s.speedo] then s.speedo = Config.DefaultSettings.speedo end
    if s.units ~= 'kmh' and s.units ~= 'mph' then s.units = 'kmh' end
    if s.statusMode ~= 'always' and s.statusMode ~= 'auto' then s.statusMode = 'always' end
    local cStyles = { minimal = true, bar = true, compact = true }
    if not cStyles[s.compassStyle] then s.compassStyle = Config.DefaultSettings.compassStyle end
    s.compassWidth = math.min(math.max(math.floor(tonumber(s.compassWidth) or 280), 180), 420)
    if type(s.accent) ~= 'string' or not s.accent:match('^#%x%x%x%x%x%x$') then s.accent = Config.DefaultSettings.accent end
    s.scale = math.min(math.max(tonumber(s.scale) or 0.9, 0.6), 1.6)
    s.musicVolume = math.min(math.max(math.floor(tonumber(s.musicVolume) or 100), 0), 100)

    -- posiciones: { nombre = { x = %, y = % } }
    local pos = {}
    if type(s.pos) == 'table' then
        for name, p in pairs(s.pos) do
            if type(name) == 'string' and VALID_BLOCKS[name] and type(p) == 'table'
                and tonumber(p.x) and tonumber(p.y) then
                pos[name] = {
                    x = math.min(math.max(tonumber(p.x), 0), 100),
                    y = math.min(math.max(tonumber(p.y), 0), 100),
                }
            end
        end
    end
    s.pos = pos
    return s
end

local function loadSettings()
    local raw = GetResourceKvpString(KVP)
    local ok, data = pcall(json.decode, raw or '')
    HUD.settings = sanitize(ok and data or nil)
end

function HUD.saveSettings(data)
    HUD.settings = sanitize(data)
    SetResourceKvp(KVP, json.encode(HUD.settings))
    HUD.send('settings', HUD.settings)
    TriggerEvent('lsn_hud:settingsChanged', HUD.settings)
end

-- Reloj del servidor en segundos (epoch)
local clockOffset = 0
function HUD.serverTime()
    return GetCloudTimeAsInt() + clockOffset
end
CreateThread(function()
    while true do
        local t1 = GetGameTimer()
        local ok, srv = pcall(lib.callback.await, 'lsn_hud:time', false)
        local rtt = (GetGameTimer() - t1) / 1000.0
        if ok and tonumber(srv) and rtt < 3.0 then
            clockOffset = math.floor(tonumber(srv) + rtt / 2 - GetCloudTimeAsInt() + 0.5)
        end
        Wait(600000)
    end
end)

-- velocidad en las unidades del jugador
function HUD.speedFactor()
    return HUD.settings.units == 'mph' and 2.236936 or 3.6
end
function HUD.speedUnit()
    return HUD.settings.units == 'mph' and 'mph' or 'km/h'
end
function HUD.fmtSpeed(ms)
    return ('%d %s'):format(math.floor(ms * HUD.speedFactor() + 0.5), HUD.speedUnit())
end

-- ------------------------------------------------------------
-- Visibilidad general
-- ------------------------------------------------------------
local lastVisible = nil
function HUD.isVisible()
    return not HUD.hidden and not HUD.cinematic and not IsPauseMenuActive()
        and not IsScreenFadedOut() and not IsPlayerSwitchInProgress()
end

CreateThread(function()
    while true do
        local vis = HUD.isVisible()
        if vis ~= lastVisible then
            lastVisible = vis
            HUD.send('visible', vis)
            if vis then TriggerEvent('lsn_hud:becameVisible') end
        end
        Wait(250)
    end
end)

-- ------------------------------------------------------------
-- Minimapa: marco alineado al radar de GTA (bajo consumo)
-- ------------------------------------------------------------
local minimapScaleform = nil

local function hideDefaultHealthBars()
    if not Config.Status.hideDefaultHealth then return end
    if not minimapScaleform then
        minimapScaleform = RequestScaleformMovie('minimap')
    end
    if HasScaleformMovieLoaded(minimapScaleform) then
        BeginScaleformMovieMethod(minimapScaleform, 'SETUP_HEALTH_ARMOUR')
        ScaleformMovieMethodAddParamInt(3)
        EndScaleformMovieMethod()
    end
end

local function minimapRect()
    local safezone = GetSafeZoneSize()
    local aspect = GetAspectRatio(false)
    local resX, resY = GetActiveScreenResolution()
    local xs, ys = 1.0 / resX, 1.0 / resY
    local w = xs * (resX / (4 * aspect))
    local h = ys * (resY / 5.674)
    local left = xs * (resX * (0.05 * (math.abs(safezone - 1.0) * 10)))
    local bottom = 1.0 - ys * (resY * (0.05 * (math.abs(safezone - 1.0) * 10)))
    return { x = left * 100, y = (bottom - h) * 100, w = w * 100, h = h * 100 }
end

local radarShown = nil
local function updateRadar()
    local inVeh = VEH and VEH.veh ~= 0 or IsPedInAnyVehicle(PlayerPedId(), false)
    local want = HUD.isVisible() and (inVeh or HUD.settings.minimapOnFoot)
    if want ~= radarShown then
        radarShown = want
        DisplayRadar(want)
        HUD.send('minimap', { show = want, rect = minimapRect() })
        if want then hideDefaultHealthBars() end
    end
end

CreateThread(function()
    minimapScaleform = RequestScaleformMovie('minimap')
    while not HasScaleformMovieLoaded(minimapScaleform) do Wait(100) end
    hideDefaultHealthBars()

    local tick = 0
    while true do
        updateRadar()
        tick = tick + 1
        -- refuerzo ligero cada ~1.5s en vez de cada frame (Wait(0))
        if tick % 5 == 0 and radarShown then
            hideDefaultHealthBars()
        end
        Wait(300)
    end
end)

-- cambia la resolucion o el safezone: recalcular el marco
CreateThread(function()
    local last = ''
    while true do
        Wait(2500)
        local r = minimapRect()
        local key = ('%.2f:%.2f:%.2f:%.2f'):format(r.x, r.y, r.w, r.h)
        if key ~= last then
            last = key
            HUD.send('minimap', { show = radarShown, rect = r })
        end
    end
end)

-- ------------------------------------------------------------
-- Componentes de GTA que reemplaza el HUD (solo HideHudComponent)
-- ------------------------------------------------------------
CreateThread(function()
    while true do
        HideHudComponentThisFrame(6)   -- nombre del vehiculo
        HideHudComponentThisFrame(7)   -- zona
        HideHudComponentThisFrame(8)   -- clase del vehiculo
        HideHudComponentThisFrame(9)   -- calle
        if HUD.cinematic then
            HideHudAndRadarThisFrame()
        end
        Wait(0)
    end
end)

-- Cierra el bigmap al conectar (Wait(250) en lugar de Wait(0))
CreateThread(function()
    local pid = PlayerId()
    while not NetworkIsPlayerActive(pid) or not IsPlayerPlaying(pid) do
        Wait(250)
    end
    local deadline = GetGameTimer() + 25000
    while GetGameTimer() < deadline do
        if IsBigmapActive() == 1 then
            SetRadarBigmapEnabled(false, false)
        end
        Wait(250)
    end
end)

-- ------------------------------------------------------------
-- Sincronizacion de configuracion global del servidor (Logo + Admin)
-- ------------------------------------------------------------
local function syncServerState()
    local ok, res = pcall(lib.callback.await, 'lsn_hud:getServerState', false)
    if ok and type(res) == 'table' then
        HUD.isAdmin = res.isAdmin == true
        if type(res.server) == 'table' then HUD.server = res.server end
        HUD.send('serverConfig', { isAdmin = HUD.isAdmin, server = HUD.server })
    end
end

RegisterNetEvent('lsn_hud:serverConfig', function(cfg)
    if type(cfg) ~= 'table' then return end
    HUD.server = cfg
    HUD.send('serverConfig', { isAdmin = HUD.isAdmin, server = HUD.server })
end)

-- ------------------------------------------------------------
-- Foco de la NUI (menu y ajustes)
-- ------------------------------------------------------------
function HUD.setFocus(name)
    HUD.focus = name
    SetNuiFocus(name ~= nil, name ~= nil)
    SetNuiFocusKeepInput(false)
end

RegisterNUICallback('ready', function(_, cb)
    HUD.ready = true
    HUD.send('config', {
        accents = Config.Accents,
        cruiseMin = Config.Cruise.minKmh,
        radio = Config.Radio.enabled,
        maxQueue = Config.Radio.maxQueue,
        stallKnots = Config.Aircraft.stallKnots,
        maxLogoBytes = (Config.Admin and Config.Admin.maxLogoBytes) or 240000,
        text = { embed = Config.Text.radioEmbed, badLink = Config.Text.radioBadLink },
    })
    HUD.send('settings', HUD.settings)
    HUD.send('visible', HUD.isVisible())
    radarShown = nil
    CreateThread(syncServerState)
    cb('ok')
end)

RegisterNUICallback('close', function(_, cb)
    HUD.setFocus(nil)
    TriggerEvent('lsn_hud:closed')
    cb('ok')
end)

RegisterNUICallback('saveSettings', function(data, cb)
    HUD.saveSettings(data)
    cb('ok')
end)

RegisterNUICallback('saveServerConfig', function(data, cb)
    if type(data) == 'table' then
        TriggerServerEvent('lsn_hud:admin:saveServerConfig', data)
    end
    cb('ok')
end)

RegisterNUICallback('notify', function(data, cb)
    if type(data) == 'table' and type(data.msg) == 'string' then
        HUD.notify(data.msg:sub(1, 160), data.kind)
    end
    cb('ok')
end)

-- ------------------------------------------------------------
-- Comandos
-- ------------------------------------------------------------
local function openSettingsPanel(tab)
    if HUD.focus then return end
    -- refrescar permiso admin al abrir por si cambio el grupo ESX
    local ok, res = pcall(lib.callback.await, 'lsn_hud:getServerState', false)
    if ok and type(res) == 'table' then
        HUD.isAdmin = res.isAdmin == true
        if type(res.server) == 'table' then HUD.server = res.server end
        HUD.send('serverConfig', { isAdmin = HUD.isAdmin, server = HUD.server })
    end
    if tab == 'admin' and not HUD.isAdmin then
        return HUD.notify(Config.Text.adminOnly or 'Sin permisos', 'error')
    end
    HUD.setFocus('settings')
    HUD.send('openSettings', {
        settings = HUD.settings,
        tab = tab or 'general',
        isAdmin = HUD.isAdmin,
        server = HUD.server,
    })
end

RegisterCommand(Config.Commands.settings, function()
    openSettingsPanel('general')
end, false)

if Config.Commands.admin and Config.Commands.admin ~= '' then
    RegisterCommand(Config.Commands.admin, function()
        openSettingsPanel('admin')
    end, false)
    TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.admin, 'Panel de administrador del HUD (logo del servidor)')
end

RegisterCommand(Config.Commands.toggle, function()
    HUD.hidden = not HUD.hidden
    SetResourceKvpInt('lsn_hud_hidden', HUD.hidden and 1 or 0)
    HUD.notify(HUD.hidden and Config.Text.hudHidden or Config.Text.hudShown)
end, false)

RegisterCommand(Config.Commands.cinematic, function()
    HUD.cinematic = not HUD.cinematic
    HUD.send('cinematic', HUD.cinematic)
end, false)

TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.settings, 'Ajustes del HUD: velocimetro, brujula, colores, posiciones y admin')
TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.toggle, 'Ocultar / mostrar el HUD')
TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.cinematic, 'Modo cine')

-- ------------------------------------------------------------
-- Arranque y limpieza
-- ------------------------------------------------------------
loadSettings()

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if HUD.focus then SetNuiFocus(false, false) end
    DisplayRadar(true)
end)

exports('setHidden', function(state)
    HUD.cinematic = state and true or false
end)
exports('getSettings', function() return copy(HUD.settings) end)
