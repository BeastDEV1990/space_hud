-- ============================================================
--  LSN HUD - client/status.lua (Optimizado con delta-check)
--  Vida, chaleco, comida, sed (esx_status), oxigeno, estamina,
--  voz, calle, zona y brujula.
-- ============================================================

local needs = { hunger = 100.0, thirst = 100.0 }
local extra = {}
local hasNeeds = false
local forceSync = true

AddEventHandler('lsn_hud:settingsChanged', function() forceSync = true end)
AddEventHandler('lsn_hud:becameVisible', function() forceSync = true end)

if Config.Status.useEsxStatus then
    AddEventHandler('esx_status:onTick', function(data)
        if type(data) ~= 'table' then return end
        hasNeeds = true
        for i = 1, #data do
            local s = data[i]
            if s and s.name then
                local pct = tonumber(s.percent) or 0
                if s.name == 'hunger' or s.name == 'thirst' then
                    needs[s.name] = pct
                elseif s.name == 'stress' or s.name == 'drunk' then
                    extra[s.name] = pct
                end
            end
        end
    end)
end

-- ------------------------------------------------------------
-- Oxigeno
-- ------------------------------------------------------------
local oxyMax = nil

local function oxygen(ped, pid)
    if not IsPedSwimmingUnderWater(ped) then
        oxyMax = nil
        return nil
    end
    local left = GetPlayerUnderwaterTimeRemaining(pid)
    if not oxyMax or left > oxyMax then oxyMax = math.max(left, 1.0) end
    return math.floor(math.max(0.0, math.min(100.0, left / oxyMax * 100.0)) + 0.5)
end

-- ------------------------------------------------------------
-- Envio al HUD solo cuando cambian valores (bajo consumo NUI)
-- ------------------------------------------------------------
CreateThread(function()
    local pid = PlayerId()
    local lastKey = ''
    while true do
        Wait(250)
        if HUD.isVisible() then
            local ped = PlayerPedId()
            local maxHp = GetEntityMaxHealth(ped) - 100
            local hp = IsEntityDead(ped) and 0 or math.floor(math.max(0, math.min(100, (GetEntityHealth(ped) - 100) / math.max(maxHp, 1) * 100)) + 0.5)
            local armor = GetPedArmour(ped)
            local stamina = math.floor(100 - GetPlayerSprintStaminaRemaining(pid) + 0.5)
            local oxy = oxygen(ped, pid)
            local hunger = hasNeeds and math.floor(needs.hunger + 0.5) or nil
            local thirst = hasNeeds and math.floor(needs.thirst + 0.5) or nil
            local stress = extra.stress and math.floor(extra.stress + 0.5) or nil
            local inVeh = (VEH and VEH.veh ~= 0) or IsPedInAnyVehicle(ped, false)
            local autoBelow = HUD.settings.statusMode == 'auto' and Config.Status.autoShowBelow or nil

            local vTalk, vMode, vRadio = false, nil, false
            if HUD.settings.showVoice then
                vTalk = NetworkIsPlayerTalking(pid) == 1 or NetworkIsPlayerTalking(pid) == true
                local prox = LocalPlayer.state.proximity
                vMode = type(prox) == 'table' and (prox.mode or prox.index) or 2
                vRadio = LocalPlayer.state.radioActive and true or false
            end

            local key = ('%d:%d:%s:%s:%s:%s:%d:%s:%s:%s:%s:%s'):format(
                hp, armor, tostring(hunger), tostring(thirst), tostring(stress), tostring(oxy),
                stamina, tostring(HUD.settings.showVoice), tostring(vTalk), tostring(vMode), tostring(vRadio), tostring(autoBelow)
            )

            if forceSync or key ~= lastKey then
                lastKey = key
                HUD.send('player', {
                    hp = hp,
                    armor = armor,
                    hunger = hunger,
                    thirst = thirst,
                    stress = stress,
                    oxygen = oxy,
                    stamina = stamina,
                    voice = HUD.settings.showVoice and { talking = vTalk, mode = vMode, radio = vRadio } or nil,
                    inVehicle = inVeh,
                    autoBelow = autoBelow,
                })
            end
        else
            Wait(250)
        end
    end
end)

-- ------------------------------------------------------------
-- Calle, zona y brujula (frecuencia adaptativa + delta-check)
-- ------------------------------------------------------------
local function compassHeading()
    local rot = GetGameplayCamRot(0)
    return (360.0 - ((rot.z % 360.0) + 360.0) % 360.0) % 360.0
end

local function angleDelta(a, b)
    local d = math.abs(a - b) % 360.0
    return d > 180.0 and 360.0 - d or d
end

CreateThread(function()
    local lastHdg = -999.0
    local lastLocKey = ''
    local nextStreetAt = 0

    while true do
        local showCompass = HUD.settings.showCompass
        local showStreet = HUD.settings.showStreet
        if HUD.isVisible() and (showCompass or showStreet) then
            local now = GetGameTimer()
            local payload = nil

            if showCompass then
                local hdg = compassHeading()
                if forceSync or angleDelta(hdg, lastHdg) >= 0.45 then
                    lastHdg = hdg
                    payload = payload or {}
                    payload.hdg = math.floor(hdg * 10 + 0.5) / 10
                end
            end

            if showStreet and (forceSync or now >= nextStreetAt) then
                nextStreetAt = now + 500
                local c = GetEntityCoords(PlayerPedId())
                local s1, s2 = GetStreetNameAtCoord(c.x, c.y, c.z)
                local street = GetStreetNameFromHashKey(s1)
                local cross = s2 ~= 0 and GetStreetNameFromHashKey(s2) or ''
                local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
                if zone == 'NULL' then zone = '' end
                local h = GetClockHours()
                local m = GetClockMinutes()
                local key = street .. '|' .. cross .. '|' .. zone .. '|' .. h .. ':' .. m
                if forceSync or key ~= lastLocKey then
                    lastLocKey = key
                    payload = payload or {}
                    payload.street = street
                    payload.cross = cross
                    payload.zone = zone
                    payload.time = ('%02d:%02d'):format(h, m)
                end
            end

            if payload then
                HUD.send('loc', payload)
            end
            forceSync = false

            -- mas fluido si la brujula esta activa y en movimiento; mas relajado si solo muestra calle
            Wait(showCompass and (payload and 75 or 140) or 350)
        else
            Wait(400)
        end
    end
end)
