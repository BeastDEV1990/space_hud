-- ============================================================
--  LSN HUD - client/vehicle.lua (Optimizado)
--  Datos del velocimetro con cache lento/rapido y delta-check,
--  crucero (J), direccionales, cinturon, motor y seguro.
-- ============================================================

VEH = {
    veh = 0,
    seat = nil,
    kind = nil,       -- 'car' | 'bike' | 'bicycle' | 'boat' | 'plane' | 'heli'
    class = nil,
    cruise = nil,     -- velocidad objetivo en m/s
    belt = false,
    trip = 0.0,       -- metros (cuando realengine_vehicles no lleva el auto)
}

local T = Config.Text

-- ------------------------------------------------------------
-- Utilidades
-- ------------------------------------------------------------
function VEH.kindOf(veh)
    local model = GetEntityModel(veh)
    if IsThisModelAHeli(model) then return 'heli' end
    if IsThisModelAPlane(model) then return 'plane' end
    if IsThisModelABoat(model) or IsThisModelAJetski(model) then return 'boat' end
    if IsThisModelABicycle(model) then return 'bicycle' end
    if IsThisModelABike(model) or IsThisModelAQuadbike(model) then return 'bike' end
    return 'car'
end

function VEH.seatOf(veh, ped)
    for s = -1, GetVehicleModelNumberOfSeats(GetEntityModel(veh)) - 2 do
        if GetPedInVehicleSeat(veh, s) == ped then return s end
    end
    return nil
end

local retroModels, modernModels = {}, {}
for _, m in ipairs(Config.Retro.models or {}) do retroModels[GetHashKey(m)] = true end
for _, m in ipairs(Config.Retro.modern or {}) do modernModels[GetHashKey(m)] = true end

function VEH.isRetro(veh)
    local unit = Entity(veh).state.lsnHeadUnit
    if unit == 'carplay' then return false end
    if unit == 'retro' then return true end
    if not Config.Retro.enabled then return false end
    local model = GetEntityModel(veh)
    if modernModels[model] then return false end
    return retroModels[model] == true or Config.Retro.classes[GetVehicleClass(veh)] == true
end

function VEH.color(veh)
    if GetIsVehiclePrimaryColourCustom(veh) then
        local r, g, b = GetVehicleCustomPrimaryColour(veh)
        return { r = r, g = g, b = b }
    end
    local ok, r, g, b = pcall(GetVehicleColor, veh)
    if ok and tonumber(r) then return { r = r, g = g, b = b } end
    return nil
end

function VEH.isDriver()
    return VEH.veh ~= 0 and VEH.seat == -1
end

local realEngineChecked, realEngineStarted = 0, false
local function hasRealEngine()
    local now = GetGameTimer()
    if now - realEngineChecked > 5000 then
        realEngineChecked = now
        realEngineStarted = GetResourceState('realengine_vehicles') == 'started'
    end
    return realEngineStarted
end

-- combustible en % (ox_fuel, LegacyFuel o nativo)
local fuelMode = nil
local function detectFuel()
    local f = Config.Vehicle.fuelResource
    if f ~= 'auto' then return f end
    if GetResourceState('ox_fuel') == 'started' then return 'ox_fuel' end
    if GetResourceState('LegacyFuel') == 'started' then return 'LegacyFuel' end
    return 'native'
end

function VEH.fuel(veh)
    fuelMode = fuelMode or detectFuel()
    if fuelMode == 'ox_fuel' then
        local f = Entity(veh).state.fuel
        if f then return f + 0.0 end
    elseif fuelMode == 'LegacyFuel' then
        local ok, f = pcall(function() return exports.LegacyFuel:GetFuel(veh) end)
        if ok and f then return f + 0.0 end
    end
    local tank = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')
    local lvl = GetVehicleFuelLevel(veh)
    if tank and tank > 0 then return math.min(100.0, lvl / tank * 100.0) end
    return math.min(100.0, lvl)
end

local function doorBits(veh)
    local bits = 0
    for i = 0, 5 do
        if GetIsDoorValid(veh, i) and GetVehicleDoorAngleRatio(veh, i) > 0.05 then
            bits = bits | (1 << i)
        end
    end
    return bits
end

local WHEELS = { 0, 1, 4, 5 }
local function tireBits(veh)
    local bits = 0
    for n = 1, 4 do
        if IsVehicleTyreBurst(veh, WHEELS[n], false) then bits = bits | (1 << (n - 1)) end
    end
    return bits
end

local function warnings(engHealth, fuel, tires, rev)
    local w = {
        engine = engHealth < 200 and 2 or (engHealth < 400 and 1 or 0),
        fuel = fuel < 8 and 2 or (fuel < 15 and 1 or 0),
        tires = tires ~= 0 and 2 or 0,
    }
    if rev and type(rev) == 'table' then
        for k, v in pairs(rev) do
            w[k] = math.max(w[k] or 0, tonumber(v) or 0)
        end
    end
    return w
end

-- ------------------------------------------------------------
-- Subir / bajar del vehiculo
-- ------------------------------------------------------------
local function setBelt(state, silent)
    if VEH.belt == state then return end
    VEH.belt = state
    local ped = PlayerPedId()
    if Config.Seatbelt.ejectWithoutBelt then
        SetPedConfigFlag(ped, 32, not state)
    end
    LocalPlayer.state:set('lsnBelt', state, true)
    HUD.send('sound', state and 'beltOn' or 'beltOff')
    if not silent then HUD.notify(state and T.beltOn or T.beltOff, state and 'success' or 'inform') end
end

local function onEnter(veh, seat)
    VEH.veh = veh
    VEH.seat = seat
    VEH.kind = VEH.kindOf(veh)
    VEH.class = GetVehicleClass(veh)
    VEH.cruise = nil
    VEH.trip = 0.0
    VEH.belt = false
    local ped = PlayerPedId()
    if Config.Seatbelt.ejectWithoutBelt then SetPedConfigFlag(ped, 32, true) end
    if Config.Engine.manualStart then SetPedConfigFlag(ped, 429, true) end
    TriggerEvent('lsn_hud:enteredVehicle', veh, seat, VEH.kind)
end

local function onExit()
    local veh = VEH.veh
    VEH.veh = 0
    VEH.seat = nil
    VEH.kind = nil
    VEH.cruise = nil
    if VEH.belt then
        VEH.belt = false
        LocalPlayer.state:set('lsnBelt', false, true)
    end
    SetPedConfigFlag(PlayerPedId(), 32, true)
    HUD.send('car', false)
    TriggerEvent('lsn_hud:leftVehicle', veh)
end

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and not IsEntityDead(ped) then
            local seat = VEH.seatOf(veh, ped)
            if veh ~= VEH.veh then
                if VEH.veh ~= 0 then onExit() end
                onEnter(veh, seat)
            elseif seat ~= VEH.seat then
                VEH.seat = seat
                VEH.cruise = nil
            end
        elseif VEH.veh ~= 0 then
            onExit()
        end
        Wait(250)
    end
end)

-- ------------------------------------------------------------
-- Datos del velocimetro (optimizado: datos lentos en cache + ~15Hz fluidos)
-- ------------------------------------------------------------
local lastPos = nil
local carShown = false

CreateThread(function()
    local slowNext = 0
    local cachedFuel, cachedEng, cachedBody, cachedLocked = 100.0, 100.0, 100.0, false
    local cachedDoors, cachedTires, cachedRev, cachedWarn = 0, 0, nil, {}
    local lastSendAt = 0
    local lastSig = ''

    while true do
        local veh = VEH.veh
        local kind = VEH.kind
        if veh ~= 0 and DoesEntityExist(veh) and kind ~= 'plane' and kind ~= 'heli'
            and not Config.Vehicle.noSpeedo[kind] and HUD.isVisible() then
            carShown = true
            local now = GetGameTimer()
            local speed = GetEntitySpeed(veh)
            local knots = kind == 'boat' and Config.Vehicle.boatsInKnots
            local factor = knots and 1.943844 or HUD.speedFactor()
            local engineOn = GetIsVehicleEngineRunning(veh)
            local _, lowOn, highOn = GetVehicleLightsState(veh)
            local rpm = engineOn and GetVehicleCurrentRpm(veh) or 0.0
            local gear = GetVehicleCurrentGear(veh)
            local backward = speed > 0.2 and GetEntitySpeedVector(veh, true).y < -0.5 or false
            local gearTxt
            if not engineOn then gearTxt = 'P'
            elseif gear == 0 or backward then gearTxt = 'R'
            elseif speed < 0.4 and rpm < 0.25 then gearTxt = 'N'
            else gearTxt = tostring(gear) end

            -- Datos lentos: cada 400ms en lugar de cada 50ms
            if now >= slowNext then
                slowNext = now + 400
                cachedRev = nil
                local revWarn = nil
                if VEH.isDriver() and hasRealEngine() then
                    local ok, cur = pcall(function() return exports.realengine_vehicles:getCurrent() end)
                    if ok and cur then cachedRev = cur end
                    local ok2, w = pcall(function() return exports.realengine_vehicles:getWarnings() end)
                    if ok2 then revWarn = w end
                end

                local pos = GetEntityCoords(veh)
                if lastPos then
                    local d = #(pos - lastPos)
                    if d < 35.0 then VEH.trip = VEH.trip + d end
                end
                lastPos = pos

                cachedFuel = VEH.fuel(veh)
                local rawEng = GetVehicleEngineHealth(veh)
                cachedEng = math.max(0, math.min(100, rawEng / 10))
                cachedBody = math.max(0, math.min(100, GetVehicleBodyHealth(veh) / 10))
                cachedLocked = GetVehicleDoorLockStatus(veh) >= 2
                cachedDoors = doorBits(veh)
                cachedTires = tireBits(veh)
                cachedWarn = warnings(rawEng, cachedFuel, cachedTires, revWarn)
            end

            local ind = GetVehicleIndicatorLights(veh)
            local hb = GetVehicleHandbrake(veh)
            local milesK = HUD.settings.units == 'mph' and 0.621371 or 1.0
            local beltable = VEH.kind == 'car' and not Config.Seatbelt.noBeltClasses[VEH.class] and Config.Seatbelt.enabled
            local beltState = nil
            if beltable then beltState = VEH.belt end
            local beltWarn = (beltable and not VEH.belt and speed * 3.6 > Config.Seatbelt.chimeKmh and HUD.settings.beltChime) == true

            local spdVal = speed * factor
            local sig = ('%.1f:%.3f:%s:%d:%d:%d:%d:%s:%d:%d:%.1f:%s:%s'):format(
                spdVal, rpm, gearTxt, engineOn and 1 or 0, lowOn, highOn, ind,
                tostring(hb), cachedDoors, cachedTires, cachedFuel, tostring(VEH.cruise), tostring(beltState)
            )

            -- Enviar solo si algo cambio o cada 500ms como heartbeat ligero
            if sig ~= lastSig or (now - lastSendAt) >= 500 then
                lastSig = sig
                lastSendAt = now
                HUD.send('car', {
                    kind = kind,
                    spd = spdVal,
                    unit = knots and 'kn' or HUD.speedUnit(),
                    rpm = rpm,
                    gear = gearTxt,
                    fuel = cachedFuel,
                    eng = cachedEng,
                    body = cachedBody,
                    on = engineOn,
                    low = lowOn == 1,
                    high = highOn == 1,
                    ind = ind,
                    cruise = VEH.cruise and VEH.cruise * factor or nil,
                    belt = beltState,
                    beltWarn = beltWarn,
                    hb = hb,
                    locked = cachedLocked,
                    doors = cachedDoors,
                    tires = cachedTires,
                    km = cachedRev and cachedRev.km * milesK or nil,
                    trip = (cachedRev and cachedRev.trip or VEH.trip / 1000.0) * milesK,
                    dist = milesK == 1.0 and 'km' or 'mi',
                    temp = cachedRev and cachedRev.temp or nil,
                    warn = cachedWarn,
                    drv = VEH.seat == -1,
                })
            end
            Wait(engineOn and 65 or 180)
        else
            lastPos = nil
            slowNext = 0
            lastSig = ''
            if carShown then
                carShown = false
                HUD.send('car', false)
            end
            Wait(250)
        end
    end
end)

-- ------------------------------------------------------------
-- Control por cuadro: SOLO Wait(0) cuando crucero o bloqueo de cinturon estan activos
-- ------------------------------------------------------------
local function cruiseOff(silent)
    if not VEH.cruise then return end
    VEH.cruise = nil
    HUD.send('sound', 'cruiseOff')
    if not silent then HUD.notify(T.cruiseOff) end
end

CreateThread(function()
    local lastSpeed = 0.0
    while true do
        local veh = VEH.veh
        local needFrame = veh ~= 0 and (VEH.cruise ~= nil or (VEH.belt and Config.Seatbelt.blockExitWhenBuckled))
        if needFrame then
            if VEH.cruise then
                local speed = GetEntitySpeed(veh)
                local crashed = lastSpeed - speed > 2.5
                if not VEH.isDriver() or not GetIsVehicleEngineRunning(veh)
                    or IsControlPressed(0, 72) or IsControlPressed(0, 76) or crashed then
                    cruiseOff()
                elseif not IsEntityInAir(veh) then
                    local diff = VEH.cruise - speed
                    if diff > 0.15 then
                        local want = math.min(1.0, 0.2 + diff * 0.35)
                        if GetControlNormal(0, 71) < want then
                            SetControlNormal(0, 71, want)
                        end
                    end
                end
                lastSpeed = speed
            else
                lastSpeed = 0.0
            end
            if VEH.belt and Config.Seatbelt.blockExitWhenBuckled then
                DisableControlAction(0, 75, true)
                if IsDisabledControlJustPressed(0, 75) then HUD.notify(T.beltBlocked, 'warning') end
            end
            Wait(0)
        else
            lastSpeed = 0.0
            Wait(250)
        end
    end
end)

-- ------------------------------------------------------------
-- Direccionales: se apagan solas al terminar la curva
-- ------------------------------------------------------------
local indHeading = nil

local function headingDiff(a, b)
    local d = math.abs(a - b) % 360.0
    return d > 180.0 and 360.0 - d or d
end

function VEH.setIndicator(value)
    local veh = VEH.veh
    if veh == 0 or not VEH.isDriver() then return end
    local cur = Entity(veh).state.lsnInd or 0
    if cur == value then value = 0 end
    SetVehicleIndicatorLights(veh, 1, value == 1 or value == 3)
    SetVehicleIndicatorLights(veh, 0, value == 2 or value == 3)
    indHeading = (value == 1 or value == 2) and GetEntityHeading(veh) or nil
    TriggerServerEvent('lsn_hud:veh:set', VehToNet(veh), 'ind', value)
    HUD.send('sound', 'ind')
end

CreateThread(function()
    local turned = false
    while true do
        local veh = VEH.veh
        if indHeading and veh ~= 0 and VEH.isDriver() then
            local d = headingDiff(GetEntityHeading(veh), indHeading)
            if d > 45.0 then turned = true end
            if turned and math.abs(GetVehicleSteeringAngle(veh)) < 4.0 and d > 60.0 then
                turned = false
                local cur = Entity(veh).state.lsnInd or 0
                if cur == 1 or cur == 2 then VEH.setIndicator(cur) end
                indHeading = nil
            end
            Wait(200)
        else
            turned = false
            Wait(400)
        end
    end
end)

-- ------------------------------------------------------------
-- Acciones del jugador
-- ------------------------------------------------------------
function VEH.toggleCruise()
    local veh = VEH.veh
    if veh == 0 or not VEH.isDriver() or Config.Cruise.blockedClasses[VEH.class] then return end
    if VEH.cruise then return cruiseOff() end
    local speed = GetEntitySpeed(veh)
    if speed * 3.6 < Config.Cruise.minKmh then
        local min = Config.Cruise.minKmh / 3.6
        return HUD.notify(T.cruiseTooSlow:format(HUD.fmtSpeed(min)), 'warning')
    end
    VEH.cruise = speed
    HUD.send('sound', 'cruiseOn')
    HUD.notify(T.cruiseOn:format(HUD.fmtSpeed(speed)), 'success')
end

function VEH.toggleBelt()
    if VEH.veh == 0 or not Config.Seatbelt.enabled then return end
    if VEH.kind ~= 'car' or Config.Seatbelt.noBeltClasses[VEH.class] then return end
    setBelt(not VEH.belt)
end

local function keysResource()
    return GetResourceState('lsn_llaves') == 'started'
end

function VEH.toggleEngine()
    if keysResource() then return exports.lsn_llaves:toggleEngine() end
    local veh = VEH.veh
    if veh == 0 then return HUD.notify(T.notInVehicle, 'error') end
    if not VEH.isDriver() then return end
    local on = not GetIsVehicleEngineRunning(veh)
    SetVehicleEngineOn(veh, on, false, true)
    if not on then cruiseOff(true) end
    HUD.notify(on and T.engineOn or T.engineOff)
end

function VEH.target(maxDist)
    if VEH.veh ~= 0 then return VEH.veh end
    local pos = GetEntityCoords(PlayerPedId())
    local best, bestD = 0, maxDist
    for _, v in ipairs(GetGamePool('CVehicle')) do
        local d = #(GetEntityCoords(v) - pos)
        if d < bestD and NetworkGetEntityIsNetworked(v) then best, bestD = v, d end
    end
    return best
end

function VEH.toggleLock()
    if keysResource() then return exports.lsn_llaves:toggleLock() end
    if not Config.Lock.enabled then return end
    local veh = VEH.target(Config.Lock.distance)
    if veh == 0 then return HUD.notify(T.noVehicleNear, 'error') end
    TriggerServerEvent('lsn_hud:veh:lock', VehToNet(veh))
end

RegisterNetEvent('lsn_hud:veh:fob', function()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then return end
    lib.requestAnimDict('anim@mp_player_intmenu@key_fob@')
    TaskPlayAnim(ped, 'anim@mp_player_intmenu@key_fob@', 'fob_click', 3.0, 3.0, 900, 48, 0.0, false, false, false)
end)

-- ------------------------------------------------------------
-- Teclas
-- ------------------------------------------------------------
local K = Config.Keys
local function bind(name, desc, key, fn)
    RegisterCommand('+lsnhud_' .. name, fn, false)
    RegisterCommand('-lsnhud_' .. name, function() end, false)
    RegisterKeyMapping('+lsnhud_' .. name, desc, 'keyboard', key)
end

bind('cruise', 'Vehiculo: control de crucero', K.cruise, function() VEH.toggleCruise() end)
bind('indleft', 'Vehiculo: direccional izquierda', K.indLeft, function() VEH.setIndicator(1) end)
bind('indright', 'Vehiculo: direccional derecha', K.indRight, function() VEH.setIndicator(2) end)
bind('hazards', 'Vehiculo: luces de emergencia', K.hazards, function() VEH.setIndicator(3) end)
bind('belt', 'Vehiculo: cinturon de seguridad', K.seatbelt, function() VEH.toggleBelt() end)
if GetResourceState('lsn_llaves') == 'missing' then
    bind('engine', 'Vehiculo: encender / apagar motor', K.engine, function() VEH.toggleEngine() end)
    if Config.Lock.enabled then
        bind('lock', 'Vehiculo: seguro de puertas', K.lock, function() VEH.toggleLock() end)
    end
end

exports('hasSeatbelt', function() return VEH.belt end)
exports('isRetro', function(veh) return VEH.isRetro(veh) end)
exports('getCruise', function() return VEH.cruise end)
