-- ============================================================
--  LSN HUD - client/radio.lua (Optimizado)
--  Radio de YouTube sincronizada por vehiculo con escaneo
--  adaptativo para reducir consumo cuando no hay musica cerca.
-- ============================================================

local R = Config.Radio

local OPENINGS = {
    { door = 0, win = 0, bones = { 'window_lf', 'door_dside_f' } },
    { door = 1, win = 1, bones = { 'window_rf', 'door_pside_f' } },
    { door = 2, win = 2, bones = { 'window_lr', 'door_dside_r' } },
    { door = 3, win = 3, bones = { 'window_rr', 'door_pside_r' } },
}

local function bonePos(veh, names)
    for _, n in ipairs(names) do
        local i = GetEntityBoneIndexByName(veh, n)
        if i ~= -1 then return GetWorldPositionOfEntityBone(veh, i) end
    end
    return nil
end

local function falloff(d)
    if d >= R.range then return 0.0 end
    local f = R.refDistance / math.max(d, R.refDistance)
    local edge = 1.0 - (d / R.range) ^ 2
    return f * edge
end

local function bit(v, i) return ((tonumber(v) or 0) & (1 << i)) ~= 0 end

local function openBody(veh)
    local kind = VEH.kindOf(veh)
    if kind == 'bike' or kind == 'bicycle' or kind == 'boat' then return true end
    if Entity(veh).state.lsnRoof then return true end
    local roof = GetConvertibleRoofState(veh)
    return roof == 1 or roof == 2
end

local function isClosed(veh)
    if openBody(veh) then return false end
    local st = Entity(veh).state
    if (st.lsnWin or 0) ~= 0 then return false end
    for i = 0, 3 do
        if GetIsDoorValid(veh, i) then
            if GetVehicleDoorAngleRatio(veh, i) > 0.05 then return false end
            if not IsVehicleWindowIntact(veh, i) then return false end
        end
    end
    return true
end

function VEH.hearFactor(veh, pos)
    local center = GetEntityCoords(veh)
    local dist = #(center - pos)
    if dist >= R.range + 4.0 then return 0.0 end
    if openBody(veh) then return math.min(1.0, falloff(dist)) end

    local st = Entity(veh).state
    local total = R.closedFactor * falloff(dist)
    for _, o in ipairs(OPENINGS) do
        if GetIsDoorValid(veh, o.door) then
            local doorOpen = GetVehicleDoorAngleRatio(veh, o.door) > 0.05
            local winOpen = bit(st.lsnWin, o.win) or not IsVehicleWindowIntact(veh, o.win)
            if doorOpen or winOpen then
                local p = bonePos(veh, o.bones) or center
                total = total + (doorOpen and R.open.door or R.open.window) * falloff(#(p - pos))
            end
        end
    end
    if GetIsDoorValid(veh, 5) and GetVehicleDoorAngleRatio(veh, 5) > 0.05 then
        total = total + R.open.trunk * falloff(#((bonePos(veh, { 'boot' }) or center) - pos))
    end
    if GetIsDoorValid(veh, 4) and GetVehicleDoorAngleRatio(veh, 4) > 0.05 then
        total = total + R.open.hood * falloff(#((bonePos(veh, { 'bonnet' }) or center) - pos))
    end
    return math.min(1.0, total)
end

-- Despertar el escaneo rapido en cuanto algun vehiculo active la radio
local wakeupAt = 0
AddStateBagChangeHandler('lsnRadio', nil, function(_, _, value)
    if value then wakeupAt = GetGameTimer() + 5000 end
end)

local function source()
    local ped = PlayerPedId()
    local own = VEH and VEH.veh or GetVehiclePedIsIn(ped, false)
    if own ~= 0 and Entity(own).state.lsnRadio then return own, 1.0 end

    local pos = GetEntityCoords(ped)
    local muffle = (own ~= 0 and isClosed(own)) and R.listenerInClosedCar or 1.0
    local best, bestF = 0, 0.0
    local near, nearD = 0, R.range
    for _, veh in ipairs(GetGamePool('CVehicle')) do
        if veh ~= own and NetworkGetEntityIsNetworked(veh) then
            local r = Entity(veh).state.lsnRadio
            if r then
                local d = #(GetEntityCoords(veh) - pos)
                if d < nearD then near, nearD = veh, d end
                if d < R.range + 4.0 then
                    local f = VEH.hearFactor(veh, pos) * muffle
                    if f > bestF then best, bestF = veh, f end
                end
            end
        end
    end
    if bestF < 0.01 then return near, 0.0 end
    return best, bestF
end

local last = nil
local lastVeh, lastN = 0, nil

CreateThread(function()
    while true do
        local payload = false
        local active = false
        if R.enabled then
            local veh, factor = source()
            if veh ~= 0 then
                active = true
                local r = Entity(veh).state.lsnRadio
                if type(r) == 'table' and r.id then
                    local vol = (tonumber(r.vol) or 50) * factor * (HUD.settings.musicVolume or 100) / 100
                    payload = {
                        id = r.id, n = r.n, t = r.t, p = r.p and true or false, pos = r.pos or 0,
                        vol = math.floor(vol + 0.5), now = HUD.serverTime(),
                        inside = veh == (VEH and VEH.veh or GetVehiclePedIsIn(PlayerPedId(), false)),
                    }
                    if payload.inside and (veh ~= lastVeh or r.n ~= lastN) then
                        SetVehRadioStation(veh, 'OFF')
                    end
                    lastVeh, lastN = veh, r.n
                end
            end
        end
        local key = payload and (payload.id .. ':' .. payload.n .. ':' .. tostring(payload.p) .. ':' .. payload.vol .. ':' .. (payload.now // 2)) or 'off'
        if key ~= last then
            last = key
            HUD.send('audio', payload)
        end
        -- 150ms solo cuando hay radio activa o recien encendida; 600ms en reposo
        Wait((active or GetGameTimer() < wakeupAt) and 150 or 600)
    end
end)

-- ------------------------------------------------------------
-- Controles desde CarPlay
-- ------------------------------------------------------------
RegisterNUICallback('radio', function(data, cb)
    cb('ok')
    local veh = VEH.veh
    if veh == 0 or type(data) ~= 'table' or type(data.cmd) ~= 'string' then return end
    if not R.controlSeats[VEH.seat] then return HUD.notify(Config.Text.radioNoSeat, 'error') end
    TriggerServerEvent('lsn_hud:radio', VehToNet(veh), data.cmd, data.arg, data.title)
    SetTimeout(300, HUD.refreshMenu)
end)

RegisterNUICallback('ytEnded', function(data, cb)
    cb('ok')
    local veh = VEH.veh
    if veh ~= 0 and type(data) == 'table' and R.controlSeats[VEH.seat] then
        TriggerServerEvent('lsn_hud:radio', VehToNet(veh), 'ended', tonumber(data.n))
    end
end)

RegisterNUICallback('ytError', function(data, cb)
    cb('ok')
    local veh = VEH.veh
    if veh ~= 0 and type(data) == 'table' and R.controlSeats[VEH.seat] then
        HUD.notify(Config.Text.radioEmbed, 'error')
        TriggerServerEvent('lsn_hud:radio', VehToNet(veh), 'ended', tonumber(data.n))
    end
end)

RegisterNetEvent('lsn_hud:radio:msg', function(key)
    local msg = Config.Text[key]
    if msg then HUD.notify(msg, key == 'radioQueued' and 'success' or 'error') end
end)
