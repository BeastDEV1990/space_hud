-- ============================================================
--  LSN HUD - client/menu.lua
--  Pantalla tipo CarPlay: inicio, musica, vehiculo (puertas,
--  vidrios, techo, luz interior, motor, seguro, cinturon,
--  asientos) y diagnostico (piezas de realengine_vehicles).
-- ============================================================

local T = Config.Text
local open = false

local function label(text)
    if not text or text == '' then return '' end
    local l = GetLabelText(text)
    if l == 'NULL' then return text end
    return l
end

local function bits(fn, from, to)
    local b = 0
    for i = from, to do if fn(i) then b = b | (1 << i) end end
    return b
end

local function diagnostics(veh)
    local d = {
        eng = math.max(0, math.min(100, GetVehicleEngineHealth(veh) / 10)),
        body = math.max(0, math.min(100, GetVehicleBodyHealth(veh) / 10)),
        fuel = VEH.fuel(veh),
        tank = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume'),
    }
    if VEH.isDriver() and GetResourceState('realengine_vehicles') == 'started' then
        local ok, cur = pcall(function() return exports.realengine_vehicles:getCurrent() end)
        if ok and cur then
            local k = HUD.settings.units == 'mph' and 0.621371 or 1.0
            d.km = cur.km * k
            d.trip = cur.trip * k
            d.temp = cur.temp
            d.parts = cur.parts
            local ok2, labels = pcall(function() return exports.realengine_vehicles:getPartLabels() end)
            if ok2 then d.labels = labels end
        end
    end
    d.dist = HUD.settings.units == 'mph' and 'mi' or 'km'
    return d
end

local function radioAllowed(veh)
    return Config.Radio.enabled and not Config.Radio.blockedClasses[GetVehicleClass(veh)]
end

local function state()
    local veh = VEH.veh
    if veh == 0 or not DoesEntityExist(veh) then return nil end
    local model = GetEntityModel(veh)
    local bag = VEH.bag(veh)
    local seats = GetVehicleModelNumberOfSeats(model)
    local roofState = GetConvertibleRoofState(veh)
    local radio = Entity(veh).state.lsnRadio
    return {
        name = label(GetDisplayNameFromVehicleModel(model)),
        make = label(GetMakeNameFromVehicleModel(model)),
        plate = (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', ''),
        kind = VEH.kind,
        seat = VEH.seat,
        drv = VEH.seat == -1,
        speed = GetEntitySpeed(veh),
        on = GetIsVehicleEngineRunning(veh),
        locked = GetVehicleDoorLockStatus(veh) >= 2,
        belt = VEH.belt,
        beltable = VEH.kind == 'car' and Config.Seatbelt.enabled and not Config.Seatbelt.noBeltClasses[VEH.class],
        ind = bag.ind,
        int = bag.int,
        win = bag.win,
        doorValid = bits(function(i) return GetIsDoorValid(veh, i) end, 0, 5),
        doorOpen = bits(function(i) return GetIsDoorValid(veh, i) and GetVehicleDoorAngleRatio(veh, i) > 0.05 end, 0, 5),
        convertible = IsVehicleAConvertible(veh, false),
        roof = roofState == 1 or roofState == 2,
        seats = seats,
        seatFree = bits(function(i) return IsVehicleSeatFree(veh, i - 1) end, 0, math.max(seats - 1, 0)),
        canRadio = radioAllowed(veh) and Config.Radio.controlSeats[VEH.seat] == true,
        hasRadio = radioAllowed(veh),
        radio = radio,
        now = HUD.serverTime(),
        diag = diagnostics(veh),
        retro = VEH.isRetro(veh),
        color = VEH.color(veh),
        units = HUD.speedUnit(),
        factor = HUD.speedFactor(),
    }
end

local function openMenu(tab)
    if HUD.focus then return end
    if VEH.veh == 0 then return HUD.notify(T.notInVehicle, 'error') end
    local st = state()
    if not st then return end
    open = true
    HUD.setFocus('menu')
    HUD.send('carplay', { open = true, tab = tab, state = st })
end

local function closeMenu()
    if not open then return end
    open = false
    HUD.send('carplay', { open = false })
    if HUD.focus == 'menu' then HUD.setFocus(nil) end
end

AddEventHandler('lsn_hud:closed', function() open = false end)

-- refresco mientras esta abierto
CreateThread(function()
    while true do
        if open then
            if VEH.veh == 0 then
                closeMenu()
            else
                local st = state()
                if st then HUD.send('carplay', { state = st }) end
            end
            Wait(400)
        else
            Wait(500)
        end
    end
end)

function HUD.refreshMenu()
    if open then
        local st = state()
        if st then HUD.send('carplay', { state = st }) end
    end
end

-- ------------------------------------------------------------
-- Acciones desde la pantalla
-- ------------------------------------------------------------
local function netOf(veh) return VehToNet(veh) end

RegisterNUICallback('vehAction', function(data, cb)
    cb('ok')
    local veh = VEH.veh
    if veh == 0 or type(data) ~= 'table' then return end
    local act, i = data.act, tonumber(data.i)

    if act == 'engine' then VEH.toggleEngine()
    elseif act == 'lock' then VEH.toggleLock()
    elseif act == 'belt' then VEH.toggleBelt()
    elseif act == 'ind' and i then VEH.setIndicator(math.floor(i))
    elseif act == 'int' then
        TriggerServerEvent('lsn_hud:veh:set', netOf(veh), 'int', not VEH.bag(veh).int)
    elseif act == 'door' and i and i >= 0 and i <= 5 then
        if GetVehicleDoorLockStatus(veh) >= 2 and VEH.seat ~= -1 then return HUD.notify(T.isLocked, 'error') end
        local isOpen = GetVehicleDoorAngleRatio(veh, i) > 0.05
        TriggerServerEvent('lsn_hud:veh:set', netOf(veh), 'door', { i = i, open = not isOpen })
    elseif act == 'win' and i and i >= 0 and i <= 3 then
        local down = (VEH.bag(veh).win & (1 << i)) ~= 0
        TriggerServerEvent('lsn_hud:veh:set', netOf(veh), 'win', { i = i, down = not down })
    elseif act == 'roof' then
        if not IsVehicleAConvertible(veh, false) then return HUD.notify(T.noRoof, 'error') end
        if GetEntitySpeed(veh) > 1.5 then return HUD.notify(T.roofSpeed, 'warning') end
        local st = GetConvertibleRoofState(veh)
        TriggerServerEvent('lsn_hud:veh:set', netOf(veh), 'roof', not (st == 1 or st == 2))
    elseif act == 'seat' and i then
        local seat = math.floor(i)
        if seat ~= VEH.seat and IsVehicleSeatFree(veh, seat) and GetEntitySpeed(veh) < 2.0 then
            if VEH.belt then VEH.toggleBelt() end
            SetPedIntoVehicle(PlayerPedId(), veh, seat)
        end
    end
    SetTimeout(250, HUD.refreshMenu)
end)

-- ------------------------------------------------------------
-- Teclas y comandos
-- ------------------------------------------------------------
local K = Config.Keys
RegisterCommand('+lsnhud_menu', function() openMenu('vehicle') end, false)
RegisterCommand('-lsnhud_menu', function() end, false)
RegisterKeyMapping('+lsnhud_menu', 'Vehiculo: menu (puertas, vidrios, motor...)', 'keyboard', K.vehicleMenu)

RegisterCommand('+lsnhud_carplay', function() openMenu('home') end, false)
RegisterCommand('-lsnhud_carplay', function() end, false)
RegisterKeyMapping('+lsnhud_carplay', 'Vehiculo: pantalla CarPlay y radio', 'keyboard', K.carplay)

RegisterCommand(Config.Commands.vehicle, function() openMenu('vehicle') end, false)
RegisterCommand(Config.Commands.radio, function() openMenu('music') end, false)
TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.vehicle, 'Menu del vehiculo')
TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.radio, 'Radio del vehiculo (YouTube)')
