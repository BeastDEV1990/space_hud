fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'LSN'
description 'LSN HUD - estado, velocimetros, aeronaves, menu de vehiculo, CarPlay y radio'
version '1.4.0'

dependencies {
    'es_extended',
    'ox_lib',
}

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
    'client/status.lua',
    'client/vehicle.lua',
    'client/aircraft.lua',
    'client/sync.lua',
    'client/menu.lua',
    'client/headunit.lua',
    'client/radio.lua',
}

server_scripts {
    'server/main.lua',
    'server/radio.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
    'html/fonts/*.ttf',
}
